export default async function handler(_req: any, res: any) {
  try {
    const r = await fetch('https://www.tcmb.gov.tr/kurlar/today.xml', {
      headers: { 'User-Agent': 'Mozilla/5.0', Accept: 'application/xml, text/xml, */*' },
    });
    if (!r.ok) return res.status(r.status).json({ error: `TCMB returned ${r.status}` });
    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    res.setHeader('Cache-Control', 's-maxage=1800, stale-while-revalidate=3600');
    return res.status(200).send(await r.text());
  } catch {
    return res.status(502).json({ error: 'Proxy failed' });
  }
}
