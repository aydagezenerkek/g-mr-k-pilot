import { auditAndVerifyTariff, InputError } from '../../server/customsAudit.js';

import { rateLimited } from '../../server/rateLimit.js';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (rateLimited(req, 15)) return res.status(429).json({ error: 'Çok fazla istek. Bir dakika sonra tekrar deneyin.' });
  try {
    const b = req.body || {};
    if (!b.hsCode) return res.status(400).json({ error: 'hsCode parametresi zorunludur.' });
    const result = await auditAndVerifyTariff({
      hsCode: String(b.hsCode),
      targetCountry: String(b.targetCountry || 'Almanya'),
      localDescription: b.localDescription ? String(b.localDescription) : undefined,
      forceRefresh: false,
    });
    return res.status(200).json(result);
  } catch (error: any) {
    if (error instanceof InputError) return res.status(400).json({ error: error.message });
    if (error?.message === 'AI_QUOTA') return res.status(429).json({ error: 'Ücretsiz yapay zeka kotası doldu. Bir süre sonra tekrar deneyin.' });
    if (error?.message === 'AI_NOT_CONFIGURED') return res.status(503).json({ error: 'AI servisi yapılandırılmamış.' });
    return res.status(500).json({ error: 'Ön değerlendirme sırasında teknik bir hata oluştu.' });
  }
}
