import { askCustomsCopilot } from '../../server/copilotService.js';

import { rateLimited } from '../../server/rateLimit.js';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (rateLimited(req, 15)) return res.status(429).json({ error: 'Çok fazla istek. Bir dakika sonra tekrar deneyin.' });
  try {
    const b = req.body || {};
    const prompt = typeof b.prompt === 'string' ? b.prompt.slice(0, 500) : '';
    const history = Array.isArray(b.history)
      ? b.history.slice(-6).map((h: any) => ({
          role: h?.role === 'model' ? 'model' : 'user',
          text: String(h?.text ?? '').slice(0, 500),
        }))
      : [];
    return res.status(200).json(await askCustomsCopilot(prompt, history));
  } catch {
    return res.status(500).json({
      reply: 'Gümrük rehber servisinde geçici bir gecikme oluştu. Lütfen sol menüden ilgili sayfayı seçiniz.',
      suggested_screen: null,
      suggested_action_label: null,
      quick_options: [],
      is_out_of_scope: false,
    });
  }
}
