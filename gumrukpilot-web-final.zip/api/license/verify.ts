import { handleLicenseBody } from '../../server/license.js';

import { rateLimited } from '../../server/rateLimit.js';

export default function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (rateLimited(req, 8)) return res.status(429).json({ error: 'Çok fazla istek. Bir dakika sonra tekrar deneyin.' });
  const { status, json } = handleLicenseBody(req.body);
  return res.status(status).json(json);
}
