import { lookupOfficial } from '../server/officialSources.js';
import { rateLimited } from '../server/rateLimit.js';

export default async function handler(req: any, res: any) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  if (rateLimited(req, 20)) return res.status(429).json({ error: 'Çok fazla istek. Bir dakika sonra tekrar deneyin.' });
  const r = await lookupOfficial(String(req.query.hs ?? ''), String(req.query.country ?? ''));
  if (!r.ok) return res.status(400).json({ error: r.error });
  // CDN önbelleği: aynı GTİP+ülke 24 saat paylaşımlı önbellekten döner.
  if (r.tariff || r.market) res.setHeader('Cache-Control', 's-maxage=86400, stale-while-revalidate=604800');
  return res.status(200).json(r);
}
