# GümrükPilot Gizlilik Politikası

Son güncelleme: [TARİH]

GümrükPilot ("Uygulama"), ihracat gönderileri için gümrük hazırlığı, maliyet tahmini ve fatura/çeki listesi hazırlamanıza yardımcı olan bir araçtır.

## Hangi veriler işlenir?
Uygulamaya girdiğiniz bilgiler: satıcı bilgileriniz (unvan, adres, telefon, e-posta, vergi numarası), alıcı bilgileri, ürün bilgileri, fiyatlar ve oluşturduğunuz fatura/çeki listeleri.

## Veriler nerede saklanır?
Bu veriler **yalnızca cihazınızda** saklanır. Geliştirici olarak bu verilere erişmiyoruz, sunucularımıza göndermiyoruz, reklam veya analiz amacıyla üçüncü taraflarla paylaşmıyoruz.

## Ağ bağlantısı
Uygulama, güncel döviz kurunu göstermek için T.C. Merkez Bankası'nın herkese açık kur servisine bağlanır. Bu istekte kişisel verileriniz gönderilmez.

## Yedekleme
- **Uygulama içi yedek:** "Yedekle / Geri Yükle" ile oluşturduğunuz dosya sizin seçtiğiniz yere kaydedilir. Dosya şifresizdir; güvenli saklamak sizin sorumluluğunuzdadır.
- **Android hesap yedeği:** Cihazınızda Google yedeği açıksa, uygulama verileri işletim sistemi tarafından Google hesabınıza yedeklenebilir. Bu, Google'ın ayarlarına ve gizlilik politikasına tabidir.

## Paylaşım
Oluşturduğunuz PDF ve listeleri yalnızca siz paylaşım ekranından seçtiğiniz uygulamalarla paylaşırsınız.

## Silme
Uygulamayı kaldırdığınızda cihazdaki verileriniz silinir. Google hesap yedeğini Google hesabınızdan ayrıca silebilirsiniz.

## Sorumluluk reddi
Uygulamadaki gümrük kuralları ve maliyet tahminleri bilgilendirme amaçlıdır; bağlayıcı değildir ve gümrük müşavirliği/hukuki danışmanlık yerine geçmez. Kesin işlem için ilgili ülkenin gümrük idaresine ve yetkili gümrük müşavirine başvurun.

## İletişim
[AD / FİRMA] — [E-POSTA]

> Not: Yayından önce bu metni bir hukukçuya (KVKK açısından) kontrol ettirin ve [ ] alanlarını doldurun.
