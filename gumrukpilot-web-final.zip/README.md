# GümrükPilot

Türkiye'den ihracat yapan firmalar için gümrük uyum kokpiti (web: React + Vite + TS).
Veriler cihazda tutulur, hesap yoktur. Sunucu tarafı yalnızca: Pro lisans doğrulama, AI GTİP ön değerlendirme, TCMB kur proxy'si.

## Çalıştırma
```
npm install
npm test          # vitest (src/core/*.test.ts)
npm run lint      # tsc --noEmit
npm run dev       # express + vite, http://localhost:3000
```

## Vercel
`api/` klasörü serverless fonksiyonlardır, `vercel.json` hazırdır. Ortam değişkenleri: `.env.example`.
`LICENSE_KEYS` ve `LICENSE_SECRET` tanımlı değilse Pro aktivasyonu çalışmaz (güvenli varsayılan).

## Pro modeli
Anahtar → `/api/license/verify` → 30 günlük imzalı token. İstemci her açılışta tokenı sunucuda doğrular;
yerel bir bayrakla Pro açılamaz. Not: PDF üretimi istemcide olduğundan kararlı bir saldırgan kodu değiştirebilir; bu, ödeme altyapısı gelene kadar kabul edilmiş bir risktir.

## İçerik doğrulama durumu
Kural verisi (`src/core/rules.ts`) henüz bir gümrük müşaviri tarafından imzalanmamıştır. "Uzman Doğrulama Modu" raporları,
ad girilip onaylanmadıkça "UZMAN ONAYI YOKTUR" ibaresi taşır. AI GTİP/vergi çıktısı her zaman "doğrulanmamış"tır.

## Uzman tarife tablosu
`server/curatedTariffs.ts` — yalnızca müşavir onaylı (verified_by + verified_on) satırlar eklenir; varsa AI yerine bu kullanılır.
