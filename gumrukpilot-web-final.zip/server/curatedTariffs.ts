/**
 * Uzman onaylı tarife tablosu. Satır, yalnızca bir gümrük müşaviri doğruladıysa eklenir
 * (verified_by: ad/ruhsat no, verified_on: YYYY-MM-DD). Boşsa sistem AI ön tahmine düşer.
 */
export interface CuratedTariff {
  hs_code: string;
  country: string;
  base_duty_rate: string;
  vat_rate: string;
  conditions: string;
  verified_by: string;
  verified_on: string;
}

export const CURATED_TARIFFS: CuratedTariff[] = [];
