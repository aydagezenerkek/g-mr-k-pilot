/** Basit, instance başına bellek içi istek sınırı (IP başına dakikada `max`). */
const hits = new Map<string, { n: number; reset: number }>();

export function rateLimited(req: any, max = 15): boolean {
  const fwd = String(req.headers?.['x-forwarded-for'] || '').split(',')[0].trim();
  const ip = fwd || req.socket?.remoteAddress || 'unknown';
  const now = Date.now();
  if (hits.size > 5000) hits.clear();
  const h = hits.get(ip);
  if (!h || now > h.reset) {
    hits.set(ip, { n: 1, reset: now + 60000 });
    return false;
  }
  return ++h.n > max;
}
