import { createHash, createHmac, timingSafeEqual } from 'node:crypto';

/**
 * Pro lisans doğrulama (sunucu tarafı).
 * LICENSE_KEYS   : virgülle ayrılmış geçerli anahtarlar
 * LICENSE_SECRET : token imzalama sırrı (en az 24 karakter, istemciye asla gitmez)
 * Token anahtarı düz metin içermez; anahtar LICENSE_KEYS'ten silinirse token da geçersiz olur.
 */

const TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000;

const b64 = (s: string) => Buffer.from(s, 'utf8').toString('base64url');
const unb64 = (s: string) => Buffer.from(s, 'base64url').toString('utf8');
const keyHash = (key: string) => createHash('sha256').update(key).digest('hex').slice(0, 16);

const secret = () => {
  const s = process.env.LICENSE_SECRET || '';
  return s.length >= 24 ? s : '';
};

const validKeys = () =>
  (process.env.LICENSE_KEYS || '').split(',').map(k => k.trim().toUpperCase()).filter(Boolean);

const sign = (payload: string, s: string) => createHmac('sha256', s).update(payload).digest('base64url');

const safeEqual = (a: string, b: string) => {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
};

export type LicenseResult =
  | { valid: true; token?: string; expiresAt: number }
  | { valid: false; reason: 'not_configured' | 'invalid' | 'expired' };

/** Anahtarla aktivasyon: geçerliyse imzalı, süreli token üretir. */
export function activateLicense(rawKey: unknown): LicenseResult {
  const s = secret();
  if (!s || validKeys().length === 0) return { valid: false, reason: 'not_configured' };
  const key = String(rawKey ?? '').trim().toUpperCase();
  if (!key || !validKeys().some(k => safeEqual(k, key))) return { valid: false, reason: 'invalid' };
  const expiresAt = Date.now() + TOKEN_TTL_MS;
  const payload = b64(JSON.stringify({ h: keyHash(key), exp: expiresAt }));
  return { valid: true, token: `${payload}.${sign(payload, s)}`, expiresAt };
}

/** Token kontrolü: imza + süre + anahtarın hâlâ geçerli olması. */
export function checkLicenseToken(rawToken: unknown): LicenseResult {
  const s = secret();
  if (!s || validKeys().length === 0) return { valid: false, reason: 'not_configured' };
  const token = String(rawToken ?? '');
  const [payload, sig] = token.split('.');
  if (!payload || !sig || !safeEqual(sig, sign(payload, s))) return { valid: false, reason: 'invalid' };
  try {
    const { h, exp } = JSON.parse(unb64(payload)) as { h: string; exp: number };
    if (typeof exp !== 'number' || exp < Date.now()) return { valid: false, reason: 'expired' };
    if (!validKeys().some(k => keyHash(k) === h)) return { valid: false, reason: 'invalid' };
    return { valid: true, expiresAt: exp };
  } catch {
    return { valid: false, reason: 'invalid' };
  }
}

/** Tek giriş noktası: {key} veya {token} alır. */
export function handleLicenseBody(body: any): { status: number; json: Record<string, unknown> } {
  const r = body?.token ? checkLicenseToken(body.token) : activateLicense(body?.key);
  if (r.valid) return { status: 200, json: { valid: true, token: (r as any).token, expiresAt: r.expiresAt } };
  return { status: r.reason === 'not_configured' ? 503 : 200, json: { valid: false, reason: r.reason } };
}
