import { CURATED_TARIFFS } from './curatedTariffs.js';

import type { CuratedTariff } from './curatedTariffs.js';

const digits = (s: string) => String(s ?? '').replace(/\D/g, '');
const norm = (s: string) => String(s ?? '').toLowerCase().trim();

export function findCurated(hsCode: string, country: string): CuratedTariff | null {
  const hs = digits(hsCode);
  const rows = CURATED_TARIFFS.filter(r => r.verified_by?.trim() && r.verified_on?.trim());
  return rows.find(r => digits(r.hs_code) === hs && norm(r.country) === norm(country)) ?? null;
}
