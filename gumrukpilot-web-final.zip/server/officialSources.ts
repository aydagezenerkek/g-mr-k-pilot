import { COUNTRIES } from '../src/core/countries.js';

/**
 * Resmî / açık kaynaklar:
 *  - ABD vergisi: USITC HTS (hts.usitc.gov/reststop) — yalnızca temel (General/Special/Other) oran.
 *  - Pazar büyüklüğü: UN Comtrade (yıllık ithalat, ilk ortaklar, Türkiye payı).
 * Yanıt biçimleri canlıda scripts/check-apis.mjs ile doğrulanmalıdır; ayrıştırma savunmacıdır.
 */

const M49: Record<string, number> = {
  DE: 276, FR: 251, IT: 380, ES: 724, NL: 528, BE: 56, PL: 616, RO: 642, BG: 100, GR: 300,
  GB: 826, AZ: 31, GE: 268, RS: 688, US: 842, CN: 156, AE: 784, SA: 682, QA: 634,
};
const TURKEY_M49 = 792;

const ALIASES: Record<string, string> = {
  abd: 'US', usa: 'US', amerika: 'US', 'amerika birleşik devletleri': 'US',
  ingiltere: 'GB', 'i̇ngiltere': 'GB', uk: 'GB', 'birleşik krallık': 'GB',
};

export function resolveCountryCode(name: string): string | null {
  const n = String(name ?? '').trim().toLowerCase();
  if (!n) return null;
  if (ALIASES[n]) return ALIASES[n];
  const c = COUNTRIES.find(x => x.code.toLowerCase() === n || x.nameTr.toLowerCase() === n || x.nameEn.toLowerCase() === n);
  return c?.code ?? null;
}

async function getJson(url: string, headers: Record<string, string> = {}, ms = 8000): Promise<any> {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(url, { headers: { Accept: 'application/json', 'User-Agent': 'GumrukPilot/1.0', ...headers }, signal: ctl.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } finally {
    clearTimeout(t);
  }
}

export interface UsTariff { htsno: string; description: string; general: string; special: string; other: string; note: string }

export async function fetchUsTariff(hsDigits: string): Promise<UsTariff | null> {
  if (hsDigits.length < 6) return null;
  const rows = await getJson(`https://hts.usitc.gov/reststop/search?keyword=${encodeURIComponent(hsDigits)}`);
  if (!Array.isArray(rows)) return null;
  const cands = rows
    .filter((r: any) => r && typeof r.htsno === 'string' && String(r.htsno).replace(/\D/g, '').startsWith(hsDigits.slice(0, 8)) && String(r.general ?? '').trim())
    .sort((a: any, b: any) => String(b.htsno).length - String(a.htsno).length);
  const r = cands[0];
  if (!r) return null;
  return {
    htsno: String(r.htsno),
    description: String(r.description ?? '').replace(/<[^>]*>/g, '').slice(0, 200),
    general: String(r.general),
    special: String(r.special ?? ''),
    other: String(r.other ?? ''),
    note: 'Temel HTS oranıdır. Ek vergiler (Section 232/301, IEEPA/karşılıklı tarifeler, AD/CVD) bu orana dahil değildir; hts.usitc.gov ve broker ile teyit edin.',
  };
}

export interface MarketInfo {
  year: number;
  importValueUsd: number;
  topPartners: { partner: string; valueUsd: number; share: number }[];
  turkeyValueUsd: number;
  turkeyShare: number;
}

export async function fetchMarket(countryCode: string, hsDigits: string): Promise<MarketInfo | null> {
  const reporter = M49[countryCode];
  if (!reporter || hsDigits.length < 6) return null;
  const key = process.env.COMTRADE_API_KEY;
  const base = key ? 'https://comtradeapi.un.org/data/v1/get/C/A/HS' : 'https://comtradeapi.un.org/public/v1/preview/C/A/HS';
  const headers: Record<string, string> = key ? { 'Ocp-Apim-Subscription-Key': key } : {};
  const thisYear = new Date().getFullYear();
  for (const year of [thisYear - 1, thisYear - 2, thisYear - 3]) {
    const url = `${base}?reporterCode=${reporter}&period=${year}&cmdCode=${hsDigits.slice(0, 6)}&flowCode=M`;
    let body: any;
    try { body = await getJson(url, headers, 12000); } catch { continue; }
    const rows: any[] = Array.isArray(body?.data) ? body.data : [];
    const val = (r: any) => Number(r?.primaryValue ?? r?.cifvalue ?? 0) || 0;
    const world = rows.find(r => Number(r.partnerCode) === 0);
    const total = world ? val(world) : 0;
    if (!total) continue;
    const partners = rows
      .filter(r => Number(r.partnerCode) !== 0 && val(r) > 0)
      .sort((a, b) => val(b) - val(a));
    const tr = partners.find(r => Number(r.partnerCode) === TURKEY_M49);
    return {
      year,
      importValueUsd: total,
      topPartners: partners.slice(0, 5).map(r => ({ partner: String(r.partnerDesc ?? r.partnerCode), valueUsd: val(r), share: val(r) / total })),
      turkeyValueUsd: tr ? val(tr) : 0,
      turkeyShare: tr ? val(tr) / total : 0,
    };
  }
  return null;
}

export async function lookupOfficial(hs: string, countryName: string) {
  const digits = String(hs ?? '').replace(/\D/g, '');
  const code = resolveCountryCode(countryName);
  const errors: string[] = [];
  if (digits.length < 6) return { ok: false as const, error: 'GTİP en az 6 haneli olmalıdır.' };
  if (!code) return { ok: false as const, error: 'Ülke listede bulunamadı.' };
  const [tariff, market] = await Promise.all([
    code === 'US' ? fetchUsTariff(digits).catch(e => { errors.push('ABD tarife servisi yanıt vermedi'); return null; }) : Promise.resolve(null),
    fetchMarket(code, digits).catch(() => { errors.push('Pazar verisi alınamadı'); return null; }),
  ]);
  return { ok: true as const, country: code, tariff, market, errors, fetchedAt: new Date().toISOString() };
}
