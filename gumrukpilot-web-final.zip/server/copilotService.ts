import { GoogleGenAI, Type } from '@google/genai';

const aiStudio = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'gumrukpilot',
    },
  },
});

export interface CopilotQuickOption {
  label: string;
  payload: string;
}

export type ValidAppScreen =
  | 'expert-audit'
  | 'docs'
  | 'pallet'
  | 'cost'
  | 'customs'
  | 'roadmap'
  | 'mistakes'
  | 'shipments'
  | 'exchange'
  | 'sync';

export interface CopilotResponse {
  reply: string;
  suggested_screen: ValidAppScreen | null;
  suggested_action_label: string | null;
  quick_options: CopilotQuickOption[];
  is_out_of_scope: boolean;
}

const SYSTEM_INSTRUCTION = `ROL VE KİMLİK:
Sen GümrükPilot Dış Ticaret & Gümrük Mevzuatı Yönlendiricisisin. Görevin kullanıcıya gümrük süreçlerinde doğrudan kanuna, evraklara ve GümrükPilot içindeki ilgili modüllere (sayfalara) dayalı KISA, NET VE SIFIR BOŞ KONUŞMA ile rehberlik etmektir.

KATI KURALLAR:
1. BOŞ KONUŞMA YOK: Merhaba, nasılsınız, size nasıl yardımcı olabilirim gibi giriş-gelişme cümleleri, dolaylı anlatımlar veya sohbet havası KESİNLİKLE YASAKTIR. Doğrudan mevzuat hükmünü, evrak gereksinimini veya sistem sayfasını söyle. En fazla 2-3 kısa cümle.
2. SİSTEM İÇİ YÖNLENDİRME: Kullanıcının çözüme ulaşması için GümrükPilot içindeki doğru ekrana gitmesini sağla.
   - 'expert-audit': GTİP ve vergi için yapay zeka ön değerlendirmesi (resmi kaynaktan doğrulanmamıştır).
   - 'docs': Ticari Fatura (Commercial Invoice), Çeki Listesi (Packing List), A.TR, EUR.1, Menşe belgesi.
   - 'pallet': Paletleme (EUR-1/EUR-2), CBM hesaplama, TIR (33 palet) veya Konteyner (40' HC 25 palet) yükleme.
   - 'cost': Navlun, FOB/CIF, sigorta, gümrük müşaviri masrafı, kâr marjı ihracat maliyet hesabı.
   - 'shipments': Sevkiyat takibi, VEDOP kapanışı, 180 GÜNLÜK İBKB ihracat bedeli yurda getirme ve TCMB bozdurma takibi.
   - 'customs': Gümrük rejimleri, beyanname hazırlığı, gümrük müşaviri vekaleti, ihracat kontrolleri.
   - 'roadmap': Sıfırdan Adım Adım İhracat Rehberi.
   - 'mistakes': En Sık Yapılan 10 İhracat Hatası ve İdari Para Cezaları.
   - 'exchange': TCMB Canlı Kurları & Çapraz Kur Hesaplayıcı.
   - 'sync': Veri yedekleme: JSON dosyası olarak dışa/içe aktarma ve ekiple dosya paylaşımı (bulut senkronu yoktur).
3. SİSTEM DIŞI SORULARI REDDET: Kullanıcı dış ticaret, gümrük, lojistik, kambiyo mevzuatı ve GümrükPilot haricinde bir soru sorarsa (örneğin hava durumu, yemek tarifi, genel sohbet, felsefe, kodlama, spor vb.):
   - 'is_out_of_scope': true yap.
   - 'reply': "Bu asistan yalnızca GümrükPilot sistemi, uluslararası dış ticaret mevzuatı (4458 G.K.), gümrük evrakları ve sevkiyat operasyonları için yapılandırılmıştır. Kapsam dışı sorulara yanıt verilememektedir."
   - 'suggested_screen': null yap, 'quick_options' boş dizi döndür.
4. ŞIKLARLA TEŞHİS (QUICK OPTIONS):
   - Eğer kullanıcı "Almanya'ya mal göndermek istiyorum" gibi genel bir ülke veya hedef belirtirse; ürünün cinsini sormak için 'quick_options' listesine 3-5 tane doğrudan tıklanabilir ürün kategorisi ekle.`;

// Known non-customs trigger patterns for instant out-of-scope filtering
const NON_CUSTOMS_KEYWORDS = [
  'makarna', 'tarif', 'yemek', 'hava nasıl', 'felsefe', 'futbol', 'maç',
  'şarkı', 'film', 'dizi', 'fıkra', 'espri', 'aşk', 'burç', 'hava durumu',
  'python', 'javascript yaz', 'react kodu yaz', 'sen kimsin', 'nasılsın'
];

function evaluateDeterministicCustomsRule(prompt: string): CopilotResponse {
  const lower = prompt.toLowerCase();

  // 1. Check for explicit out-of-scope triggers
  const isOutOfScope = NON_CUSTOMS_KEYWORDS.some(kw => lower.includes(kw));
  if (isOutOfScope) {
    return {
      reply: 'Bu asistan yalnızca GümrükPilot sistemi, uluslararası dış ticaret mevzuatı (4458 G.K.), gümrük evrakları ve sevkiyat operasyonları için yapılandırılmıştır. Kapsam dışı sorulara yanıt verilememektedir.',
      suggested_screen: null,
      suggested_action_label: null,
      quick_options: [],
      is_out_of_scope: true
    };
  }

  // 2. Germany & EU Intent (Detailed category diagnosis)
  if (lower.includes('alman') || lower.includes('ab') || lower.includes('avrupa')) {
    // If specific category is mentioned
    if (lower.includes('tekstil') || lower.includes('giyim') || lower.includes('tişört') || lower.includes('konfeksiyon')) {
      return {
        reply: 'Almanya’ya tekstil ve konfeksiyon ihracatında (Fasıl 61-63) 1/95 OKK uyarınca A.TR Dolaşım Belgesi ile gümrük vergisi %0’dır. Almanya ithalat KDV oranı %19’dur; REACH ve azo boyar test raporları hazır bulundurulmalıdır.',
        suggested_screen: 'expert-audit',
        suggested_action_label: 'Tekstil GTİP (6109.10) Denetimini Aç',
        quick_options: [
          { label: '📄 Fatura & Çeki Listesi Hazırla', payload: 'Tekstil ihracat faturası ve çeki listesi' },
          { label: '📦 Koli & Euro Palet Planla', payload: 'Tekstil koli ve paletleme hesabı' }
        ],
        is_out_of_scope: false
      };
    }

    if (lower.includes('makine') || lower.includes('sanayi') || lower.includes('yedek parça') || lower.includes('metal')) {
      return {
        reply: 'Almanya’ya makine ve sanayi ihracatında (Fasıl 84-85) A.TR belgesi ile gümrük vergisi %0 uygulanır. 2006/42/EC Makine Emniyeti Yönetmeliği gereği CE işareti ve AB Uygunluk Beyanı (DoC) zorunludur.',
        suggested_screen: 'expert-audit',
        suggested_action_label: 'Makine GTİP Denetimini Aç',
        quick_options: [
          { label: '📄 Commercial Invoice & Packing List', payload: 'Makine faturası ve çeki listesi oluştur' },
          { label: '📦 TIR (13.60m) Yükleme Planı', payload: 'TIR palet kapasitesi hesabı' }
        ],
        is_out_of_scope: false
      };
    }

    if (lower.includes('gıda') || lower.includes('tarım') || lower.includes('meyve') || lower.includes('zeytin')) {
      return {
        reply: 'DİKKAT: Gıda ve tarım ürünlerinde (Fasıl 01-24) A.TR DOLAŞIM BELGESİ GEÇERSİZDİR. İndirimli tarife için EUR.1 Dolaşım Belgesi ve Tarım ve Orman Bakanlığı onaylı Bitki/Hayvan Sağlık Sertifikası zorunludur.',
        suggested_screen: 'expert-audit',
        suggested_action_label: 'Gıda GTİP & Sağlık Şartlarını İncele',
        quick_options: [
          { label: '📄 Sağlık Sertifikası & Evraklar', payload: 'Gıda ihracat evrakları ve fatura' },
          { label: '🔍 AB TARIC Veritabanı Kontrolü', payload: 'AB gıda vergileri TARIC sorgusu' }
        ],
        is_out_of_scope: false
      };
    }

    // General Germany intent -> Ask for product category with instant clickable chips
    return {
      reply: 'Almanya ve AB ülkelerine ihracatta gümrük tarifesi ve zorunlu belgeler ürün grubuna göre farklılaşır. Doğru mevzuat ve vergi tespiti için lütfen ürün grubunuzu seçiniz:',
      suggested_screen: 'expert-audit',
      suggested_action_label: 'GTİP & Tarife Masasını Aç',
      quick_options: [
        { label: '👕 Tekstil & Giyim (Fasıl 61-63)', payload: 'Almanya tekstil ihracatı kuralları' },
        { label: '⚙️ Makine & Sanayi (Fasıl 84-85)', payload: 'Almanya makine ihracatı A.TR belgesi' },
        { label: '🫒 Gıda & Tarım (Fasıl 01-24)', payload: 'Almanya gıda ihracatı kuralları EUR.1' },
        { label: '🧴 Kimya & Kozmetik (Fasıl 33-38)', payload: 'Almanya kozmetik ihracatı CPNP' },
        { label: '📦 Genel Kargo / Diğer', payload: 'Almanya genel kargo ihracatı' }
      ],
      is_out_of_scope: false
    };
  }

  // 3. Commercial Documents (Fatura, Çeki Listesi, A.TR, EUR.1)
  if (lower.includes('fatura') || lower.includes('çeki') || lower.includes('packing') || lower.includes('invoice') || lower.includes('evrak') || lower.includes('belge')) {
    return {
      reply: 'İhracat gümrük beyannamesi için İngilizce Ticari Fatura (Commercial Invoice) ve Koli/Palet bazlı Çeki Listesi (Packing List) zorunludur. Sistemimizden tek tıkla resmi PDF/Baskı formatında üretebilirsiniz.',
      suggested_screen: 'docs',
      suggested_action_label: 'Fatura & Çeki Listesi Oluşturucuya Git',
      quick_options: [
        { label: '📄 Ticari Fatura Şablonu Aç', payload: 'Yeni ihracat faturası oluştur' },
        { label: '📦 Çeki Listesi (Koli/Palet) Hazırla', payload: 'Çeki listesi hazırla' },
        { label: '🔍 GTİP Denetimine Geç', payload: 'GTİP denetimi yap' }
      ],
      is_out_of_scope: false
    };
  }

  // 4. Repatriation (180 gün, İBKB, bedel, kambiyo)
  if (lower.includes('180') || lower.includes('ibkb') || lower.includes('bedel') || lower.includes('kambiyo') || lower.includes('para') || lower.includes('bozdur')) {
    return {
      reply: 'Türk Parası Kıymetini Koruma Hakkında 32 Sayılı Karar uyarınca, fiili ihraç tarihinden itibaren ihracat bedellerinin 180 gün içinde yurda getirilmesi ve İBKB (İhracat Bedeli Kabul Belgesi) bağlanması zorunludur. Belirlenen TCMB bozdurma oranı bankaca tahsil edilir.',
      suggested_screen: 'shipments',
      suggested_action_label: '180 Günlük İBKB Bedel Takibini Aç',
      quick_options: [
        { label: '⏱️ Kalan Süre Sayacını Aç', payload: '180 gün kalan süre takibi' },
        { label: '💱 TCMB Canlı Kurlarını İncele', payload: 'TCMB kurları döviz bozdurma' }
      ],
      is_out_of_scope: false
    };
  }

  // 5. Pallet, CBM & Logistics
  if (lower.includes('palet') || lower.includes('cbm') || lower.includes('konteyner') || lower.includes('tir') || lower.includes('hacim') || lower.includes('koli')) {
    return {
      reply: 'Standart 13.60m TIR 33 Euro Palet (EUR 1: 120x80cm), 40\' High Cube Konteyner ise 25 Euro Palet alır. Koli ölçülerini girerek CBM ve araç doluluk oranını anında simüle edebilirsiniz.',
      suggested_screen: 'pallet',
      suggested_action_label: 'Palet & CBM Hesaplayıcıyı Aç',
      quick_options: [
        { label: '🚚 13.60m Standart TIR Simülasyonu', payload: 'TIR palet hesaplama' },
        { label: '🚢 40\' HC Konteyner Simülasyonu', payload: 'Konteyner CBM hesaplama' }
      ],
      is_out_of_scope: false
    };
  }

  // 6. Cost & Incoterms (FOB, CIF, navlun, kâr)
  if (lower.includes('maliyet') || lower.includes('fob') || lower.includes('cif') || lower.includes('fiyat') || lower.includes('navlun') || lower.includes('incoterm')) {
    return {
      reply: 'İhracat birim fiyatınızı belirlerken fabrika çıkış maliyeti (EXW), iç nakliye, liman/gümrük masrafları ve hedef kâr marjını hesaplayarak FOB ve CIF teklif fiyatı çıkarabilirsiniz.',
      suggested_screen: 'cost',
      suggested_action_label: 'İhracat Maliyet Masasına Git',
      quick_options: [
        { label: '💰 FOB / CIF Fiyat Simülasyonu', payload: 'FOB ve CIF ihracat fiyatı hesapla' },
        { label: '📄 Fatura Modülüne Aktar', payload: 'Maliyeti faturaya aktar' }
      ],
      is_out_of_scope: false
    };
  }

  // 7. General Foreign Trade inquiry
  return {
    reply: 'GümrükPilot Dış Ticaret Uyum Sisteminde talebiniz için resmi modüller hazırdır. Lütfen yapmak istediğiniz işlemi seçiniz:',
    suggested_screen: 'expert-audit',
    suggested_action_label: 'GTİP & Tarife Masasını Aç',
    quick_options: [
      { label: '🇩🇪 Almanya / AB İhracatı', payload: 'Almanya ihracatı kuralları' },
      { label: '📄 Fatura & Çeki Listesi', payload: 'Fatura ve çeki listesi hazırla' },
      { label: '🔍 GTİP Ön Değerlendirme', payload: 'GTİP doğrulama yap' },
      { label: '💰 180 Günlük İBKB Takibi', payload: '180 günlük İBKB bedel kuralı' }
    ],
    is_out_of_scope: false
  };
}

export async function askCustomsCopilot(
  userPrompt: string,
  history: Array<{ role: 'user' | 'model'; text: string }> = []
): Promise<CopilotResponse> {
  const prompt = userPrompt?.trim();
  if (!prompt) {
    return {
      reply: 'Lütfen gümrük, sevkiyat veya sistem işlemiyle ilgili talebinizi belirtin.',
      suggested_screen: null,
      suggested_action_label: null,
      quick_options: [
        { label: '🇩🇪 Almanya / AB İhracatı', payload: 'Almanya ihracatı yapmak istiyorum' },
        { label: '📄 Fatura & Çeki Listesi', payload: 'Fatura ve çeki listesi hazırlamak istiyorum' },
        { label: '🔍 GTİP & Vergi Denetimi', payload: 'GTİP ve vergi oranlarını denetlemek istiyorum' },
        { label: '💰 180 Günlük İBKB Bedel Kuralı', payload: '180 günlük ihracat bedeli ve İBKB kuralı nedir?' }
      ],
      is_out_of_scope: false
    };
  }

  // Instant out-of-scope filter before external call
  const lower = prompt.toLowerCase();
  if (NON_CUSTOMS_KEYWORDS.some(kw => lower.includes(kw))) {
    return {
      reply: 'Bu asistan yalnızca GümrükPilot sistemi, uluslararası dış ticaret mevzuatı (4458 G.K.), gümrük evrakları ve sevkiyat operasyonları için yapılandırılmıştır. Kapsam dışı sorulara yanıt verilememektedir.',
      suggested_screen: null,
      suggested_action_label: null,
      quick_options: [],
      is_out_of_scope: true
    };
  }

  // If Gemini API Key is configured, use Gemini
  if (process.env.GEMINI_API_KEY) {
    try {
      const formattedHistory = history.slice(-4).map(h => `${h.role === 'user' ? 'Kullanıcı' : 'Asistan'}: ${h.text}`).join('\n');
      const fullUserText = formattedHistory ? `Önceki Bağlam:\n${formattedHistory}\n\nYeni Kullanıcı Talebi:\n${prompt}` : prompt;

      const response = await aiStudio.models.generateContent({
        model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
        contents: fullUserText,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: { type: Type.STRING },
              suggested_screen: {
                type: Type.STRING,
                enum: [
                  'expert-audit',
                  'docs',
                  'pallet',
                  'cost',
                  'customs',
                  'roadmap',
                  'mistakes',
                  'shipments',
                  'exchange',
                  'sync',
                  'null'
                ]
              },
              suggested_action_label: { type: Type.STRING },
              quick_options: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    label: { type: Type.STRING },
                    payload: { type: Type.STRING }
                  },
                  required: ['label', 'payload']
                }
              },
              is_out_of_scope: { type: Type.BOOLEAN }
            },
            required: ['reply', 'quick_options', 'is_out_of_scope']
          }
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      const screenVal = parsed.suggested_screen === 'null' || !parsed.suggested_screen ? null : parsed.suggested_screen;

      return {
        reply: parsed.reply || 'İşleminiz için ilgili modül aşağıda listelenmiştir.',
        suggested_screen: screenVal,
        suggested_action_label: parsed.suggested_action_label || (screenVal ? 'İlgili Sayfayı Aç' : null),
        quick_options: Array.isArray(parsed.quick_options) ? parsed.quick_options : [],
        is_out_of_scope: Boolean(parsed.is_out_of_scope)
      };
    } catch (err: any) {
      console.warn('[Copilot AI Error, falling back to deterministic engine]:', err?.message || err);
    }
  }

  // Robust deterministic fallback engine
  return evaluateDeterministicCustomsRule(prompt);
}
