import express from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import { auditAndVerifyTariff, InputError } from './server/customsAudit.js';
import { askCustomsCopilot } from './server/copilotService.js';
import { handleLicenseBody } from './server/license.js';
import { lookupOfficial } from './server/officialSources.js';

/**
 * PRODUCTION-GRADE SERVER
 * This server is designed to handle both development (via Vite) and production (serving built assets).
 * It includes robust logging and health checks for Cloud Run deployment.
 */

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // 1. Basic Security & Logging & JSON Body Parsing
  app.set('trust proxy', 1);
  if (process.env.ALLOWED_ORIGIN) app.use(cors({ origin: process.env.ALLOWED_ORIGIN.split(',') }));
  app.use(express.json({ limit: '20kb' }));

  // AI uç noktaları için istek sınırı (IP başına dakikada 15, instance başına günde 1500)
  const hits = new Map<string, { n: number; reset: number }>();
  let dayCount = 0;
  let dayReset = Date.now() + 86400000;
  const aiLimiter: express.RequestHandler = (req, res, next) => {
    const now = Date.now();
    if (now > dayReset) { dayCount = 0; dayReset = now + 86400000; }
    if (++dayCount > 1500) return res.status(429).json({ error: 'Günlük AI kullanım sınırına ulaşıldı.' });
    const ip = req.ip || 'unknown';
    const h = hits.get(ip);
    if (!h || now > h.reset) { hits.set(ip, { n: 1, reset: now + 60000 }); return next(); }
    if (++h.n > 15) return res.status(429).json({ error: 'Çok fazla istek. Bir dakika sonra tekrar deneyin.' });
    next();
  };
  app.use('/api/customs', aiLimiter);
  app.use('/api/license', aiLimiter);
  app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
  });

  // 2. Customs Tariff AI Verification Endpoint (uzman tablosu, yoksa Gemini ön tahmini)
  app.post('/api/customs/verify', async (req, res) => {
    try {
      const hsCode = req.body?.hsCode as string;
      const targetCountry = (req.body?.targetCountry as string) || 'Almanya';
      const localDescription = req.body?.localDescription as string;
      const forceRefresh = false;

      if (!hsCode) {
        return res.status(400).json({ error: 'hsCode parametresi zorunludur (Örn: 847130 veya 8471.30.00.00.00).' });
      }

      const result = await auditAndVerifyTariff({
        hsCode: String(hsCode),
        targetCountry: String(targetCountry),
        localDescription: localDescription ? String(localDescription) : undefined,
        forceRefresh,
      });

      return res.status(200).json(result);
    } catch (error: any) {
      if (error instanceof InputError) return res.status(400).json({ error: error.message });
    if (error?.message === 'AI_QUOTA') return res.status(429).json({ error: 'Ücretsiz yapay zeka kotası doldu. Bir süre sonra tekrar deneyin.' });
      if (error?.message === 'AI_NOT_CONFIGURED') return res.status(503).json({ error: 'AI servisi bu sunucuda yapılandırılmamış.' });
      console.error('[API /api/customs/verify] Error:', error);
      return res.status(500).json({ error: 'Ön değerlendirme sırasında teknik bir hata oluştu.' });
    }
  });

  // Resmî kaynaklar: ABD HTS oranı + UN Comtrade pazar büyüklüğü
  app.get('/api/market', async (req, res) => {
    const r = await lookupOfficial(String(req.query.hs ?? ''), String(req.query.country ?? ''));
    if (!r.ok) return res.status(400).json({ error: r.error });
    return res.json(r);
  });

  // Lisans: {key} -> imzalı token, {token} -> doğrulama
  app.post('/api/license/verify', (req, res) => {
    const { status, json } = handleLicenseBody(req.body);
    return res.status(status).json(json);
  });

  // 4. Customs Copilot & In-App Navigator (Strict customs expertise & routing)
  app.post('/api/customs/copilot', async (req, res) => {
    try {
      const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.slice(0, 500) : '';
      const history = Array.isArray(req.body?.history)
        ? req.body.history.slice(-6).map((h: any) => ({
            role: h?.role === 'model' ? 'model' : 'user',
            text: String(h?.text ?? '').slice(0, 500),
          }))
        : [];
      const result = await askCustomsCopilot(prompt, history);
      return res.json(result);
    } catch (err: any) {
      console.error('[API /api/customs/copilot] Error:', err);
      return res.status(500).json({
        reply: 'Gümrük rehber servisinde geçici bir gecikme oluştu. Lütfen sol menüden ilgili sayfayı doğrudan seçiniz.',
        suggested_screen: null,
        suggested_action_label: null,
        quick_options: [],
        is_out_of_scope: false
      });
    }
  });

  // 4. TCMB Proxy (to avoid CORS in browser)
  app.get('/api/tcmb', async (_req, res) => {
    try {
      const response = await fetch('https://www.tcmb.gov.tr/kurlar/today.xml', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/xml, text/xml, */*',
        },
      });
      if (!response.ok) return res.status(response.status).json({ error: `TCMB returned ${response.status}` });
      const xmlText = await response.text();
      res.setHeader('Content-Type', 'application/xml; charset=utf-8');
      return res.send(xmlText);
    } catch (err: any) {
      return res.status(502).json({ error: 'Proxy failed', details: err.message });
    }
  });

  // 3. Health Check (Crucial for Cloud Run)
  app.get('/api/health', (req, res) => {
    const distPath = path.join(process.cwd(), 'dist');
    res.json({
      status: 'ok',
      time: new Date().toISOString(),
      distExists: fs.existsSync(distPath),
      indexExists: fs.existsSync(path.join(distPath, 'index.html'))
    });
  });

  // 4. Mode Selection (Dev vs Prod)
  const isDev = process.env.NODE_ENV === 'development';
  const isProd = !isDev;
  const distPath = path.join(process.cwd(), 'dist');
  
  console.log(`[Server] Environment: ${process.env.NODE_ENV || 'not set'} (Mode: ${isDev ? 'DEV' : 'PROD'})`);

  if (isDev) {
    console.log('[Server] Starting in DEVELOPMENT mode (Vite Middleware)');
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    console.log(`[Server] Starting in PRODUCTION mode. Serving: ${distPath}`);
    
    // Serve assets with aggressive caching
    app.use('/assets', express.static(path.join(distPath, 'assets'), {
      maxAge: '1y',
      immutable: true,
      fallthrough: false
    }));

    // Serve other static files
    app.use(express.static(distPath, { index: false }));

    // SPA Fallback
    app.get('*', (req, res) => {
      const indexPath = path.join(distPath, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Application build not found. Please run "npm run build".');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Listening on 0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[Server] Fatal Error:', err);
  process.exit(1);
});
