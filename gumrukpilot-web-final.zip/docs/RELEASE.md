# Yayın kontrol listesi
1. `npm install && npm test && npm run lint` temiz.
2. Vercel'de `GEMINI_API_KEY`, `LICENSE_KEYS`, `LICENSE_SECRET` tanımlı.
3. Canlıda: lisans aktivasyonu, `/api/health`, GTİP ön değerlendirme, PDF indirme elle denendi.
4. Rapor/arayüzde "uzman onaylı" ifadesi yalnızca gerçek uzman imzası varsa kullanılır.
