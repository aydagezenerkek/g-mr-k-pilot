# GümrükPilot – Kapsamlı Test Planı (TR)

Bu doküman, GümrükPilot uygulamasının gümrük, palet optimizasyonu, maliyet, kambiyo (İBKB) ve dokümantasyon modüllerinin doğrulama senaryolarını içerir.

---

## 1. Birim Testler (Unit Tests)

### 1.1 Sevkiyat & İBKB 180 Gün Testleri (`ProceedsTrackerTest.kt`)
- [x] İhracat tarihinden itibaren 180 günlük kesin sürenin hesaplanması (`calculateDeadline`)
- [x] 30.000 USD veya muadili altındaki ihracatlarda otomatik terkin muafiyetinin doğrulanması (`isExempt`)
- [x] Kalan gün sayısına göre durum geçişleri: Süre İçinde (OK), Kritik Süre (Son 30 gün - WARNING), Süresi Geçti (OVERDUE)
- [x] Bankadan İBKB alındığında durumun doğrudan `CLOSED` olarak güncellenmesi

### 1.2 Ağırlık ve Dara Testleri (`InvoiceTareTest.kt`)
- [x] Net ağırlık ve brüt ağırlık arasındaki farkın (dara) doğru hesaplanması (`tare = gross - net`)
- [x] Brüt ağırlığın her zaman net ağırlıktan büyük veya eşit olmasının zorunlu tutulması
- [x] Palet darasının (Euro palet 25 kg vb.) toplam gönderi darasına eklenmesi

### 1.3 Dış Ticaret & Gümrük Mevzuat Ekstraları (`ComplianceExtrasTest.kt`)
- [x] Mikro İhracat (ETGB) kriteri: Ağırlık ≤ 300 kg ve değer ≤ 15.000 EUR uygunluğu
- [x] Ahşap ambalaj ve paletlerde ISPM-15 ısıl işlem zorunluluğu doğrulaması
- [x] AB'ye giden tarım ve gıda ürünlerinde A.TR yerine EUR.1 zorunluluğu
- [x] Yüksek teknolojili elektronik ve kimyasallarda çift kullanımlı (Dual-Use) eşya kontrol uyarısı

### 1.4 Gümrük Hazırlığı ve GTİP Testleri (`HsGuideTest.kt` & `CustomsPrepEngineTest.kt`)
- [x] Tüm örnek GTİP'lerin 6 haneli ve rakamlardan oluşması
- [x] GTİP fasıllarının sektör/kategori ile eşleşmesi
- [x] Lityum pillerde UN 38.3 test özetinin "DURDURUCU (BLOCKER)" olarak tetiklenmesi
- [x] Kimyasallarda 16 maddelik MSDS/SDS belgesi zorunluluğu

---

## 2. Entegrasyon ve UI Testleri

### 2.1 Paletleme Motoru
- Koli ölçüleri (U x G x Y) ve ağırlığı girildiğinde Euro ve Endüstriyel palet katman ve toplam palet sayısının matematiksel doğruluğu.
- TIR (33 palet) ve 40' HC (25 palet) araç doluluk yüzdelerinin hesaplanması.

### 2.2 Ticari Fatura (Commercial Invoice) & PDF Çıktısı
- İhracatçı ve ithalatçı unvan, adres, vergi ve EORI numaralarının fatura şablonuna doğru yerleşmesi.
- Incoterm (DAP, FOB, DDP vb.) ve para birimi sembollerinin tutarlılığı.
- A4 formatında temiz ve baskıya uygun PDF çıktısı alınması.

### 2.3 Yerel Yedekleme & Geri Yükleme
- Sevkiyat ve fatura verilerinin şifresiz JSON formatında dışa aktarılması.
- Yedekten geri yükleme yapıldığında mevcut kayıtların korunarak birleştirilmesi (merge).
