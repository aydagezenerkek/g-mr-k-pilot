# GümrükPilot – Yetkili Gümrük Müşaviri & Dış Ticaret Kontrol Listesi

Bu kılavuz, ihracat operasyonlarında gümrük tescili öncesi, sevk anı ve sonrasında yapılması gereken yasal, operasyonel ve mevzuatsal kontrolleri içerir.

---

## 1. İhracat Öncesi Evrak ve Belge Kontrolleri

- [ ] **İngilizce Ticari Fatura (Commercial Invoice):**
  - İhracatçı ve ithalatçı tam unvan, adres ve vergi/EORI numaraları eksiksiz mi?
  - Fatura tarihi ve benzersiz fatura numarası mevcut mu?
  - Doğru teslim şekli (**Incoterms 2020: EXW, FOB, CIF, DAP, DDP vb.**) belirtilmiş mi?
  - Döviz cinsi (EUR, USD, GBP vb.) ve birim/toplam fiyatlar tutarlı mı?
- [ ] **Çeki Listesi (Packing List):**
  - Koli/palet adetleri, kap numaralandırması yapılmış mı?
  - Her kalemin **Net Ağırlığı** ve ambalaj dahil **Brüt Ağırlığı** faturayla birebir uyumlu mu?
  - Dara (Tare = Brüt - Net) makul mü?
- [ ] **Dolaşım ve Menşe İspat Belgeleri:**
  - **Avrupa Birliği (AB):** Sanayi ürünleri için **A.TR Dolaşım Belgesi** düzenlendi mi?
  - **İstisna:** AB'ye giden işlenmiş tarım, gıda veya AKÇT demir-çelik ürünlerinde A.TR değil **EUR.1 / EUR-MED** düzenlendi mi?
  - **Birleşik Krallık (BK / UK):** STA gereğince **EUR.1 veya Menşe Beyanı** mevcut mu?
  - **Azerbaycan / Diğer STA Ülkeleri:** Tercihli ticaret belgesi (**EUR.1 / CT-1**) hazır mı?
  - **3. Ülkeler (ABD, Çin, Körfez vb.):** Ticaret Odası onaylı **Menşe Şahadetnamesi (Certificate of Origin)** hazırlandı mı?

---

## 2. GTİP ve Ürün Güvenliği Denetimleri

- [ ] **GTİP / HS Code Teyidi:**
  - Türk Gümrük Tarife Cetveli'ne göre 12 haneli GTİP doğru tespit edildi mi?
  - Varış ülkesinin 8-10 haneli yerel tarife kodu ile çapraz kontrol yapıldı mı?
- [ ] **Özel İzin ve Ürün Mevzuatı:**
  - **Lityum Piller / Bataryalı Eşya:** IATA/ADR kapsamında geçerli **UN 38.3 Test Özeti** var mı?
  - **Kimyasallar & Boya:** 16 maddelik onaylı İngilizce **MSDS / SDS (Güvenlik Bilgi Formu)** mevcut mu?
  - **Gıda ve Tarım:** Tarım ve Orman Bakanlığı onaylı resmi **Sağlık/Bitki Karantina Sertifikası (Phytosanitary)** alındı mı?
  - **Tekstil & Hazır Giyim:** Ürün üzerinde silinmez elyaf kompozisyonu ve 'Made in Turkiye' etiketi var mı?
  - **Tıbbi Cihazlar:** CE, DoC ve MDR mevzuat onayları tamamlandı mı?
  - **Çift Kullanımlı Eşya (Dual-Use):** Hassas makine ve çiplerde İhracat Genel Müdürlüğü ön izni gerekiyor mu?

---

## 3. Lojistik, Ambalaj ve Yükleme Standartları

- [ ] **ISPM-15 Ahşap Ambalaj Standardı:**
  - Sevkiyatta kullanılan ahşap palet, sandık ve takozlarda uluslararası **ISPM-15 Isıl İşlem (HT)** damgası var mı?
- [ ] **Taşıma Belgesi (CMR / Bill of Lading / AWB):**
  - Gönderici, alıcı, ihbar adresi (Notify), yükleme ve varış limanları faturayla uyumlu mu?
- [ ] **Mikro İhracat (ETGB) Uygunluğu:**
  - Brüt ağırlık ≤ 300 kg ve mal bedeli ≤ 15.000 EUR ise basitleştirilmiş ETGB ile çıkış planlandı mı?

---

## 4. Kambiyo ve İBKB (İhracat Bedeli Kabul Belgesi) Takibi

- [ ] **180 Gün Kuralı:**
  - Fiili ihraç tarihinden itibaren 180 gün içinde bedelin banka kanalıyla Türkiye'ye getirilmesi takip altına alındı mı?
- [ ] **TCMB Döviz Satış Zorunluluğu:**
  - Güncel genelge uyarınca bedelin zorunlu yüzdesi banka aracılığıyla TCMB'ye satıldı mı?
- [ ] **Terkin Muafiyeti:**
  - 30.000 USD veya altındaki ihracatlarda otomatik terkin muafiyeti kontrol edildi mi?

---
*GümrükPilot Lojistik & Gümrük İşletim Sistemi tarafından oluşturulmuştur.*
