import { describe, it, expect, beforeEach } from 'vitest';
import {
  CatalogProduct,
  INITIAL_CATALOG_PRODUCTS,
  loadCatalogFromStorage,
  saveCatalogToStorage
} from './catalog';

// Mock localStorage for node environment
class MockLocalStorage implements Storage {
  private store: Record<string, string> = {};
  get length(): number {
    return Object.keys(this.store).length;
  }
  clear(): void {
    this.store = {};
  }
  getItem(key: string): string | null {
    return this.store[key] ?? null;
  }
  key(index: number): string | null {
    return Object.keys(this.store)[index] ?? null;
  }
  removeItem(key: string): void {
    delete this.store[key];
  }
  setItem(key: string, value: string): void {
    this.store[key] = String(value);
  }
}

describe('Product Catalog (src/core/catalog.ts)', () => {
  let mockStorage: MockLocalStorage;

  beforeEach(() => {
    mockStorage = new MockLocalStorage();
  });

  it('should return initial products when storage is empty', () => {
    const products = loadCatalogFromStorage(mockStorage);
    expect(products.length).toBeGreaterThanOrEqual(4);
    expect(products[0].name).toBe('Endüstriyel Otomasyon Sensörleri');
    expect(products[0].hsCode).toBe('8471.30.00.00.00');
  });

  it('should save and load updated product catalog from storage', () => {
    const newProduct: CatalogProduct = {
      id: 'test-1',
      name: 'Test Ürün',
      hsCode: '1234.56.78.90.12',
      category: 'ELECTRONICS',
      unitPrice: 150,
      currency: 'EUR',
      unit: 'PCS',
      createdAt: '2026-11-04'
    };

    saveCatalogToStorage([newProduct], mockStorage);
    const loaded = loadCatalogFromStorage(mockStorage);

    expect(loaded.length).toBe(1);
    expect(loaded[0].name).toBe('Test Ürün');
    expect(loaded[0].unitPrice).toBe(150);
  });

  it('should handle corrupted JSON in storage gracefully', () => {
    mockStorage.setItem('customspilot_product_catalog', 'invalid-json{{{');
    const loaded = loadCatalogFromStorage(mockStorage);
    expect(loaded).toEqual(INITIAL_CATALOG_PRODUCTS);
  });
});
