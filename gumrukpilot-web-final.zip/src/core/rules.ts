import { Country, getCountryByCode, TradeRegime } from './countries';
import { PAYMENT_METHODS } from './paymentMethods';

export const DATA_VERIFIED_ON = '2026-11-04';

export type Severity = 'BLOCKER' | 'REQUIRED' | 'WARNING' | 'TIP';

export const PRODUCT_CATEGORIES = [
  'FOOD', 'TEXTILE', 'CLOTHING', 'ELECTRONICS', 'MACHINERY',
  'CHEMICALS', 'COSMETICS', 'MEDICAL', 'PLANT_ANIMAL', 'OTHER',
] as const;
export type ProductCategory = typeof PRODUCT_CATEGORIES[number];

export interface ChecklistItem {
  id: string;
  title: string;
  titleEn?: string;
  detail: string;
  detailEn?: string;
  severity: Severity;
  sourceUrl?: string;
}

export interface ChecklistSection {
  title: string;
  titleEn?: string;
  items: ChecklistItem[];
}

export interface ChecklistResult {
  country: Country;
  category: ProductCategory;
  sections: ChecklistSection[];
  dataVerifiedOn: string;
}

export interface ChecklistOptions {
  declaredValue?: number;
  isSample?: boolean;
  hasLithiumBattery?: boolean;
  incoterm?: 'EXW' | 'FOB' | 'CIF' | 'CIP' | 'DAP' | 'DDP';
  paymentMethodId?: string;
}

export const buildChecklist = (
  countryCode: string,
  category: ProductCategory,
  options: ChecklistOptions = {}
): ChecklistResult => {
  const country = getCountryByCode(countryCode);
  const sections: ChecklistSection[] = [];

  // ==========================================
  // 1. Gerekli Belgeler (Required Documents)
  // ==========================================
  const docItems: ChecklistItem[] = [
    {
      id: 'doc_commercial_invoice',
      title: 'İngilizce Ticari Fatura (Commercial Invoice)',
      titleEn: 'Commercial Invoice',
      detail: 'Faturada satıcı/alıcı tam unvanı, açık adres, vergi/EORI numarası, GTİP kodu, Incoterm teslim şekli, birim fiyat ve döviz cinsi eksiksiz yer almalıdır.',
      detailEn: 'Must include full legal names of exporter/consignee, exact address, VAT/EORI number, HS code, Incoterms rule, unit prices, and currency.',
      severity: 'BLOCKER',
      sourceUrl: 'https://ticaret.gov.tr/ihracat/mevzuat'
    },
    {
      id: 'doc_packing_list',
      title: 'Çeki Listesi (Packing List)',
      titleEn: 'Packing List',
      detail: 'Her bir koli/paletin net ve brüt ağırlığı, boyutları ve içindeki ürün adedi faturadaki kalemlerle birebir uyumlu olmalıdır.',
      detailEn: 'Net and gross weights, dimensions, and item quantities for each box/pallet must match the invoice items exactly.',
      severity: 'BLOCKER',
      sourceUrl: 'https://ticaret.gov.tr/ihracat/mevzuat'
    }
  ];

  if (country.tradeRegime === 'CUSTOMS_UNION') {
    if (category === 'FOOD' || category === 'PLANT_ANIMAL') {
      docItems.push({
        id: 'doc_eur1_agri',
        title: 'EUR.1 Dolaşım Belgesi (Tarım Ürünü İstisnası)',
        titleEn: 'EUR.1 Certificate (Agricultural Product Exception)',
        detail: 'Gıda, tarım ve işlenmiş tarım ürünleri AB Gümrük Birliği (A.TR) kapsamı dışındadır; tercihli vergi için EUR.1 / Menşe İspat Belgesi gereklidir.',
        detailEn: 'Processed food, agricultural, and ECSC products are outside the Turkey-EU Customs Union scope (A.TR); an EUR.1 is required for preferential duty rates.',
        severity: 'REQUIRED',
        sourceUrl: 'https://ticaret.gov.tr/dis-iliskiler/avrupa-birligi'
      });
    } else {
      docItems.push({
        id: 'doc_atr',
        title: 'A.TR Dolaşım Belgesi (Serbest Dolaşım)',
        titleEn: 'A.TR Movement Certificate (Free Circulation)',
        detail: 'Türkiye - AB Gümrük Birliği kapsamında sanayi mallarında gümrük vergisi muafiyeti (%0) sağlamak için A.TR düzenlenmelidir. (Önemli Hukuki Not: A.TR bir menşe belgesi değildir; eşyanın serbest dolaşım statüsünde olduğunu tevsik eder).',
        detailEn: 'An A.TR certificate must be issued to benefit from zero customs duty (0%) on industrial goods under the Turkey-EU Customs Union. (Legal Note: A.TR is not a certificate of origin; it certifies free circulation status).',
        severity: 'REQUIRED',
        sourceUrl: 'https://ticaret.gov.tr/dis-iliskiler/avrupa-birligi'
      });
    }
  } else if (country.tradeRegime === 'FREE_TRADE_AGREEMENT') {
    docItems.push({
      id: 'doc_eur1_sta',
      title: 'EUR.1 / EUR-MED veya Fatura Menşe Beyanı',
      titleEn: 'EUR.1 / EUR-MED or Invoice Origin Declaration',
      detail: `${country.nameTr} ile akdedilen Serbest Ticaret Anlaşması kapsamında tercihli sıfır/indirimli vergiden faydalanmak için Tercihli Menşe İspat Belgesi (EUR.1 / EUR-MED veya yetkili ihracatçı menşe beyanı) zorunludur.`,
      detailEn: `Under the Free Trade Agreement with ${country.nameEn}, Preferential Certificate of Origin (EUR.1, EUR-MED, or invoice origin declaration) is required for preferential duty reduction.`,
      severity: 'REQUIRED',
      sourceUrl: 'https://ticaret.gov.tr/dis-iliskiler/serbest-ticaret-anlasmalari'
    });
  } else {
    // MFN / 3. Ülke
    docItems.push({
      id: 'doc_coo',
      title: 'Menşe Şahadetnamesi (Certificate of Origin)',
      titleEn: 'Certificate of Origin',
      detail: 'Ürünün Türkiye menşeli olduğunu tevsik eden Ticaret/Sanayi Odası onaylı Menşe Şahadetnamesi sunulmalıdır.',
      detailEn: 'Chamber of Commerce approved Certificate of Origin certifying that the goods originate in Turkey must be presented.',
      severity: 'REQUIRED',
      sourceUrl: 'https://ticaret.gov.tr/ihracat/mevzuat'
    });
  }

  sections.push({
    title: 'Gerekli Belgeler',
    titleEn: 'Required Documents',
    items: docItems
  });

  // ==========================================
  // 2. Ürün ve Mevzuat Uyumluluğu (Product & Regulatory)
  // ==========================================
  const complianceItems: ChecklistItem[] = [];

  const isHighRiskDualUse = ['ELECTRONICS', 'CHEMICALS', 'MACHINERY'].includes(category);
  complianceItems.push({
    id: 'comp_sanctions_dualuse',
    title: 'Yaptırım & Dual-Use Kontrolü',
    titleEn: 'Sanctions & Dual-Use Screening',
    detail: isHighRiskDualUse
      ? 'Alıcı firmayı ve ürünü ihracat kontrolü/yaptırım listelerinden kontrol edin. AB Dual-Use Tüzüğü kapsamındaki ürünler ve BM/AB/ABD yaptırım listelerindeki taraflarla ticaret ayrı izin veya yasak gerektirebilir. (Önemli Vurgu: Elektronik, kimya ve makine ürünlerinde dual-use ve son kullanıcı denetimleri kritik önem taşır.)'
      : 'Alıcı firmayı ve ürünü ihracat kontrolü/yaptırım listelerinden kontrol edin. AB Dual-Use Tüzüğü kapsamındaki ürünler ve BM/AB/ABD yaptırım listelerindeki taraflarla ticaret ayrı izin veya yasak gerektirebilir.',
    detailEn: isHighRiskDualUse
      ? 'Screen the counterparty and item against export control and sanctions lists. Goods under EU Dual-Use regulations or sanctioned entities require special permits. (Crucial: Electronics, chemicals, and machinery require strict end-user checks.)'
      : 'Screen the counterparty and item against export control and sanctions lists. Goods covered by Dual-Use regulations or parties under UN/EU/US sanctions may require special authorization.',
    severity: 'WARNING',
    sourceUrl: 'https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32021R0821'
  });

  switch (category) {
    case 'TEXTILE':
    case 'CLOTHING':
      complianceItems.push({
        id: 'comp_textile_label',
        title: 'Tekstil Elyaf Kompozisyonu ve Menşe Etiketi',
        titleEn: 'Textile Fiber Composition & Origin Label',
        detail: 'Ürün üzerinde silinmez elyaf içerik oranı (%100 Pamuk, %50 Polyester vb.), bakım/yıkama talimatları ve "Made in Turkiye" menşe etiketi bulunmalıdır.',
        detailEn: 'Garments must feature permanent fiber composition ratios (e.g., 100% Cotton), care/wash instructions, and a "Made in Turkiye" origin label.',
        severity: 'REQUIRED',
        sourceUrl: 'https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32011R1007'
      });
      break;

    case 'ELECTRONICS':
      complianceItems.push({
        id: 'comp_ce_rohs',
        title: 'CE İşareti ve RoHS/WEEE Uygunluk Beyanı (DoC)',
        titleEn: 'CE Marking & RoHS/WEEE Declaration of Conformity',
        detail: 'Elektrikli ve elektronik ekipmanlarda CE işareti, LVD/EMC test raporları ve RoHS/WEEE direktiflerine uygunluk teknik dosyası zorunludur.',
        detailEn: 'Electrical and electronic equipment requires CE mark, LVD/EMC test reports, and technical compliance files under RoHS/WEEE directives.',
        severity: 'REQUIRED',
        sourceUrl: 'https://ec.europa.eu/growth/single-market/ce-marking_en'
      });
      // Lityum pil varsa UN 38.3 BLOCKER, default olarak da güvenlik kontrolü
      if (options.hasLithiumBattery !== false) {
        complianceItems.push({
          id: 'comp_battery_un383',
          title: 'Lityum Pil Taşıma Beyanı (UN 38.3 Test Özeti)',
          titleEn: 'Lithium Battery Transport Declaration (UN 38.3)',
          detail: 'Lityum iyon / polimer batarya içeren ürünlerde IATA-DGR / ADR uyarınca UN 38.3 Test Özeti olmadan hava veya kara yoluyla taşıma yapılamaz.',
          detailEn: 'Products containing lithium batteries cannot be transported by air or road without a UN 38.3 Test Summary pursuant to IATA-DGR / ADR.',
          severity: 'BLOCKER',
          sourceUrl: 'https://www.unece.org/trans/danger/danger.html'
        });
      }
      break;

    case 'MACHINERY':
      complianceItems.push({
        id: 'comp_machinery_ce',
        title: 'Makine Direktifi CE Beyanı ve Tip Onayı',
        titleEn: 'Machinery Directive CE Declaration & Type Approval',
        detail: '2006/42/EC Makine Emniyeti Yönetmeliği uyarınca CE Uygunluk Beyanı ve üretici AT Uygunluk Deklarasyonu zorunludur.',
        detailEn: 'CE Declaration of Conformity and manufacturer EC Declaration are mandatory under Directive 2006/42/EC on Machinery.',
        severity: 'REQUIRED',
        sourceUrl: 'https://ec.europa.eu/growth/sectors/mechanical-engineering/machinery_en'
      });
      break;

    case 'FOOD':
      complianceItems.push({
        id: 'comp_food_health',
        title: 'Resmi Sağlık ve Bitki/Karantina Sertifikası',
        titleEn: 'Official Health & Phytosanitary Certificate',
        detail: 'Tarım ve Orman Bakanlığı onaylı resmi Sağlık Sertifikası (Health/Phytosanitary Certificate) ve gıda analiz raporları gümrükten önce temin edilmelidir.',
        detailEn: 'Official Health/Phytosanitary Certificate and certified food lab analysis reports must be obtained prior to customs declaration.',
        severity: 'BLOCKER',
        sourceUrl: 'https://www.tarimorman.gov.tr'
      });
      break;

    case 'CHEMICALS':
      complianceItems.push({
        id: 'comp_chem_msds',
        title: 'MSDS (Malzeme Güvenlik Bilgi Formu)',
        titleEn: 'SDS / MSDS (Safety Data Sheet)',
        detail: 'İngilizce dilinde, güncel 16 maddelik onaylı Güvenlik Bilgi Formu (SDS/MSDS) ve REACH / CLP uyumluluk deklarasyonu zorunludur.',
        detailEn: 'Up-to-date 16-section Safety Data Sheet (SDS/MSDS) in English and REACH / CLP compliance declaration are mandatory.',
        severity: 'BLOCKER',
        sourceUrl: 'https://echa.europa.eu'
      });
      break;

    case 'COSMETICS':
      complianceItems.push({
        id: 'comp_cosmetics_cpnp',
        title: 'Kozmetik Ürün Bildirimi (CPNP) ve Ürün Güvenlik Dosyası',
        titleEn: 'Cosmetics Notification (CPNP) & Safety Dossier',
        detail: 'AB ve hedef pazar mevzuatına göre Sorumlu Kişi (Responsible Person) ataması, Ürün Güvenlik Raporu (CPSR) ve CPNP portal bildirimi zorunludur.',
        detailEn: 'Appointed Responsible Person, Cosmetic Product Safety Report (CPSR), and CPNP portal notification are required.',
        severity: 'REQUIRED',
        sourceUrl: 'https://single-market-economy.ec.europa.eu/sectors/cosmetics/cpnp_en'
      });
      break;

    case 'MEDICAL':
      complianceItems.push({
        id: 'comp_medical_mdr',
        title: 'Tıbbi Cihaz MDR Belgesi ve CE Sertifikasyonu',
        titleEn: 'Medical Device MDR Certification & CE Marking',
        detail: 'MDR (AB 2017/745) direktifi kapsamında Onaylanmış Kuruluş (Notified Body) CE sertifikası ve ürün kayıt onayı olmadan gümrükten çekilemez.',
        detailEn: 'Medical devices cannot clear customs without Notified Body CE certification and product registration under the MDR (EU 2017/745).',
        severity: 'BLOCKER',
        sourceUrl: 'https://health.ec.europa.eu/medical-devices-sector_en'
      });
      break;

    case 'PLANT_ANIMAL':
      complianceItems.push({
        id: 'comp_phytosanitary',
        title: 'Fitosaniter / Veteriner Sağlık Sertifikası',
        titleEn: 'Phytosanitary / Veterinary Health Certificate',
        detail: 'Canlı bitki, tohum veya hayvansal ürünlerde uluslararası bitki karantina / veteriner sağlık belgesi sınır kontrol noktası girişinde zorunludur.',
        detailEn: 'Live plants, seeds, or animal products require an international quarantine or veterinary health certificate for border control entry.',
        severity: 'BLOCKER',
        sourceUrl: 'https://www.ippc.int'
      });
      break;

    default:
      break;
  }

  sections.push({
    title: 'Ürün ve Mevzuat Uyumluluğu',
    titleEn: 'Product & Regulatory Compliance',
    items: complianceItems
  });

  // ==========================================
  // 3. Gümrükleme & Teslimat (Customs & Logistics)
  // ==========================================
  const logisticsItems: ChecklistItem[] = [];

  // Gümrük Birliği ülkesi veya İngiltere ise alıcı EORI kontrolü (WARNING)
  if (country.tradeRegime === 'CUSTOMS_UNION' || country.code === 'GB') {
    logisticsItems.push({
      id: 'log_buyer_eori',
      title: 'Alıcının EORI Numarası Kontrolü',
      titleEn: 'Consignee EORI Number Verification',
      detail: 'AB ülkeleri ve Birleşik Krallık gümrüğünde işlem yapabilmek için ithalatçı firmanın geçerli bir EORI numarasına sahip olduğu teyit edilmelidir.',
      detailEn: 'Verify that the consignee has a valid EORI number to clear customs in EU member states and the UK.',
      severity: 'WARNING',
      sourceUrl: 'https://ec.europa.eu/taxation_customs/dds2/eos/eori_home.jsp'
    });
  }

  // ISPM-15 ahşap ambalaj (REQUIRED, her zaman)
  logisticsItems.push({
    id: 'log_ispm15',
    title: 'ISPM-15 Ahşap Ambalaj Standardı',
    titleEn: 'ISPM-15 Wood Packaging Standard',
    detail: 'Sevkiyatta kullanılan ahşap palet, sandık ve takozlarda IPPC ISPM-15 ısıl işlem (HT) damgası bulunması zorunludur; aksi halde gümrükten geri çevrilir.',
    detailEn: 'All wooden pallets, crates, and dunnage must bear the IPPC ISPM-15 heat-treatment (HT) stamp; untreated wood will be rejected at border inspection.',
    severity: 'REQUIRED',
    sourceUrl: 'https://www.ippc.int'
  });

  // Incoterm based insurance warning
  if (options.incoterm) {
    if (options.incoterm === 'CIF' || options.incoterm === 'CIP') {
      logisticsItems.push({
        id: 'log_insurance_required',
        title: 'Sigorta (Incoterm: ' + options.incoterm + ')',
        titleEn: 'Insurance (Incoterm: ' + options.incoterm + ')',
        detail: 'Bu teslim şeklinde sigorta yaptırmak satıcının sorumluluğundadır.',
        detailEn: 'Under this Incoterms rule, procuring cargo marine insurance is the contractual obligation of the seller.',
        severity: 'REQUIRED'
      });
    } else if (options.incoterm === 'FOB' || options.incoterm === 'EXW') {
      logisticsItems.push({
        id: 'log_insurance_recommended',
        title: 'Sigorta (Incoterm: ' + options.incoterm + ')',
        titleEn: 'Insurance (Incoterm: ' + options.incoterm + ')',
        detail: 'Bu teslim şeklinde sigorta yaptırmak zorunlu değildir ancak navlun ve mal güvenliği için şiddetle önerilir.',
        detailEn: 'Cargo insurance is not mandatory under this Incoterm, but highly recommended to protect against transit loss or damage.',
        severity: 'TIP'
      });
    }
  }

  // Payment Method
  if (options.paymentMethodId) {
    const pm = PAYMENT_METHODS.find(p => p.id === options.paymentMethodId);
    if (pm) {
      logisticsItems.push({
        id: 'log_payment_method',
        title: 'Ödeme Şekli: ' + pm.nameTr,
        titleEn: 'Payment Term: ' + (pm.nameEn || pm.nameTr),
        detail: pm.descriptionTr + ' ' + pm.balanceTr + (pm.tipTr ? ' İpucu: ' + pm.tipTr : ''),
        detailEn: (pm.descriptionEn || pm.descriptionTr) + ' ' + (pm.balanceEn || pm.balanceTr) + (pm.tipEn ? ' Tip: ' + pm.tipEn : ''),
        severity: pm.riskLevel === 'YÜKSEK' ? 'WARNING' : 'TIP'
      });
    }
  }

  // Mal bedeli 15.000 EUR altıysa ETGB mikro ihracat ipucu (TIP)
  const declaredVal = options.declaredValue;
  if (declaredVal !== undefined && declaredVal > 0 && declaredVal <= 15000) {
    logisticsItems.push({
      id: 'log_etgb_eligible',
      title: 'Mikro İhracat (ETGB) İmkanı',
      titleEn: 'Micro-Export (ETGB) Opportunity',
      detail: 'Ağırlık ve fatura tutarı mikro ihracat sınırlarının altındaysa gümrük müşaviri olmadan hızlı kargo operatörüyle ETGB düzenlenebilir. Sınırlar güncellenmiş olabilir (eski sınır 300 kg / 15.000 EUR); Ticaret Bakanlığı mevzuatından teyit edin.',
      detailEn: 'If weight and invoice value are below the micro-export limits, goods can be dispatched via an express carrier under ETGB without a customs broker. Limits may have been updated (former limit 300 kg / 15,000 EUR); confirm with the Ministry of Trade.',
      severity: 'TIP',
      sourceUrl: 'https://ticaret.gov.tr'
    });
  }

  // Numune ise numune ibaresi (TIP)
  if (options.isSample) {
    logisticsItems.push({
      id: 'log_sample_marking',
      title: 'Numune İbaresi ve Asgari Gümrük Kıymeti',
      titleEn: 'Sample Marking & Minimum Customs Value',
      detail: 'Faturada "Free sample for test purposes only - No commercial value, declared for customs only" ibaresi bulunmalıdır. (Yasal İkaz: 4458 sayılı Gümrük Kanunu Md. 23-31 uyarınca eşya bedeli 0.00 olamaz; sembolik bir gümrük kıymeti (örn. 1 USD) yazılmalıdır).',
      detailEn: 'The invoice must state: "Free sample for test purposes only - No commercial value, declared for customs only". (Legal Note: Pursuant to Customs Law Arts. 23-31, customs value cannot be 0.00; declare a nominal value e.g. 1 USD).',
      severity: 'TIP'
    });
  }

  sections.push({
    title: 'Gümrükleme & Teslimat',
    titleEn: 'Customs & Logistics',
    items: logisticsItems
  });

  return {
    country,
    category,
    sections,
    dataVerifiedOn: DATA_VERIFIED_ON
  };
};
