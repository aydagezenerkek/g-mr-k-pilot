import { describe, it, expect } from 'vitest';
import { isStale, diffTariff, TTL_DAYS } from './tariffCache';

describe('tariffCache', () => {
  it('TTL dolunca bayat sayılır', () => {
    const now = Date.now();
    expect(isStale({ data: {}, source: 'x', savedAt: now - (TTL_DAYS + 1) * 86400000 }, now)).toBe(true);
    expect(isStale({ data: {}, source: 'x', savedAt: now - 86400000 }, now)).toBe(false);
  });
  it('değişimi yakalar', () => {
    const a = { tariff_details: { base_duty_rate: '%0', vat_rate: '%19' } };
    const b = { tariff_details: { base_duty_rate: '%4', vat_rate: '%19' } };
    expect(diffTariff(a, b)?.change_detected).toBe(true);
    expect(diffTariff(a, a)?.change_detected).toBe(false);
  });
});
