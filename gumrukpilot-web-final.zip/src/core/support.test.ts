import { describe, it, expect } from 'vitest';
import { SUPPORT_PROGRAM, supportCopy } from './support';

describe('support banner', () => {
  it('başvuru aşamasında destek/kabul iddiası içermez', () => {
    const c = supportCopy('applied', 'tr');
    expect(c.body).toContain('anlamına gelmez');
    expect(c.body).not.toContain('kabul edilmiştir');
  });
  it('varsayılan durum applied', () => {
    expect(SUPPORT_PROGRAM.status).toBe('applied');
  });
});
