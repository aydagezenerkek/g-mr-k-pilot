export type RiskLevel = 'DÜŞÜK' | 'ORTA' | 'YÜKSEK';

export interface PaymentMethod {
  id: string;
  nameTr: string;
  nameEn?: string;
  riskLevel: RiskLevel;
  descriptionTr: string;
  descriptionEn?: string;
  balanceTr: string;
  balanceEn?: string;
  tipTr?: string;
  tipEn?: string;
}

export const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'cash_in_advance',
    nameTr: 'Peşin (Cash in Advance)',
    nameEn: 'Cash in Advance (Advance Payment)',
    riskLevel: 'DÜŞÜK',
    descriptionTr: 'Mal sevkiyatından önce ödemenin alınması.',
    descriptionEn: 'Full payment received before shipment dispatch.',
    balanceTr: 'İhracatçı için en güvenli, ithalatçı için riskli.',
    balanceEn: 'Safest method for the exporter, higher risk for the buyer.'
  },
  {
    id: 'letter_of_credit',
    nameTr: 'Akreditif (Letter of Credit)',
    nameEn: 'Letter of Credit (L/C)',
    riskLevel: 'ORTA',
    descriptionTr: 'Bankaların araya girdiği, belgelerin şartlara uygunluğu esas olan ödeme şekli.',
    descriptionEn: 'Bank-guaranteed payment contingent upon presenting compliant documents.',
    balanceTr: 'Bankalar aracılığıyla her iki tarafın riskleri dengelenir.',
    balanceEn: 'Balances risk for both buyer and seller through banking channels.',
    tipTr: 'Eximbank alacak sigortası ve iskonto imkanları mevcuttur.',
    tipEn: 'Eximbank export credit insurance and discounting options available.'
  },
  {
    id: 'documents_against_payment',
    nameTr: 'Vesaik Mukabili (Documents against Payment)',
    nameEn: 'Documents against Payment (D/P - CAD)',
    riskLevel: 'ORTA',
    descriptionTr: 'Belgelerin bedel ödenmesi karşılığında banka tarafından teslim edilmesi.',
    descriptionEn: 'Shipping documents released by collecting bank only upon full payment.',
    balanceTr: 'İthalatçının ödeme yapmaması durumunda malın geri getirilmesi riski vardır.',
    balanceEn: 'Risk of cargo return if the buyer defaults or fails to pay at arrival port.',
    tipTr: 'Eximbank alacak sigortası ve iskonto imkanları mevcuttur.',
    tipEn: 'Eximbank export credit insurance and discounting options available.'
  },
  {
    id: 'documents_against_acceptance',
    nameTr: 'Mal Mukabili (Documents against Acceptance)',
    nameEn: 'Documents against Acceptance / Open Account',
    riskLevel: 'YÜKSEK',
    descriptionTr: 'Malların ve belgelerin gönderilip, ödemenin belirlenen vadede yapılması.',
    descriptionEn: 'Goods and documents dispatched with deferred payment due at maturity.',
    balanceTr: 'İhracatçı için en riskli yöntem, vadeli ödeme içerir.',
    balanceEn: 'Highest risk for exporter; requires credit assessment and insurance.'
  }
];
