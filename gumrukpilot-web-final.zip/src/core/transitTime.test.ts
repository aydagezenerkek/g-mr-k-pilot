import { describe, it, expect } from 'vitest';
import { estimateTransitTime } from './transitTime';

describe('estimateTransitTime', () => {
  it('should estimate EU road transit correctly', () => {
    const result = estimateTransitTime('DE', 'road', true);
    expect(result.minDays).toBe(3);
    expect(result.maxDays).toBe(7);
  });

  it('should estimate US sea transit correctly', () => {
    const result = estimateTransitTime('US', 'sea', false);
    expect(result.minDays).toBe(20);
    expect(result.maxDays).toBe(35);
  });

  it('should estimate express air transit correctly for any country', () => {
    const result = estimateTransitTime('CN', 'air', false);
    expect(result.minDays).toBe(2);
    expect(result.maxDays).toBe(5);
  });

  it('should estimate Middle East road transit correctly', () => {
    const result = estimateTransitTime('AE', 'road', false);
    expect(result.minDays).toBe(5);
    expect(result.maxDays).toBe(10);
  });

  it('should provide fallback for unknown countries or modes', () => {
    const result = estimateTransitTime('XX', 'road', false);
    expect(result.minDays).toBe(7);
    expect(result.maxDays).toBe(12);
  });
});
