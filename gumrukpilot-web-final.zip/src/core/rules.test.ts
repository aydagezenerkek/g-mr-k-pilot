import { describe, it, expect } from 'vitest';
import { buildChecklist, DATA_VERIFIED_ON } from './rules';
import { COUNTRIES } from './countries';

describe('Customs Prep Rule Engine (src/core/rules.ts)', () => {
  it('should have 19 countries defined with valid trade regimes', () => {
    expect(COUNTRIES.length).toBe(19);
    expect(COUNTRIES.every(c => ['CUSTOMS_UNION', 'FREE_TRADE_AGREEMENT', 'MFN'].includes(c.tradeRegime))).toBe(true);
  });

  it('should have valid DATA_VERIFIED_ON date', () => {
    expect(DATA_VERIFIED_ON).toBe('2026-11-04');
  });

  // Test 1: Always BLOCKER Commercial Invoice & Packing List
  it('Test 1: should always have commercial invoice and packing list as BLOCKER in Section 1', () => {
    const res = buildChecklist('DE', 'OTHER');
    const docSection = res.sections.find(s => s.title === 'Gerekli Belgeler');
    expect(docSection).toBeDefined();

    const invoice = docSection?.items.find(i => i.id === 'doc_commercial_invoice');
    const packing = docSection?.items.find(i => i.id === 'doc_packing_list');

    expect(invoice?.severity).toBe('BLOCKER');
    expect(packing?.severity).toBe('BLOCKER');
  });

  // Test 2: Customs Union + Industrial Product -> A.TR (REQUIRED)
  it('Test 2: should require A.TR for industrial products to Customs Union (Germany / ELECTRONICS)', () => {
    const res = buildChecklist('DE', 'ELECTRONICS');
    const docSection = res.sections.find(s => s.title === 'Gerekli Belgeler');
    const atr = docSection?.items.find(i => i.id === 'doc_atr');
    const eur1 = docSection?.items.find(i => i.id === 'doc_eur1_agri');

    expect(atr?.severity).toBe('REQUIRED');
    expect(eur1).toBeUndefined();
  });

  // Test 3: Customs Union + Food/Agri -> EUR.1 (REQUIRED), NOT A.TR
  it('Test 3: should require EUR.1 instead of A.TR for FOOD to Customs Union (France / FOOD)', () => {
    const res = buildChecklist('FR', 'FOOD');
    const docSection = res.sections.find(s => s.title === 'Gerekli Belgeler');
    const eur1 = docSection?.items.find(i => i.id === 'doc_eur1_agri');
    const atr = docSection?.items.find(i => i.id === 'doc_atr');

    expect(eur1?.severity).toBe('REQUIRED');
    expect(atr).toBeUndefined();
  });

  // Test 4: Customs Union + Plant/Animal -> EUR.1 (REQUIRED)
  it('Test 4: should require EUR.1 for PLANT_ANIMAL to Customs Union (Italy / PLANT_ANIMAL)', () => {
    const res = buildChecklist('IT', 'PLANT_ANIMAL');
    const docSection = res.sections.find(s => s.title === 'Gerekli Belgeler');
    const eur1 = docSection?.items.find(i => i.id === 'doc_eur1_agri');

    expect(eur1?.severity).toBe('REQUIRED');
  });

  // Test 5: FTA Country (GB) -> EUR.1 / STA (REQUIRED)
  it('Test 5: should require EUR.1/EUR-MED for Free Trade Agreement country (United Kingdom / TEXTILE)', () => {
    const res = buildChecklist('GB', 'TEXTILE');
    const docSection = res.sections.find(s => s.title === 'Gerekli Belgeler');
    const eur1Sta = docSection?.items.find(i => i.id === 'doc_eur1_sta');

    expect(eur1Sta?.severity).toBe('REQUIRED');
  });

  // Test 6: MFN Country (US) -> Certificate of Origin (REQUIRED)
  it('Test 6: should require Certificate of Origin for MFN country (USA / MACHINERY)', () => {
    const res = buildChecklist('US', 'MACHINERY');
    const docSection = res.sections.find(s => s.title === 'Gerekli Belgeler');
    const coo = docSection?.items.find(i => i.id === 'doc_coo');

    expect(coo?.severity).toBe('REQUIRED');
  });

  // Test 7: ELECTRONICS -> CE+RoHS (REQUIRED) and UN 38.3 (BLOCKER)
  it('Test 7: should have CE+RoHS REQUIRED and Lithium UN 38.3 BLOCKER for Electronics', () => {
    const res = buildChecklist('DE', 'ELECTRONICS', { hasLithiumBattery: true });
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');

    const ce = compSection?.items.find(i => i.id === 'comp_ce_rohs');
    const un383 = compSection?.items.find(i => i.id === 'comp_battery_un383');

    expect(ce?.severity).toBe('REQUIRED');
    expect(un383?.severity).toBe('BLOCKER');
  });

  // Test 8: FOOD -> Health Certificate (BLOCKER)
  it('Test 8: should return Sanitary/Phytosanitary Health Certificate as BLOCKER for FOOD', () => {
    const res = buildChecklist('US', 'FOOD');
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');
    const foodHealth = compSection?.items.find(i => i.id === 'comp_food_health');

    expect(foodHealth?.severity).toBe('BLOCKER');
  });

  // Test 9: CHEMICALS -> MSDS (BLOCKER)
  it('Test 9: should return MSDS as BLOCKER for CHEMICALS', () => {
    const res = buildChecklist('NL', 'CHEMICALS');
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');
    const msds = compSection?.items.find(i => i.id === 'comp_chem_msds');

    expect(msds?.severity).toBe('BLOCKER');
  });

  // Test 10: COSMETICS -> CPNP notification (REQUIRED)
  it('Test 10: should return CPNP notification as REQUIRED for COSMETICS', () => {
    const res = buildChecklist('FR', 'COSMETICS');
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');
    const cpnp = compSection?.items.find(i => i.id === 'comp_cosmetics_cpnp');

    expect(cpnp?.severity).toBe('REQUIRED');
  });

  // Test 11: MEDICAL -> MDR (BLOCKER)
  it('Test 11: should return MDR approval as BLOCKER for MEDICAL products', () => {
    const res = buildChecklist('DE', 'MEDICAL');
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');
    const mdr = compSection?.items.find(i => i.id === 'comp_medical_mdr');

    expect(mdr?.severity).toBe('BLOCKER');
  });

  // Test 12: PLANT_ANIMAL -> Phytosanitary (BLOCKER)
  it('Test 12: should return Phytosanitary Certificate as BLOCKER for PLANT_ANIMAL', () => {
    const res = buildChecklist('ES', 'PLANT_ANIMAL');
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');
    const phyto = compSection?.items.find(i => i.id === 'comp_phytosanitary');

    expect(phyto?.severity).toBe('BLOCKER');
  });

  // Test 13: TEXTILE/CLOTHING -> Composition Label (REQUIRED)
  it('Test 13: should return textile fiber label as REQUIRED for TEXTILE/CLOTHING', () => {
    const res = buildChecklist('PL', 'CLOTHING');
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');
    const label = compSection?.items.find(i => i.id === 'comp_textile_label');

    expect(label?.severity).toBe('REQUIRED');
  });

  // Test 14: Logistics EORI check for Customs Union & UK (WARNING) and ISPM-15 (REQUIRED)
  it('Test 14: should include EORI WARNING for UK and Customs Union, and ISPM-15 REQUIRED for all', () => {
    const resUK = buildChecklist('GB', 'MACHINERY');
    const logSectionUK = resUK.sections.find(s => s.title === 'Gümrükleme & Teslimat');
    const eoriUK = logSectionUK?.items.find(i => i.id === 'log_buyer_eori');
    const ispm15UK = logSectionUK?.items.find(i => i.id === 'log_ispm15');

    expect(eoriUK?.severity).toBe('WARNING');
    expect(ispm15UK?.severity).toBe('REQUIRED');

    // MFN country without EORI warning
    const resUS = buildChecklist('US', 'MACHINERY');
    const logSectionUS = resUS.sections.find(s => s.title === 'Gümrükleme & Teslimat');
    const eoriUS = logSectionUS?.items.find(i => i.id === 'log_buyer_eori');
    const ispm15US = logSectionUS?.items.find(i => i.id === 'log_ispm15');

    expect(eoriUS).toBeUndefined();
    expect(ispm15US?.severity).toBe('REQUIRED');
  });

  // Test 15: ETGB Tip under 15,000 EUR & Sample Tip
  it('Test 15: should provide ETGB TIP when declared value <= 15000 and Sample TIP when isSample is true', () => {
    const res = buildChecklist('DE', 'OTHER', { declaredValue: 5000, isSample: true });
    const logSection = res.sections.find(s => s.title === 'Gümrükleme & Teslimat');

    const etgb = logSection?.items.find(i => i.id === 'log_etgb_eligible');
    const sample = logSection?.items.find(i => i.id === 'log_sample_marking');

    expect(etgb?.severity).toBe('TIP');
    expect(sample?.severity).toBe('TIP');
  });

  // Test 16: Incoterm Insurance
  it('Test 16: should provide REQUIRED insurance for CIF/CIP and TIP for FOB/EXW', () => {
    const resCIF = buildChecklist('DE', 'OTHER', { incoterm: 'CIF' });
    const logSectionCIF = resCIF.sections.find(s => s.title === 'Gümrükleme & Teslimat');
    expect(logSectionCIF?.items.find(i => i.id === 'log_insurance_required')?.severity).toBe('REQUIRED');

    const resFOB = buildChecklist('DE', 'OTHER', { incoterm: 'FOB' });
    const logSectionFOB = resFOB.sections.find(s => s.title === 'Gümrükleme & Teslimat');
    expect(logSectionFOB?.items.find(i => i.id === 'log_insurance_recommended')?.severity).toBe('TIP');
  });

  // Test 17: Payment Method
  it('Test 17: should include payment method warning/tip', () => {
    const resHigh = buildChecklist('DE', 'OTHER', { paymentMethodId: 'documents_against_acceptance' });
    const logSectionHigh = resHigh.sections.find(s => s.title === 'Gümrükleme & Teslimat');
    expect(logSectionHigh?.items.find(i => i.id === 'log_payment_method')?.severity).toBe('WARNING');

    const resLow = buildChecklist('DE', 'OTHER', { paymentMethodId: 'cash_in_advance' });
    const logSectionLow = resLow.sections.find(s => s.title === 'Gümrükleme & Teslimat');
    expect(logSectionLow?.items.find(i => i.id === 'log_payment_method')?.severity).toBe('TIP');
  });

  // Test 18: comp_sanctions_dualuse present with WARNING for any category/country
  it('Test 18: should include comp_sanctions_dualuse with WARNING severity for any category and country', () => {
    const res = buildChecklist('US', 'TEXTILE');
    const compSection = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu');
    const item = compSection?.items.find(i => i.id === 'comp_sanctions_dualuse');

    expect(item).toBeDefined();
    expect(item?.severity).toBe('WARNING');
    expect(item?.title).toBe('Yaptırım & Dual-Use Kontrolü');
  });

  // Test 19: comp_sanctions_dualuse emphasizes electronics, chemicals, machinery
  it('Test 19: should emphasize dual-use for ELECTRONICS, CHEMICALS, and MACHINERY categories', () => {
    const resElec = buildChecklist('DE', 'ELECTRONICS');
    const itemElec = resElec.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu')?.items.find(i => i.id === 'comp_sanctions_dualuse');
    expect(itemElec?.detail).toContain('Önemli Vurgu');

    const resOther = buildChecklist('DE', 'OTHER');
    const itemOther = resOther.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu')?.items.find(i => i.id === 'comp_sanctions_dualuse');
    expect(itemOther?.detail).not.toContain('Önemli Vurgu');
  });

  // Test 20: comp_sanctions_dualuse has correct sourceUrl
  it('Test 20: should have official sourceUrl for comp_sanctions_dualuse', () => {
    const res = buildChecklist('FR', 'MACHINERY');
    const item = res.sections.find(s => s.title === 'Ürün ve Mevzuat Uyumluluğu')?.items.find(i => i.id === 'comp_sanctions_dualuse');

    expect(item?.sourceUrl).toBe('https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32021R0821');
  });
});

