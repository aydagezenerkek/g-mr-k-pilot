import { describe, test, expect } from 'vitest';
import { PAYMENT_METHODS } from './paymentMethods';

describe('Payment Methods', () => {
  test('should have 4 payment methods', () => {
    expect(PAYMENT_METHODS.length).toBe(4);
  });

  test('should have correct IDs', () => {
    expect(PAYMENT_METHODS.map(pm => pm.id)).toEqual(['cash_in_advance', 'letter_of_credit', 'documents_against_payment', 'documents_against_acceptance']);
  });

  test('should have correct risk levels', () => {
    expect(PAYMENT_METHODS.find(pm => pm.id === 'cash_in_advance')?.riskLevel).toBe('DÜŞÜK');
    expect(PAYMENT_METHODS.find(pm => pm.id === 'documents_against_acceptance')?.riskLevel).toBe('YÜKSEK');
  });

  test('should have tips for L/C and D/P', () => {
    expect(PAYMENT_METHODS.find(pm => pm.id === 'letter_of_credit')?.tipTr).toBeDefined();
    expect(PAYMENT_METHODS.find(pm => pm.id === 'documents_against_payment')?.tipTr).toBeDefined();
  });

  test('should have descriptions', () => {
    PAYMENT_METHODS.forEach(pm => {
      expect(pm.descriptionTr.length).toBeGreaterThan(0);
    });
  });
});
