export interface CatalogProduct {
  id: string;
  name: string;
  hsCode: string;
  category: string;
  unitPrice: number;
  currency: string;
  unit: string;
  createdAt: string;
}

export const INITIAL_CATALOG_PRODUCTS: CatalogProduct[] = [
  {
    id: 'prod-1',
    name: 'Endüstriyel Otomasyon Sensörleri',
    hsCode: '8471.30.00.00.00',
    category: 'ELECTRONICS',
    unitPrice: 85,
    currency: 'EUR',
    unit: 'PCS',
    createdAt: '2026-09-01'
  },
  {
    id: 'prod-2',
    name: 'Pamuklu Erkek Dokuma Gömlek',
    hsCode: '6205.20.00.00.00',
    category: 'CLOTHING',
    unitPrice: 18.5,
    currency: 'EUR',
    unit: 'PCS',
    createdAt: '2026-09-02'
  },
  {
    id: 'prod-3',
    name: 'Doğal Sızma Zeytinyağı (1L Cam Şişe)',
    hsCode: '1509.20.00.00.00',
    category: 'FOOD',
    unitPrice: 9.75,
    currency: 'EUR',
    unit: 'BTL',
    createdAt: '2026-09-03'
  },
  {
    id: 'prod-4',
    name: 'CNC Hidrolik Basınç Valfi',
    hsCode: '8481.20.10.00.00',
    category: 'MACHINERY',
    unitPrice: 240,
    currency: 'USD',
    unit: 'PCS',
    createdAt: '2026-09-04'
  }
];

export const loadCatalogFromStorage = (storage?: Storage): CatalogProduct[] => {
  const s = storage || (typeof window !== 'undefined' ? window.localStorage : undefined);
  if (!s) return INITIAL_CATALOG_PRODUCTS;
  try {
    const raw = s.getItem('customspilot_product_catalog');
    if (!raw) return INITIAL_CATALOG_PRODUCTS;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_CATALOG_PRODUCTS;
  } catch {
    return INITIAL_CATALOG_PRODUCTS;
  }
};

export const saveCatalogToStorage = (products: CatalogProduct[], storage?: Storage): void => {
  const s = storage || (typeof window !== 'undefined' ? window.localStorage : undefined);
  if (!s) return;
  try {
    s.setItem('customspilot_product_catalog', JSON.stringify(products));
  } catch (e) {
    console.error('Failed to save catalog to localStorage:', e);
  }
};
