export interface InvoiceItem {
  qty: number;
  unitPrice: number;
  currency: 'EUR' | 'USD' | 'TRY';
}

export const calculateTotalValueInUsd = (items: InvoiceItem[], rates: { [key: string]: number }): number => {
  return items.reduce((acc, item) => {
    const usdRate = rates['USD'] || 1;
    const itemCurrencyRate = rates[item.currency] || 1;
    const valueInTry = item.qty * item.unitPrice * itemCurrencyRate;
    return acc + (valueInTry / usdRate);
  }, 0);
};

/**
 * UYARI: 30.000 USD sınırı 2020 tarihli düzenlemeden gelir; güncel Genelge'de bankaca terkin sınırı 15.000 USD
 * olarak geçmektedir (kaynaklar çelişiyor). Bu değer kullanıcıya "muafsınız" demek için KULLANILMAMALI;
 * uzman teyidi gelene kadar yalnızca iç hesapta tutulur.
 */
export const checkProceedsExemption = (totalValueInUsd: number): boolean => {
  return totalValueInUsd > 0 && totalValueInUsd <= 30000;
};

export const calculateLandedCost = (
  goodsValue: number,
  freightValue: number,
  dutyPct: number,
  vatPct: number
) => {
  const cif = goodsValue + freightValue;
  const duty = (cif * dutyPct) / 100;
  const vat = ((cif + duty) * vatPct) / 100;
  return {
    duty,
    vat,
    total: cif + duty + vat,
  };
};

export const calculateIbkbRemainingDays = (startDateStr: string): number => {
  if (!startDateStr) return 180;
  const startDate = new Date(startDateStr);
  if (isNaN(startDate.getTime())) return 180;
  const deadline = new Date(startDate);
  deadline.setDate(deadline.getDate() + 180);
  const diffMs = deadline.getTime() - new Date().getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
};
