export type TradeRegime = 'CUSTOMS_UNION' | 'FREE_TRADE_AGREEMENT' | 'MFN';

export interface Country {
  code: string;
  nameTr: string;
  nameEn: string;
  tradeRegime: TradeRegime;
  defaultDutyRate: number;
  currency: string;
  sourceUrl?: string;
  noteTr?: string;
  noteEn?: string;
}

export const COUNTRIES: Country[] = [
  // Gümrük Birliği (AB Üyeleri - A.TR / Sanayi %0)
  { code: 'DE', nameTr: 'Almanya', nameEn: 'Germany', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'FR', nameTr: 'Fransa', nameEn: 'France', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'IT', nameTr: 'İtalya', nameEn: 'Italy', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'ES', nameTr: 'İspanya', nameEn: 'Spain', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'NL', nameTr: 'Hollanda', nameEn: 'Netherlands', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'BE', nameTr: 'Belçika', nameEn: 'Belgium', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'PL', nameTr: 'Polonya', nameEn: 'Poland', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'RO', nameTr: 'Romanya', nameEn: 'Romania', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'BG', nameTr: 'Bulgaristan', nameEn: 'Bulgaria', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },
  { code: 'GR', nameTr: 'Yunanistan', nameEn: 'Greece', tradeRegime: 'CUSTOMS_UNION', defaultDutyRate: 0.0, currency: 'EUR' },

  // Serbest Ticaret Anlaşması (STA - EUR.1 / EUR-MED / Menşe İspat)
  { code: 'GB', nameTr: 'Birleşik Krallık', nameEn: 'United Kingdom', tradeRegime: 'FREE_TRADE_AGREEMENT', defaultDutyRate: 0.0, currency: 'GBP' },
  { code: 'AZ', nameTr: 'Azerbaycan', nameEn: 'Azerbaijan', tradeRegime: 'FREE_TRADE_AGREEMENT', defaultDutyRate: 0.0, currency: 'USD' },
  { code: 'GE', nameTr: 'Gürcistan', nameEn: 'Georgia', tradeRegime: 'FREE_TRADE_AGREEMENT', defaultDutyRate: 0.0, currency: 'USD' },
  { code: 'RS', nameTr: 'Sırbistan', nameEn: 'Serbia', tradeRegime: 'FREE_TRADE_AGREEMENT', defaultDutyRate: 0.0, currency: 'EUR' },

  // 3. Ülke / En Çok Kayırılan Ülke (MFN - Menşe Şahadetnamesi / Standart Tarife)
  { code: 'US', nameTr: 'Amerika Birleşik Devletleri', nameEn: 'United States', tradeRegime: 'MFN', defaultDutyRate: 4.5, currency: 'USD', sourceUrl: 'https://hts.usitc.gov' },
  { 
    code: 'CN', 
    nameTr: 'Çin', 
    nameEn: 'China', 
    tradeRegime: 'MFN', 
    defaultDutyRate: 7.1, 
    currency: 'USD', 
    sourceUrl: 'https://immib.org.tr/TR/cin-ticaret-politikalari-incelemesi',
    noteTr: 'Ürüne göre %0-65 arası değişir, ortalama oran',
    noteEn: 'Varies between 0-65% depending on product, average rate'
  },
  { 
    code: 'AE', 
    nameTr: 'Birleşik Arap Emirlikleri', 
    nameEn: 'United Arab Emirates', 
    tradeRegime: 'FREE_TRADE_AGREEMENT', 
    defaultDutyRate: 0.0, 
    currency: 'USD', 
    sourceUrl: 'https://ticaret.gov.tr/dis-iliskiler/serbest-ticaret-anlasmalari' 
  },
  { 
    code: 'SA', 
    nameTr: 'Suudi Arabistan', 
    nameEn: 'Saudi Arabia', 
    tradeRegime: 'MFN', 
    defaultDutyRate: 5.0, 
    currency: 'USD', 
    sourceUrl: 'https://ticaret.gov.tr' 
  },
  { 
    code: 'QA', 
    nameTr: 'Katar', 
    nameEn: 'Qatar', 
    tradeRegime: 'MFN', 
    defaultDutyRate: 5.0, 
    currency: 'USD', 
    sourceUrl: 'https://ticaret.gov.tr' 
  }
];

export const getCountryByCode = (code: string): Country => {
  const found = COUNTRIES.find(c => c.code.toUpperCase() === code.toUpperCase());
  if (found) return found;
  return {
    code: code.toUpperCase(),
    nameTr: code.toUpperCase(),
    nameEn: code.toUpperCase(),
    tradeRegime: 'MFN',
    defaultDutyRate: 5.0,
    currency: 'USD'
  };
};
