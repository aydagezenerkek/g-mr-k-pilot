/**
 * Destek programı durumu. SADECE yazılı sonuç gelince 'accepted' yapılır.
 * 'applied' iken arayüz destek/onay iddiasında bulunmaz.
 */
export type SupportStatus = 'applied' | 'accepted';

export const SUPPORT_PROGRAM: { name: string; status: SupportStatus } = {
  name: 'İTO Bilgiyi Ticarileştirme Merkezi (BTM)',
  status: 'applied',
};

export function supportCopy(status: SupportStatus, lang: 'tr' | 'en') {
  const tr = lang === 'tr';
  if (status === 'accepted') {
    return {
      pill: tr ? 'Kabul edildi' : 'Accepted',
      title: tr ? 'İTO BTM programı kapsamında' : 'Part of the ITO BTM programme',
      body: tr
        ? 'GümrükPilot, İTO Bilgiyi Ticarileştirme Merkezi (BTM) programına kabul edilmiştir.'
        : 'GümrükPilot has been accepted into the Istanbul Chamber of Commerce (ITO) Knowledge Commercialisation Centre (BTM) programme.',
    };
  }
  return {
    pill: tr ? 'Değerlendirmede' : 'Under review',
    title: tr ? 'İTO BTM başvurusu değerlendirmede' : 'ITO BTM application under review',
    body: tr
      ? 'GümrükPilot, İTO Bilgiyi Ticarileştirme Merkezi (BTM) programına başvurmuştur. Sonuç henüz açıklanmamıştır; bu bilgi bir destek veya onay anlamına gelmez.'
      : 'GümrükPilot has applied to the Istanbul Chamber of Commerce (ITO) Knowledge Commercialisation Centre (BTM) programme. No result has been announced; this is not a statement of support or approval.',
  };
}
