export type TransportMode = 'road' | 'sea' | 'air' | 'rail';

export interface TransitTimeEstimate {
  minDays: number;
  maxDays: number;
  label: string;
}

export function estimateTransitTime(
  countryCode: string,
  mode: TransportMode,
  isEuMember: boolean
): TransitTimeEstimate {
  // Base ranges based on mode and distance/regime
  // All estimates are from Turkey (Istanbul center)
  
  if (mode === 'air') {
    return { minDays: 2, maxDays: 5, label: 'Express Air' };
  }

  if (isEuMember) {
    if (mode === 'road') {
      return { minDays: 3, maxDays: 7, label: 'Standard Road' };
    }
    if (mode === 'rail') {
      return { minDays: 10, maxDays: 15, label: 'Intermodal Rail' };
    }
    if (mode === 'sea') {
      return { minDays: 7, maxDays: 14, label: 'Short Sea Shipping' };
    }
  }

  // North America (US, CA)
  if (['US', 'CA'].includes(countryCode)) {
    if (mode === 'sea') {
      return { minDays: 20, maxDays: 35, label: 'Transatlantic Sea' };
    }
    return { minDays: 3, maxDays: 7, label: 'Priority Air' };
  }

  // Far East / China
  if (['CN', 'JP', 'KR'].includes(countryCode)) {
    if (mode === 'sea') {
      return { minDays: 30, maxDays: 45, label: 'Far East Sea' };
    }
    if (mode === 'rail') {
      return { minDays: 18, maxDays: 25, label: 'Iron Silk Road' };
    }
  }

  // Middle East / Gulf
  if (['AE', 'SA', 'QA'].includes(countryCode)) {
    if (mode === 'road') {
      return { minDays: 5, maxDays: 10, label: 'Gulf Road' };
    }
    if (mode === 'sea') {
      return { minDays: 12, maxDays: 20, label: 'Middle East Sea' };
    }
  }

  // Default catch-all
  const defaults: Record<TransportMode, TransitTimeEstimate> = {
    road: { minDays: 7, maxDays: 12, label: 'International Road' },
    sea: { minDays: 15, maxDays: 30, label: 'Standard Sea' },
    air: { minDays: 3, maxDays: 6, label: 'Standard Air' },
    rail: { minDays: 14, maxDays: 21, label: 'Standard Rail' }
  };

  return defaults[mode];
}
