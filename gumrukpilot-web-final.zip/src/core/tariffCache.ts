/** Cihazdaki GTİP/vergi önbelleği: ilk sorgu AI'dan, sonrası bu kayıttan; süre dolunca AI yeniden kontrol eder. */
export const TTL_DAYS = 30;
const KEY = 'gp_tariff_cache_v1';

export interface CachedTariff { data: any; source: string; savedAt: number }
type Store = Record<string, CachedTariff>;

const keyOf = (hs: string, country: string) => `${hs.replace(/\D/g, '')}|${country.trim().toLowerCase()}`;

function load(): Store {
  try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; }
}

export function getCached(hs: string, country: string): CachedTariff | null {
  return load()[keyOf(hs, country)] ?? null;
}

export function isStale(c: CachedTariff, now = Date.now()): boolean {
  return now - c.savedAt > TTL_DAYS * 86400000;
}

export function saveCached(hs: string, country: string, data: any, source: string, now = Date.now()) {
  try {
    const s = load();
    s[keyOf(hs, country)] = { data, source, savedAt: now };
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch { /* depolama dolu/kapalı: önbelleksiz devam */ }
}

/** Yeni ve önceki sonucu karşılaştırır. */
export function diffTariff(prev: any, next: any) {
  const p = prev?.tariff_details, n = next?.tariff_details;
  if (!p || !n) return undefined;
  const fmt = (t: any) => `Vergi: ${t.base_duty_rate} · KDV/VAT: ${t.vat_rate}`;
  const changed = p.base_duty_rate !== n.base_duty_rate || p.vat_rate !== n.vat_rate;
  return { previous_value: fmt(p), new_value: fmt(n), change_detected: changed };
}
