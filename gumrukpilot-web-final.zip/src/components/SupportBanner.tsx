import { Landmark, CheckCircle2, Clock, Circle, HardDrive, ShieldCheck } from 'lucide-react';
import { SUPPORT_PROGRAM, supportCopy } from '../core/support';

export default function SupportBanner({ lang }: { lang: 'tr' | 'en' }) {
  const tr = lang === 'tr';
  const { status, name } = SUPPORT_PROGRAM;
  const c = supportCopy(status, lang);
  const accepted = status === 'accepted';

  const steps = [
    { label: tr ? 'Başvuru yapıldı' : 'Applied', state: 'done' },
    { label: tr ? 'Değerlendirme' : 'Review', state: accepted ? 'done' : 'current' },
    { label: tr ? 'Sonuç' : 'Result', state: accepted ? 'done' : 'todo' },
  ] as const;

  const trust = [
    { icon: HardDrive, tone: 'text-sky-400', text: tr ? 'Verileriniz cihazınızda saklanır, hesap gerekmez.' : 'Your data stays on your device; no account needed.' },
    { icon: Clock, tone: 'text-amber-400', text: tr ? 'Kural verisi gümrük müşaviri onayı bekliyor.' : 'Rule data is awaiting customs broker review.' },
    { icon: ShieldCheck, tone: 'text-emerald-400', text: tr ? 'Karar destek aracıdır; resmi danışmanlık yerine geçmez.' : 'Decision-support tool; not official advice.' },
  ];

  return (
    <section aria-label={tr ? 'Destek programı durumu' : 'Support programme status'} className="px-4 sm:px-8 -mt-6 relative z-20">
      <div className="max-w-6xl mx-auto rounded-2xl border border-slate-700/70 bg-slate-900/95 shadow-xl shadow-black/30 backdrop-blur p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center gap-5 lg:gap-8">
          <div className="flex items-start gap-4 flex-1 min-w-0">
            <div className="w-11 h-11 shrink-0 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-slate-950 shadow-md">
              <Landmark className="w-5 h-5" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h2 className="text-sm sm:text-base font-bold text-white">{c.title}</h2>
                <span className={`text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full border ${accepted ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40' : 'bg-amber-500/15 text-amber-300 border-amber-500/40'}`}>
                  {c.pill}
                </span>
              </div>
              <p className="text-xs sm:text-[13px] leading-relaxed text-slate-300">{c.body}</p>
              <p className="text-[11px] text-slate-500 mt-1">{name}</p>
            </div>
          </div>

          <ol className="flex items-center gap-2 sm:gap-3 lg:w-[340px] shrink-0" aria-label={tr ? 'Başvuru aşamaları' : 'Application stages'}>
            {steps.map((s, i) => (
              <li key={s.label} className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
                <div className="flex flex-col items-center gap-1 min-w-0">
                  {s.state === 'done' && <CheckCircle2 className="w-5 h-5 text-emerald-400" aria-hidden="true" />}
                  {s.state === 'current' && <Clock className="w-5 h-5 text-amber-400 animate-pulse" aria-hidden="true" />}
                  {s.state === 'todo' && <Circle className="w-5 h-5 text-slate-600" aria-hidden="true" />}
                  <span className={`text-[10px] sm:text-[11px] font-semibold text-center leading-tight ${s.state === 'todo' ? 'text-slate-500' : 'text-slate-200'}`}>{s.label}</span>
                </div>
                {i < steps.length - 1 && <div className={`h-px flex-1 ${s.state === 'done' ? 'bg-emerald-500/60' : 'bg-slate-700'}`} />}
              </li>
            ))}
          </ol>
        </div>

        <ul className="mt-5 pt-4 border-t border-slate-800 grid gap-2.5 sm:grid-cols-3">
          {trust.map(t => (
            <li key={t.text} className="flex items-start gap-2 text-[11px] sm:text-xs text-slate-300 leading-snug">
              <t.icon className={`w-4 h-4 shrink-0 mt-px ${t.tone}`} aria-hidden="true" />
              <span>{t.text}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
