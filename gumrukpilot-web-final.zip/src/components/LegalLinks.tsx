import { useEffect, useState } from 'react';
import { X } from 'lucide-react';

// Şirket kurulunca doldurun; boşsa iletişim satırı gösterilmez.
const CONTACT_EMAIL = '';

type Doc = 'privacy' | 'terms' | null;

const TEXT = {
  tr: {
    privacy: {
      title: 'Gizlilik ve KVKK Aydınlatma Metni',
      body: [
        'GümrükPilot hesap gerektirmez. Ürün kataloğunuz, gönderileriniz, yol haritası ilerlemeniz ve tercihleriniz yalnızca cihazınızın tarayıcı deposunda saklanır; bu veriler bize iletilmez.',
        'Yapay zeka GTİP ön değerlendirmesini kullandığınızda girdiğiniz GTİP numarası, hedef ülke ve varsa ürün açıklaması işlenmek üzere sunucumuz üzerinden Google Gemini hizmetine gönderilir. Bu alanlara kişisel veri, firma sırrı veya müşteri bilgisi yazmayın.',
        'Pro lisans anahtarınız doğrulama için sunucumuza gönderilir; cihazınızda yalnızca imzalı bir doğrulama jetonu saklanır.',
        'Döviz kurları T.C. Merkez Bankası kaynağından sunucumuz üzerinden alınır. Çerez, reklam veya kullanıcı takibi kullanılmaz.',
        'Verileriniz cihazdadır: tarayıcı verisini silerseniz kaybolur. Ayarlardaki yedekleme özelliğiyle düzenli dışa aktarın.',
        'KVKK kapsamındaki haklarınız (bilgi alma, silme vb.) için aşağıdaki iletişim bilgisini kullanabilirsiniz. Bu metin şirket kuruluşu sonrası hukuki incelemeden geçirilerek güncellenecektir.',
      ],
    },
    terms: {
      title: 'Kullanım Şartları',
      body: [
        'GümrükPilot bir karar destek aracıdır; resmî danışmanlık, gümrük müşavirliği veya hukuki/mali görüş değildir.',
        'Kontrol listeleri, maliyet tahminleri ve süre hesapları bilgilendirme amaçlıdır. GTİP, vergi oranı ve belge şartları beyanname öncesi resmî kaynaklardan ve yetkili gümrük müşavirinden teyit edilmelidir.',
        'Yapay zeka çıktıları tahmindir ve doğrulanmamıştır. Kural verisi henüz bir gümrük müşaviri tarafından onaylanmamıştır; "Uzman Doğrulama Modu" raporları ancak ad girilip onaylandığında bir uzman beyanı içerir.',
        'Bu araçtaki bilgilere dayanarak yapılan işlemlerden doğan zararlardan GümrükPilot sorumlu tutulamaz.',
        'Pro lisansı kişiye özeldir; paylaşılması veya yeniden satılması yasaktır.',
      ],
    },
    close: 'Kapat', contact: 'İletişim', privacyBtn: 'Gizlilik / KVKK', termsBtn: 'Kullanım Şartları',
  },
  en: {
    privacy: {
      title: 'Privacy Notice',
      body: [
        'GümrükPilot needs no account. Your catalog, shipments, roadmap progress and preferences are stored only in your browser on your device and are not sent to us.',
        'When you use the AI HS-code pre-assessment, the HS code, destination country and optional product description you enter are sent through our server to Google Gemini for processing. Do not enter personal data, trade secrets or customer information there.',
        'Your Pro licence key is sent to our server for verification; only a signed verification token is stored on your device.',
        'Exchange rates are fetched from the Central Bank of Türkiye via our server. We use no cookies, ads or user tracking.',
        'Your data lives on your device and is lost if you clear browser data. Export backups regularly from Settings.',
        'This notice will be reviewed by counsel and updated after the company is incorporated.',
      ],
    },
    terms: {
      title: 'Terms of Use',
      body: [
        'GümrükPilot is a decision-support tool, not official advice, customs brokerage, or legal/financial opinion.',
        'Checklists, cost estimates and deadline calculations are informational. Confirm HS codes, duty rates and document requirements with official sources and a licensed customs broker before filing.',
        'AI output is an unverified estimate. Rule data has not yet been reviewed by a customs broker.',
        'GümrükPilot is not liable for losses arising from actions based on this tool.',
        'A Pro licence is personal and may not be shared or resold.',
      ],
    },
    close: 'Close', contact: 'Contact', privacyBtn: 'Privacy', termsBtn: 'Terms',
  },
} as const;

export default function LegalLinks({ lang, dark = false }: { lang: 'tr' | 'en'; dark?: boolean }) {
  const [open, setOpen] = useState<Doc>(null);
  const t = TEXT[lang];
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(null);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  const btn = `underline underline-offset-2 hover:opacity-80 ${dark ? 'text-slate-400' : 'text-slate-500'}`;
  const doc = open ? t[open] : null;

  return (
    <>
      <span className="inline-flex gap-3">
        <button type="button" className={btn} onClick={() => setOpen('privacy')}>{t.privacyBtn}</button>
        <button type="button" className={btn} onClick={() => setOpen('terms')}>{t.termsBtn}</button>
      </span>
      {doc && (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true" aria-label={doc.title}>
          <div className="absolute inset-0 bg-slate-950/70" onClick={() => setOpen(null)} />
          <div className="relative w-full sm:max-w-xl max-h-[85vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl bg-white text-slate-800 shadow-2xl p-5 sm:p-6 text-left">
            <div className="flex items-start justify-between gap-3 mb-3">
              <h2 className="text-base font-bold text-slate-900">{doc.title}</h2>
              <button type="button" onClick={() => setOpen(null)} aria-label={t.close} className="p-1 rounded-lg hover:bg-slate-100"><X className="w-4 h-4" /></button>
            </div>
            <div className="space-y-3 text-[13px] leading-relaxed">
              {doc.body.map((p, i) => <p key={i}>{p}</p>)}
              {CONTACT_EMAIL && <p><strong>{t.contact}:</strong> {CONTACT_EMAIL}</p>}
            </div>
            <button type="button" onClick={() => setOpen(null)} className="mt-5 w-full sm:w-auto px-5 py-2 rounded-xl bg-slate-900 text-white text-sm font-bold">{t.close}</button>
          </div>
        </div>
      )}
    </>
  );
}
