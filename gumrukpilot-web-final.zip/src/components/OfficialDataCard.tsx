import { Landmark, TrendingUp } from 'lucide-react';

const usd = (n: number) =>
  n >= 1e9 ? `${(n / 1e9).toFixed(1)} mlr $` : n >= 1e6 ? `${(n / 1e6).toFixed(1)} mn $` : `${Math.round(n / 1e3)} bin $`;

export default function OfficialDataCard({ info, lang }: { info: any; lang: 'tr' | 'en' }) {
  if (!info || (!info.tariff && !info.market)) return null;
  const tr = lang === 'tr';
  const { tariff, market } = info;
  return (
    <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-4 space-y-4">
      <div className="text-[11px] font-bold uppercase tracking-wide text-sky-800">
        {tr ? 'Resmî kaynaklardan (AI tahmini değil)' : 'From official sources (not AI estimate)'}
      </div>
      {tariff && (
        <div className="flex items-start gap-3">
          <Landmark className="w-4 h-4 text-sky-700 mt-0.5 shrink-0" aria-hidden="true" />
          <div className="text-xs text-slate-700 leading-relaxed">
            <div className="font-bold text-slate-900">{tr ? 'ABD HTS temel oranı' : 'US HTS base rate'} · {tariff.htsno}</div>
            <div>General: <strong>{tariff.general}</strong>{tariff.special ? ` · Special: ${String(tariff.special).slice(0, 80)}` : ''}</div>
            <div className="text-[11px] text-amber-800 mt-1">{tariff.note}</div>
            <div className="text-[10px] text-slate-500 mt-1">USITC · hts.usitc.gov</div>
          </div>
        </div>
      )}
      {market && (
        <div className="flex items-start gap-3">
          <TrendingUp className="w-4 h-4 text-sky-700 mt-0.5 shrink-0" aria-hidden="true" />
          <div className="text-xs text-slate-700 leading-relaxed w-full">
            <div className="font-bold text-slate-900">
              {tr ? `Pazar büyüklüğü (${market.year} ithalat): ` : `Market size (${market.year} imports): `}{usd(market.importValueUsd)}
            </div>
            <div>
              {tr ? 'Türkiye payı' : 'Türkiye share'}: <strong>{market.turkeyValueUsd ? `%${(market.turkeyShare * 100).toFixed(1)} (${usd(market.turkeyValueUsd)})` : (tr ? 'listede yok' : 'not listed')}</strong>
            </div>
            <div className="mt-1 text-slate-600">
              {tr ? 'İlk ortaklar: ' : 'Top partners: '}
              {market.topPartners.map((p: any) => `${p.partner} %${(p.share * 100).toFixed(0)}`).join(' · ')}
            </div>
            <div className="text-[10px] text-slate-500 mt-1">UN Comtrade · {tr ? 'yıllık veri, gecikmeli; 6 haneli GTİP düzeyi' : 'annual data, lagged; 6-digit HS level'}</div>
          </div>
        </div>
      )}
    </div>
  );
}
