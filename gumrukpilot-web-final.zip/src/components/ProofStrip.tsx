import { Globe2, Layers, FileText, ShieldCheck } from 'lucide-react';
import { COUNTRIES } from '../core/countries';
import { PRODUCT_CATEGORIES } from '../core/rules';

/** Rakamlar koddan okunur; elle yazılmış sayı yoktur. */
export default function ProofStrip({ lang }: { lang: 'tr' | 'en' }) {
  const tr = lang === 'tr';
  const items = [
    { icon: Globe2, value: String(COUNTRIES.length), label: tr ? 'hedef ülke' : 'destination countries' },
    { icon: Layers, value: String(PRODUCT_CATEGORIES.length), label: tr ? 'ürün kategorisi' : 'product categories' },
    { icon: FileText, value: '4', label: tr ? 'PDF: fatura · çeki · beyanname özeti · denetim raporu' : 'PDFs: invoice · packing · declaration summary · audit report' },
    { icon: ShieldCheck, value: '0', label: tr ? 'hesap, kayıt, çerez' : 'accounts, sign-ups, cookies' },
  ];
  return (
    <section aria-label={tr ? 'Öne çıkanlar' : 'Highlights'} className="px-4 sm:px-8 pt-8">
      <ul className="max-w-6xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-3">
        {items.map(i => (
          <li key={i.label} className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/60 px-4 py-3">
            <i.icon className="w-5 h-5 text-sky-400 shrink-0" aria-hidden="true" />
            <div className="min-w-0">
              <div className="text-xl font-extrabold text-white leading-none">{i.value}</div>
              <div className="text-[11px] text-slate-400 leading-snug mt-1">{i.label}</div>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
