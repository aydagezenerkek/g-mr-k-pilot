import { useEffect, useState } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

type Kind = 'success' | 'error' | 'info';
interface Item { id: number; msg: string; kind: Kind }

/** Her yerden çağrılır: notify('Kaydedildi', 'success') */
export function notify(msg: string, kind: Kind = 'info') {
  window.dispatchEvent(new CustomEvent('gp-toast', { detail: { msg, kind } }));
}

const STYLE: Record<Kind, string> = {
  success: 'border-emerald-500/40 bg-emerald-950/95 text-emerald-50',
  error: 'border-red-500/40 bg-red-950/95 text-red-50',
  info: 'border-sky-500/40 bg-slate-900/95 text-slate-50',
};
const ICON = { success: CheckCircle2, error: AlertTriangle, info: Info };

export default function ToastHost() {
  const [items, setItems] = useState<Item[]>([]);
  useEffect(() => {
    let n = 0;
    const on = (e: Event) => {
      const { msg, kind } = (e as CustomEvent).detail as { msg: string; kind: Kind };
      const id = ++n;
      setItems(p => [...p.slice(-2), { id, msg, kind }]);
      setTimeout(() => setItems(p => p.filter(i => i.id !== id)), kind === 'error' ? 6000 : 3500);
    };
    window.addEventListener('gp-toast', on);
    return () => window.removeEventListener('gp-toast', on);
  }, []);

  return (
    <div className="fixed z-[200] left-0 right-0 bottom-4 px-4 flex flex-col items-center gap-2 pointer-events-none" aria-live="polite">
      {items.map(i => {
        const Icon = ICON[i.kind];
        return (
          <div key={i.id} role="status" className={`pointer-events-auto flex items-start gap-2.5 max-w-md w-full rounded-xl border px-4 py-3 shadow-2xl backdrop-blur text-sm font-medium gp-toast-in ${STYLE[i.kind]}`}>
            <Icon className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
            <span className="flex-1 leading-snug">{i.msg}</span>
            <button type="button" aria-label="Kapat" onClick={() => setItems(p => p.filter(x => x.id !== i.id))} className="opacity-60 hover:opacity-100"><X className="w-3.5 h-3.5" /></button>
          </div>
        );
      })}
    </div>
  );
}
