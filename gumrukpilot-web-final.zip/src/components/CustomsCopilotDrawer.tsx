import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  X,
  Send,
  ArrowRight,
  Sparkles,
  ShieldAlert,
  Compass,
  CheckCircle2,
  HelpCircle,
  RotateCcw,
  ExternalLink,
  ChevronRight,
  Globe,
  Package,
  Layers
} from 'lucide-react';
import { COUNTRIES } from '../core/countries';

export type Screen =
  | 'dashboard'
  | 'shipments'
  | 'pallet'
  | 'cost'
  | 'customs'
  | 'roadmap'
  | 'mistakes'
  | 'settings'
  | 'docs'
  | 'catalog'
  | 'expert-audit'
  | 'exchange'
  | 'sync';

interface QuickOption {
  label: string;
  payload: string;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  suggestedScreen?: Screen | null;
  suggestedActionLabel?: string | null;
  quickOptions?: QuickOption[];
  isOutOfScope?: boolean;
  timestamp: string;
}

interface CustomsCopilotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (screen: Screen) => void;
  lang: 'tr' | 'en';
}

const PRODUCT_CATEGORIES = [
  { code: 'TEXTILE', labelTr: '👕 Tekstil & Giyim (Fasıl 61-63)', labelEn: 'Textile & Apparel' },
  { code: 'MACHINERY', labelTr: '⚙️ Makine & Sanayi (Fasıl 84-85)', labelEn: 'Machinery & Industrial' },
  { code: 'FOOD', labelTr: '🫒 Gıda & Tarım (Fasıl 01-24)', labelEn: 'Food & Agriculture' },
  { code: 'COSMETICS', labelTr: '🧴 Kimya & Kozmetik (Fasıl 33-38)', labelEn: 'Chemicals & Cosmetics' },
  { code: 'GENERAL', labelTr: '📦 Genel Kargo / Diğer', labelEn: 'General Cargo / Other' }
];

const NON_CUSTOMS_KEYWORDS = [
  'makarna', 'yemek tarifi', 'yemek', 'hava nasıl', 'felsefe', 'futbol', 'maç',
  'şarkı', 'film', 'dizi', 'fıkra', 'espri', 'aşk', 'burç', 'hava durumu',
  'python', 'javascript yaz', 'react kodu yaz', 'sen kimsin', 'nasılsın'
];

function evaluateCountryProductRule(countryName: string, categoryCode: string, lang: 'tr' | 'en'): { reply: string; screen: Screen; label: string; options: QuickOption[] } {
  const isEU = ['Almanya','Fransa','İtalya','İspanya','Hollanda','Belçika','Polonya','Romanya','Bulgaristan','Yunanistan','Avusturya','İsveç','Portekiz','İrlanda','Çekya','Macaristan','Danimarka','Finlandiya','Slovakya','Hırvatistan','Litvanya','Slovenya','Letonya','Estonya','Kıbrıs','Lüksemburg','Malta'].includes(countryName);

  if (isEU) {
    if (categoryCode === 'TEXTILE') {
      return {
        reply: `Tekstil ve giyim ihracatında (Fasıl 61-63) 1/95 OKK uyarınca A.TR Dolaşım Belgesi ile gümrük vergisi genellikle %0'dır. İthalat KDV (VAT) oranı ülkeye göre değişir ve ithalatçı tarafından ödenir; REACH ve azo boyar testleri zorunludur.`,
        screen: 'expert-audit',
        label: lang === 'tr' ? 'GTİP & Tarife Denetimini Aç' : 'Open HS Code Audit',
        options: [
          { label: '📄 Fatura & Çeki Listesi Hazırla', payload: 'Fatura ve çeki listesi hazırla' },
          { label: '📦 Palet & CBM Hesapla', payload: 'Palet ve CBM optimizasyonu' }
        ]
      };
    }
    if (categoryCode === 'MACHINERY') {
      return {
        reply: `Makine ve sanayi ihracatında (Fasıl 84-85) A.TR belgesi ile gümrük vergisi genellikle %0'dır. 2006/42/EC Makine Emniyeti Yönetmeliği uyarınca CE işareti ve AB Uygunluk Beyanı şarttır.`,
        screen: 'expert-audit',
        label: lang === 'tr' ? 'Makine GTİP Denetimini Aç' : 'Open Machinery Audit',
        options: [
          { label: '📄 Commercial Invoice & Packing List', payload: 'Fatura oluştur' },
          { label: '🚚 TIR Yükleme Planı (33 Palet)', payload: 'TIR palet hesaplama' }
        ]
      };
    }
    if (categoryCode === 'FOOD') {
      return {
        reply: `DİKKAT: Gıda ve tarım ürünlerinde (Fasıl 01-24) A.TR DOLAŞIM BELGESİ GEÇERSİZDİR. İndirimli tarife için EUR.1 Dolaşım Belgesi ve Tarım Bakanlığı Bitki/Hayvan Sağlık Sertifikası zorunludur.`,
        screen: 'expert-audit',
        label: lang === 'tr' ? 'Gıda GTİP & Sağlık Şartlarını İncele' : 'Check Food & Health Certs',
        options: [
          { label: '📄 Sağlık Sertifikası Evrakları', payload: 'Gıda ihracat evrakları' },
          { label: '🔍 AB TARIC Veritabanı Kontrolü', payload: 'TARIC tarife sorgusu' }
        ]
      };
    }
    return {
      reply: `Seçilen ürün grubunda 1/95 Gümrük Birliği Kararı geçerlidir. Sanayi ürünlerinde A.TR ile genellikle %0 gümrük vergisi uygulanır; kalem bazında GTİP ile teyit edin.`,
      screen: 'expert-audit',
      label: lang === 'tr' ? 'GTİP & Tarife Denetimini Aç' : 'Open Tariff Audit',
      options: [
        { label: '📄 İhracat Faturası Oluştur', payload: 'İhracat faturası hazırla' },
        { label: '💰 180 Günlük İBKB Bedel Kuralı', payload: '180 gün İBKB kuralı' }
      ]
    };
  }

  // Non-EU / FTA or MFN
  return {
    reply: `Seçilen ürün grubunda standart MFN tarifesi veya STA hükümleri uygulanır. Menşe şahadetnamesi veya EUR.1 belgesi gerekebilir.`,
    screen: 'expert-audit',
    label: lang === 'tr' ? 'GTİP & Vergi Denetimini Aç' : 'Open Tariff Audit',
    options: [
      { label: '📄 Fatura & Çeki Listesi Hazırla', payload: 'Fatura ve çeki listesi' },
      { label: '💰 İBKB Bedel Takibi', payload: '180 günlük İBKB takibi' }
    ]
  };
}

export const CustomsCopilotDrawer: React.FC<CustomsCopilotDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
  lang
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'bot',
      text:
        lang === 'tr'
          ? 'GümrükPilot Mevzuat & Sistem Yönlendiricisine hoş geldiniz. İhracat yapmak istediğiniz ülkeyi ve ürün grubunu aşağıdan seçerek saniyeler içinde kanuni şartlara ve doğru sisteme ulaşabilirsiniz.'
          : 'Welcome to CustomsPilot Navigator. Select your destination country and product category below for instant regulatory compliance and system routing.',
      quickOptions: [
        { label: '📄 Fatura & Çeki Listesi', payload: 'Fatura ve çeki listesi hazırlamak istiyorum' },
        { label: '💰 180 Günlük İBKB Bedeli', payload: '180 günlük ihracat bedeli ve İBKB kuralı nedir?' },
        { label: '🔍 GTİP & Vergi Denetimi', payload: 'GTİP ve vergi oranlarını denetlemek istiyorum' }
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Interactive Country & Product Selector state inside the drawer
  const [selectedCountry, setSelectedCountry] = useState<string>('Almanya');
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('TEXTILE');
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState<boolean>(false);

  // Alphabetically sorted countries list (Turkish locale sorting)
  const sortedCountries = [...COUNTRIES].sort((a, b) => a.nameTr.localeCompare(b.nameTr, 'tr'));

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const lower = query.toLowerCase();

      // Check out-of-scope
      const isOutOfScope = NON_CUSTOMS_KEYWORDS.some(kw => lower.includes(kw));
      if (isOutOfScope) {
        setMessages(prev => [
          ...prev,
          {
            id: `bot-${Date.now()}`,
            sender: 'bot',
            text: 'Bu asistan yalnızca GümrükPilot sistemi, uluslararası dış ticaret mevzuatı (4458 G.K.), gümrük evrakları ve sevkiyat operasyonları için yapılandırılmıştır. Kapsam dışı sorulara yanıt verilememektedir.',
            isOutOfScope: true,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        setIsLoading(false);
        return;
      }

      // Serbest sorular önce yapay zeka asistanına; hata/kota durumunda aşağıdaki kural tabanlı yönlendirmeye düşer.
      try {
        const hist = messages
          .map(m => ({ role: m.sender === 'bot' ? 'model' : 'user', text: m.text }))
          .slice(-6);
        while (hist.length && hist[0].role === 'model') hist.shift();
        const r = await fetch('/api/customs/copilot', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: query, history: hist }),
        });
        if (r.ok) {
          const j = await r.json();
          if (j && typeof j.reply === 'string' && j.reply.trim()) {
            setMessages(prev => [
              ...prev,
              {
                id: `bot-${Date.now()}`,
                sender: 'bot',
                text: j.reply,
                suggestedScreen: j.suggested_screen ?? null,
                suggestedActionLabel: j.suggested_action_label ?? null,
                quickOptions: Array.isArray(j.quick_options) ? j.quick_options.slice(0, 5) : [],
                isOutOfScope: !!j.is_out_of_scope,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ]);
            setIsLoading(false);
            return;
          }
        }
      } catch {
        /* ağ/AI hatası: kural tabanlı yanıta düş */
      }

      let matchedCountry = selectedCountry;
      for (const c of COUNTRIES) {
        if (lower.includes(c.nameTr.toLowerCase()) || lower.includes(c.nameEn.toLowerCase())) {
          matchedCountry = c.nameTr;
          break;
        }
      }

      let matchedCat = selectedCategory;
      if (lower.includes('tekstil') || lower.includes('giyim') || lower.includes('fasıl 61')) matchedCat = 'TEXTILE';
      else if (lower.includes('makine') || lower.includes('sanayi') || lower.includes('fasıl 84')) matchedCat = 'MACHINERY';
      else if (lower.includes('gıda') || lower.includes('tarım') || lower.includes('fasıl 01')) matchedCat = 'FOOD';
      else if (lower.includes('kozmetik') || lower.includes('kimya')) matchedCat = 'COSMETICS';

      if (lower.includes('fatura') || lower.includes('çeki')) {
        setMessages(prev => [
          ...prev,
          {
            id: `bot-${Date.now()}`,
            sender: 'bot',
            text: 'İhracat gümrük beyannamesi için İngilizce Ticari Fatura (Commercial Invoice) ve Koli/Palet bazlı Çeki Listesi (Packing List) zorunludur. Sistemimizden tek tıkla resmi formatta üretebilirsiniz.',
            suggestedScreen: 'docs',
            suggestedActionLabel: lang === 'tr' ? 'Fatura & Çeki Listesi Modülünü Aç' : 'Open Invoices & Docs',
            quickOptions: [
              { label: '📄 Ticari Fatura Aç', payload: 'Fatura oluştur' },
              { label: '📦 Çeki Listesi Hazırla', payload: 'Çeki listesi hazırla' }
            ],
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        setIsLoading(false);
        return;
      }

      if (lower.includes('180') || lower.includes('ibkb') || lower.includes('bedel')) {
        setMessages(prev => [
          ...prev,
          {
            id: `bot-${Date.now()}`,
            sender: 'bot',
            text: 'Türk Parası Kıymetini Koruma Hakkında 32 Sayılı Karar uyarınca, fiili ihraç tarihinden itibaren ihracat bedellerinin 180 gün içinde yurda getirilmesi ve İBKB bağlanması zorunludur.',
            suggestedScreen: 'shipments',
            suggestedActionLabel: lang === 'tr' ? 'Bedel & Sevkiyat Takibini Aç' : 'Open Proceeds Tracker',
            quickOptions: [
              { label: '⏱️ Kalan Süre Sayacı', payload: '180 gün kalan süre' },
              { label: '💱 TCMB Canlı Kurlar', payload: 'TCMB kurları' }
            ],
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        setIsLoading(false);
        return;
      }

      // Evaluate country & product rule (Country name is omitted in response text per request to avoid repetition)
      const resData = evaluateCountryProductRule(matchedCountry, matchedCat, lang);
      setMessages(prev => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'bot',
          text: resData.reply,
          suggestedScreen: resData.screen,
          suggestedActionLabel: resData.label,
          quickOptions: resData.options,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err) {
      console.error('[Copilot Error]:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickWizardSubmit = () => {
    const catObj = PRODUCT_CATEGORIES.find(c => c.code === selectedCategory);
    const catLabel = lang === 'tr' ? catObj?.labelTr : catObj?.labelEn;
    const promptText = lang === 'tr'
      ? `${selectedCountry} ülkesine ${catLabel} ihracatı yapmak istiyorum, kurallar ve vergiler nedir?`
      : `I want to export ${catLabel} to ${selectedCountry}, what are the rules and tariffs?`;
    handleSendMessage(promptText);
  };

  const handleReset = () => {
    setMessages([
      {
        id: `init-${Date.now()}`,
        sender: 'bot',
        text:
          lang === 'tr'
            ? 'Görüşme sıfırlandı. Yeni bir hedef ülke ve ürün seçebilir veya soru sorabilirsiniz.'
            : 'Conversation reset. Please select a destination country and product category.',
        quickOptions: [
          { label: '📄 Fatura & Çeki Listesi', payload: 'Fatura & çeki listesi hazırlamak istiyorum' },
          { label: '💰 180 Günlük İBKB Bedeli', payload: '180 günlük ihracat bedeli ve İBKB kuralı nedir?' }
        ],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  const getScreenDisplayName = (screen: Screen): string => {
    switch (screen) {
      case 'expert-audit':
        return lang === 'tr' ? 'GTİP & Tarife Denetimi' : 'HS Code Tariff Audit';
      case 'docs':
        return lang === 'tr' ? 'Fatura & Çeki Listesi' : 'Invoices & Documents';
      case 'pallet':
        return lang === 'tr' ? 'Palet & CBM Hesaplayıcı' : 'Pallet & CBM Planner';
      case 'cost':
        return lang === 'tr' ? 'İhracat Maliyet Hesabı' : 'Export Costing';
      case 'customs':
        return lang === 'tr' ? 'Gümrük Hazırlığı' : 'Customs Preparation';
      case 'shipments':
        return lang === 'tr' ? 'Sevkiyat & İBKB Bedel Takibi' : 'Shipments & IBKB Tracker';
      default:
        return lang === 'tr' ? 'İlgili Sayfa' : 'Related Screen';
    }
  };

  const selectedCatObj = PRODUCT_CATEGORIES.find(c => c.code === selectedCategory);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-lg bg-slate-900 border-l border-slate-800 text-slate-100 shadow-2xl flex flex-col justify-between overflow-hidden">
          {/* Header */}
          <div className="p-4 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-sky-900/30">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-sm font-bold text-white tracking-wide">
                    {lang === 'tr' ? 'AI Gümrük Rehberi' : 'AI Customs Copilot'}
                  </h3>
                  <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold">
                    ANINDA UYUM
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {lang === 'tr'
                    ? 'Ülke & Ürün Seçimi ile Hızlı Mevzuat Teşhisi'
                    : 'Instant regulatory diagnosis by country & product'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleReset}
                title={lang === 'tr' ? 'Sıfırla' : 'Reset'}
                className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                title={lang === 'tr' ? 'Kapat' : 'Close'}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive Country & Product Quick Selector Box (Alphabetical & Clean) */}
          <div className="p-3 bg-slate-950/80 border-b border-slate-800 flex flex-col gap-2.5">
            <div className="text-[11px] font-bold text-sky-400 flex items-center gap-1.5 uppercase tracking-wider">
              <Globe className="w-3.5 h-3.5" />
              <span>{lang === 'tr' ? 'Hedef Ülke & Ürün Sihirbazı' : 'Destination Country & Product Wizard'}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {/* Country Dropdown (Alphabetical) */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setIsCountryDropdownOpen(!isCountryDropdownOpen);
                    setIsCategoryDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
                >
                  <span className="truncate">{selectedCountry}</span>
                  <span className="text-slate-400 text-[10px]">&#9660;</span>
                </button>

                {isCountryDropdownOpen && (
                  <div className="absolute z-30 mt-1 w-full bg-slate-800 border border-slate-700 rounded-lg shadow-xl max-h-52 overflow-y-auto no-scrollbar">
                    {sortedCountries.map(c => (
                      <button
                        key={c.code}
                        onClick={() => {
                          setSelectedCountry(c.nameTr);
                          setIsCountryDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 text-xs hover:bg-sky-600 hover:text-white transition-colors cursor-pointer ${
                          selectedCountry === c.nameTr ? 'bg-sky-600/30 text-sky-300 font-bold' : 'text-slate-200'
                        }`}
                      >
                        {c.nameTr}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Category Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setIsCategoryDropdownOpen(!isCategoryDropdownOpen);
                    setIsCountryDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
                >
                  <span className="truncate">{lang === 'tr' ? selectedCatObj?.labelTr : selectedCatObj?.labelEn}</span>
                  <span className="text-slate-400 text-[10px]">&#9660;</span>
                </button>

                {isCategoryDropdownOpen && (
                  <div className="absolute z-30 mt-1 w-full bg-slate-800 border border-slate-700 rounded-lg shadow-xl max-h-48 overflow-y-auto no-scrollbar">
                    {PRODUCT_CATEGORIES.map(cat => (
                      <button
                        key={cat.code}
                        onClick={() => {
                          setSelectedCategory(cat.code);
                          setIsCategoryDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 text-xs hover:bg-sky-600 hover:text-white transition-colors cursor-pointer ${
                          selectedCategory === cat.code ? 'bg-sky-600/30 text-sky-300 font-bold' : 'text-slate-200'
                        }`}
                      >
                        {lang === 'tr' ? cat.labelTr : cat.labelEn}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={handleQuickWizardSubmit}
              className="w-full py-2 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-200" />
              <span>{lang === 'tr' ? 'Seçilen Kriterleri Analiz Et' : 'Analyze Selected Criteria'}</span>
            </button>
          </div>

          {/* Messages Container */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[88%] rounded-2xl p-3.5 text-xs sm:text-[13px] leading-relaxed shadow-xs ${
                    msg.sender === 'user'
                      ? 'bg-sky-600 text-white rounded-br-none'
                      : msg.isOutOfScope
                      ? 'bg-amber-950/40 border border-amber-600/40 text-amber-200 rounded-bl-none'
                      : 'bg-slate-800/90 border border-slate-700 text-slate-200 rounded-bl-none'
                  }`}
                >
                  {msg.isOutOfScope && (
                    <div className="flex items-center gap-1.5 mb-2 pb-1.5 border-b border-amber-700/40 text-[11px] font-bold text-amber-400">
                      <ShieldAlert className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                      <span>{lang === 'tr' ? 'SİSTEM & MEVZUAT DIŞI TALEP' : 'OUT-OF-SCOPE INQUIRY'}</span>
                    </div>
                  )}

                  <div className="whitespace-pre-wrap">{msg.text}</div>

                  {msg.suggestedScreen && (
                    <div className="mt-3 pt-2.5 border-t border-slate-700/70 flex flex-col gap-1.5">
                      <div className="text-[10px] uppercase font-bold text-sky-400 tracking-wider">
                        {lang === 'tr' ? 'Önerilen Sistem Ekranı:' : 'Recommended System Screen:'}
                      </div>
                      <button
                        onClick={() => {
                          onNavigate(msg.suggestedScreen!);
                          onClose();
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-sky-900/30 cursor-pointer group"
                      >
                        <div className="flex items-center gap-2">
                          <Compass className="w-3.5 h-3.5 text-sky-200 group-hover:rotate-45 transition-transform" />
                          <span>
                            {msg.suggestedActionLabel || getScreenDisplayName(msg.suggestedScreen)}
                          </span>
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-sky-200 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  )}

                  {msg.quickOptions && msg.quickOptions.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-slate-700/60">
                      <div className="text-[10px] font-semibold text-slate-400 mb-1.5">
                        {lang === 'tr' ? 'Sonraki adım:' : 'Next step:'}
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {msg.quickOptions.map((opt, oIdx) => (
                          <button
                            key={oIdx}
                            onClick={() => handleSendMessage(opt.payload)}
                            className="px-2.5 py-1 bg-slate-900/80 hover:bg-sky-500 hover:text-white text-sky-300 border border-sky-500/30 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center gap-1 shadow-xs"
                          >
                            <span>{opt.label}</span>
                            <ChevronRight className="w-3 h-3 opacity-60" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <span className="text-[10px] text-slate-500 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-start">
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl rounded-bl-none p-3.5 flex items-center gap-2 text-xs text-slate-300">
                  <div className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                  <span>
                    {lang === 'tr'
                      ? 'Gümrük mevzuatı ve vergi oranları sorgulanıyor...'
                      : 'Checking customs regulations and tariffs...'}
                  </span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Institutional Compliance Disclaimer Banner */}
          <div className="px-4 py-1.5 bg-slate-950/80 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
            <span className="flex items-center gap-1 text-slate-400">
              <CheckCircle2 className="w-3 h-3 text-emerald-400 inline" />
              {lang === 'tr'
                ? '4458 G.K. & UN Comtrade / AB TARIC Kural Tabanlı'
                : '4458 Customs Law & UN Comtrade / EU TARIC Rule-based'}
            </span>
            <span className="text-slate-400">v2.6 Uyumlu</span>
          </div>

          {/* Footer Input Form */}
          <div className="p-3 border-t border-slate-800 bg-slate-900/95">
            <form
              onSubmit={e => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder={
                  lang === 'tr'
                    ? 'Soru sorun veya GTİP girin...'
                    : 'Ask a question or type HS code...'
                }
                className="flex-1 bg-slate-950 border border-slate-700 focus:border-sky-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-colors"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!inputText.trim() || isLoading}
                className="px-3 py-2.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center shadow-xs"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
