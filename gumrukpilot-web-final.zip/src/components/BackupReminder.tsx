import { useState } from 'react';
import { HardDrive, X } from 'lucide-react';

const DAY = 86400000;

export default function BackupReminder({ lang, hasData, onGo }: { lang: 'tr' | 'en'; hasData: boolean; onGo: () => void }) {
  const [hidden, setHidden] = useState(false);
  const read = (k: string) => { try { return Number(localStorage.getItem(k) || 0); } catch { return 0; } };
  const last = read('lastBackupAt');
  const snooze = read('backupSnoozeUntil');
  if (hidden || !hasData || Date.now() < snooze || (last && Date.now() - last < 14 * DAY)) return null;
  const tr = lang === 'tr';
  return (
    <div role="status" className="flex items-center gap-3 rounded-xl border border-amber-300/60 bg-amber-50 dark:bg-amber-500/10 text-amber-900 dark:text-amber-200 px-3 py-2.5 text-xs">
      <HardDrive className="w-4 h-4 shrink-0" aria-hidden="true" />
      <span className="flex-1 leading-snug">
        {tr ? 'Verileriniz yalnızca bu cihazda. Telefon değişir veya tarayıcı temizlenirse kaybolur; şimdi yedek alın.'
            : 'Your data lives only on this device and is lost if you switch phones or clear the browser. Back it up now.'}
      </span>
      <button type="button" onClick={onGo} className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold whitespace-nowrap">{tr ? 'Yedek al' : 'Back up'}</button>
      <button type="button" aria-label={tr ? 'Sonra hatırlat' : 'Remind me later'} onClick={() => { try { localStorage.setItem('backupSnoozeUntil', String(Date.now() + 3 * DAY)); } catch {} setHidden(true); }} className="p-1 rounded hover:bg-amber-200/60"><X className="w-3.5 h-3.5" /></button>
    </div>
  );
}
