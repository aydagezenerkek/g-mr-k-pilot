import React, { useEffect, useMemo, useState } from 'react';
import SupportBanner from './components/SupportBanner';
import LegalLinks from './components/LegalLinks';
import ProofStrip from './components/ProofStrip';
import OfficialDataCard from './components/OfficialDataCard';
import { notify } from './components/Toast';
import BackupReminder from './components/BackupReminder';
import { getCached, isStale, saveCached, diffTariff } from './core/tariffCache';
import { jsPDF } from 'jspdf';
import { calculateTotalValueInUsd, checkProceedsExemption, calculateLandedCost, calculateIbkbRemainingDays } from './core/calculations';
import { buildChecklist, ProductCategory } from './core/rules';
import {
  Truck,
  Layers,
  DollarSign,
  Globe,
  Search,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Box as BoxIcon,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Maximize2,
  Calendar,
  Warehouse,
  ChevronRight,
  Calculator,
  FileText,
  FileCheck,
  Check,
  Copy,
  Receipt,
  Printer,
  Plus,
  Trash2,
  Download,
  Compass,
  ChevronDown,
  Users,
  CloudUpload,
  CloudDownload,
  Share2,
  FolderSync,
  ArrowLeft,
  X,
  Zap,
  History,
  Mail,
  MessageCircle,
  Send,
  ExternalLink,
  Tag,
  Edit2,
  Sun,
  Moon,
  Bot
} from 'lucide-react';
import { CatalogProduct, loadCatalogFromStorage, saveCatalogToStorage } from './core/catalog';
import { PAYMENT_METHODS } from './core/paymentMethods';
import { estimateTransitTime, TransportMode } from './core/transitTime';
import { CustomsCopilotDrawer } from './components/CustomsCopilotDrawer';

type Language = 'tr' | 'en';
type Screen = 'dashboard' | 'shipments' | 'pallet' | 'cost' | 'customs' | 'roadmap' | 'mistakes' | 'settings' | 'docs' | 'catalog' | 'expert-audit' | 'exchange' | 'sync';

interface CountryProfile {
  code: string;
  nameTr: string;
  nameEn: string;
  regimeTr: string;
  regimeEn: string;
  isPreferential: boolean;
  docTr: string;
  docEn: string;
  defaultDutyPct: number;
  sourceUrl?: string;
  noteTr?: string;
  noteEn?: string;
}

import { COUNTRIES } from './core/countries';

const CUSTOMS_COUNTRIES: CountryProfile[] = COUNTRIES.map(c => {
  const isCU = c.tradeRegime === 'CUSTOMS_UNION';
  const isFTA = c.tradeRegime === 'FREE_TRADE_AGREEMENT';
  return {
    code: c.code,
    nameTr: c.nameTr,
    nameEn: c.nameEn,
    regimeTr: isCU ? 'Gümrük Birliği (A.TR)' : isFTA ? 'Serbest Ticaret Anlaşması (STA)' : '3. Ülke (MFN Tarifesi)',
    regimeEn: isCU ? 'Customs Union (A.TR)' : isFTA ? 'Free Trade Agreement (FTA)' : 'Third Country (MFN Tariff)',
    isPreferential: isCU || isFTA,
    docTr: isCU ? 'A.TR Dolaşım Belgesi' : isFTA ? 'EUR.1 / Menşe Beyanı' : 'Menşe Şahadetnamesi',
    docEn: isCU ? 'A.TR Movement Certificate' : isFTA ? 'EUR.1 / Origin Declaration' : 'Certificate of Origin',
    defaultDutyPct: c.defaultDutyRate,
    sourceUrl: c.sourceUrl,
    noteTr: c.noteTr,
    noteEn: c.noteEn
  };
});

interface ProductCategoryInfo {
  code: string;
  labelTr: string;
  labelEn: string;
  densityMin: number;
  densityMax: number;
  hasBattery: boolean;
  carrierApproval: boolean;
}

const PRODUCT_CATEGORIES: ProductCategoryInfo[] = [
  { code: 'ELECTRONICS', labelTr: 'Elektronik & Batarya', labelEn: 'Electronics & Batteries', densityMin: 180, densityMax: 320, hasBattery: true, carrierApproval: true },
  { code: 'CLOTHING', labelTr: 'Giyim, Tekstil & Kumaş', labelEn: 'Clothing & Textiles', densityMin: 200, densityMax: 350, hasBattery: false, carrierApproval: false },
  { code: 'CHEMICAL', labelTr: 'Kimyasallar & Boya', labelEn: 'Chemicals & Paint', densityMin: 450, densityMax: 700, hasBattery: false, carrierApproval: true },
  { code: 'FOOD', labelTr: 'Gıda & Tarım Ürünleri', labelEn: 'Food & Agriculture', densityMin: 350, densityMax: 600, hasBattery: false, carrierApproval: false },
  { code: 'MACHINERY', labelTr: 'Makine & Sanayi Parçası', labelEn: 'Machinery & Industrial', densityMin: 300, densityMax: 600, hasBattery: false, carrierApproval: false },
  { code: 'COSMETICS', labelTr: 'Kozmetik & Kişisel Bakım', labelEn: 'Cosmetics & Personal Care', densityMin: 250, densityMax: 450, hasBattery: false, carrierApproval: true },
  { code: 'MEDICAL', labelTr: 'Tıbbi Cihaz & Sağlık', labelEn: 'Medical & Healthcare', densityMin: 200, densityMax: 400, hasBattery: false, carrierApproval: true },
  { code: 'BOOKS', labelTr: 'Kitap & Basılı Yayın', labelEn: 'Books & Printed Matter', densityMin: 350, densityMax: 550, hasBattery: false, carrierApproval: false },
  { code: 'OTHER', labelTr: 'Genel Kargo / Diğer', labelEn: 'General Cargo / Other', densityMin: 250, densityMax: 450, hasBattery: false, carrierApproval: false }
];

interface PalletStandard {
  id: string;
  nameTr: string;
  nameEn: string;
  lengthMm: number;
  widthMm: number;
  heightMm: number;
  maxWeightKg: number;
  tareWeightKg: number;
}

const PALLET_STANDARDS: PalletStandard[] = [
  { id: 'eur1', nameTr: 'Euro Palet (EUR 1)', nameEn: 'Euro Pallet (EUR 1)', lengthMm: 1200, widthMm: 800, heightMm: 144, maxWeightKg: 1500, tareWeightKg: 25 },
  { id: 'eur2', nameTr: 'Endüstriyel Palet (EUR 2)', nameEn: 'Industrial Pallet (EUR 2)', lengthMm: 1200, widthMm: 1000, heightMm: 144, maxWeightKg: 1500, tareWeightKg: 30 },
  { id: 'half', nameTr: 'Yarım Palet (EUR 6)', nameEn: 'Half Pallet (EUR 6)', lengthMm: 800, widthMm: 600, heightMm: 144, maxWeightKg: 750, tareWeightKg: 15 },
  { id: 'custom', nameTr: 'Özel Ebat', nameEn: 'Custom Dimensions', lengthMm: 1200, widthMm: 800, heightMm: 144, maxWeightKg: 1500, tareWeightKg: 25 }
];

interface VehiclePreset {
  id: string;
  nameTr: string;
  nameEn: string;
  palletCapacity: number;
  maxWeightKg: number;
}

const VEHICLE_PRESETS: VehiclePreset[] = [
  { id: 'tir', nameTr: 'Standart TIR (13.60m)', nameEn: 'Standard Semi-Trailer (13.6m)', palletCapacity: 33, maxWeightKg: 24000 },
  { id: '40hc', nameTr: "40' High Cube Konteyner", nameEn: "40' High Cube Container", palletCapacity: 25, maxWeightKg: 28500 },
  { id: '20std', nameTr: "20' Standart Konteyner", nameEn: "20' Standard Container", palletCapacity: 11, maxWeightKg: 21700 },
  { id: 'van', nameTr: 'Kamyonet / 3.5t Van', nameEn: 'Light Van', palletCapacity: 8, maxWeightKg: 1400 }
];

interface RoadmapStepItem {
  id: string;
  title: string;
  titleTr: string;
  titleEn: string;
  detail: string;
  detailTr: string;
  detailEn: string;
  route: string | null;
  routeLabel: string;
  routeLabelTr: string;
  routeLabelEn: string;
}

const ROADMAP_STEPS: RoadmapStepItem[] = [
  {
    id: 'company',
    title: 'Şirket / işletme ve vergi mükellefiyeti',
    titleTr: 'Şirket / işletme ve vergi mükellefiyeti',
    titleEn: 'Company Formation & Tax Registration',
    detail: 'Şahıs işletmesi veya şirket kur, vergi dairesinde mükellefiyet aç. Faaliyet kodunun (NACE) ürününe uygun olduğundan emin ol.',
    detailTr: 'Şahıs işletmesi veya şirket kur, vergi dairesinde mükellefiyet aç. Faaliyet kodunun (NACE) ürününe uygun olduğundan emin ol.',
    detailEn: 'Establish a sole proprietorship or company, register with the tax office, and verify your NACE activity code.',
    route: null,
    routeLabel: '',
    routeLabelTr: '',
    routeLabelEn: ''
  },
  {
    id: 'esign',
    title: 'Elektronik imza, KEP ve e-belge altyapısı',
    titleTr: 'Elektronik imza, KEP ve e-belge altyapısı',
    titleEn: 'E-Signature, Registered Email (KEP) & E-Invoicing',
    detail: 'Gümrük ve e-fatura/e-arşiv işlemleri için genellikle e-imza ya da mali mühür, KEP adresi ve e-fatura/e-arşiv kaydı gerekir. Hangilerinin gerektiğini mali müşavirine sor.',
    detailTr: 'Gümrük ve e-fatura/e-arşiv işlemleri için genellikle e-imza ya da mali mühür, KEP adresi ve e-fatura/e-arşiv kaydı gerekir. Hangilerinin gerektiğini mali müşavirine sor.',
    detailEn: 'Obtain an e-signature or financial seal, registered email (KEP), and e-invoice registration required for customs clearance.',
    route: null,
    routeLabel: '',
    routeLabelTr: '',
    routeLabelEn: ''
  },
  {
    id: 'union',
    title: 'İhracatçı Birliği kaydı',
    titleTr: 'İhracatçı Birliği kaydı',
    titleEn: "Exporters' Association Registration",
    detail: 'İhracat yapan firmalar ilgili ihracatçı birliğine kayıt olur. Küçük tutarlı veya e-ihracat gönderilerinde istisna/farklı yöntem olabilir; kendi durumunu müşavirine sor.',
    detailTr: 'İhracat yapan firmalar ilgili ihracatçı birliğine kayıt olur. Küçük tutarlı veya e-ihracat gönderilerinde istisna/farklı yöntem olabilir; kendi durumunu müşavirine sor.',
    detailEn: 'Exporters must register with their relevant regional Exporters Association before filing official export declarations.',
    route: null,
    routeLabel: '',
    routeLabelTr: '',
    routeLabelEn: ''
  },
  {
    id: 'broker',
    title: 'Gümrük müşaviri seçimi ve yetkilendirme',
    titleTr: 'Gümrük müşaviri seçimi ve yetkilendirme',
    titleEn: 'Customs Broker Selection & Authorization',
    detail: 'Güvendiğin bir gümrük müşaviri seç ve yetkilendirme (vekâlet) işlemini yap. Vekâletin şekli (noter veya elektronik) için müşavirine danış.',
    detailTr: 'Güvendiğin bir gümrük müşaviri seç ve yetkilendirme (vekâlet) işlemini yap. Vekâletin şekli (noter veya elektronik) için müşavirine danış.',
    detailEn: 'Select a licensed customs broker and execute a notarized power of attorney for representation at customs.',
    route: null,
    routeLabel: '',
    routeLabelTr: '',
    routeLabelEn: ''
  },
  {
    id: 'hs',
    title: 'Ürün sınıflandırma (GTİP) ve ülke kuralları',
    titleTr: 'Ürün sınıflandırma (GTİP) ve ülke kuralları',
    titleEn: 'HS Code Classification & Country Rules',
    detail: 'Ürününün 12 haneli GTİP\'ini belirle; ihracat izin/denetimi ve varış ülkesi şartlarını kontrol et.',
    detailTr: 'Ürününün 12 haneli GTİP\'ini belirle; ihracat izin/denetimi ve varış ülkesi şartlarını kontrol et.',
    detailEn: 'Determine the 12-digit national HS (GTIP) code; check export inspection, permits, and destination tariff conditions.',
    route: 'customs',
    routeLabel: 'Gümrük Hazırlığı\'nı aç',
    routeLabelTr: 'Gümrük Hazırlığı\'nı aç',
    routeLabelEn: 'Open Customs Prep'
  },
  {
    id: 'docs',
    title: 'Belgeler: fatura, çeki listesi, menşe, sertifikalar',
    titleTr: 'Belgeler: fatura, çeki listesi, menşe, sertifikalar',
    titleEn: 'Commercial Documents & Certificates',
    detail: 'Ticari fatura ve çeki listesini hazırla; gerekiyorsa A.TR/EUR.1/menşe ve ürüne özel sertifikaları al.',
    detailTr: 'Ticari fatura ve çeki listesini hazırla; gerekiyorsa A.TR/EUR.1/menşe ve ürüne özel sertifikaları al.',
    detailEn: 'Prepare commercial invoice and packing list; obtain A.TR, EUR.1, certificate of origin, or mandatory compliance certs.',
    route: 'docs',
    routeLabel: 'Fatura ve Çeki Listesi\'ni aç',
    routeLabelTr: 'Fatura ve Çeki Listesi\'ni aç',
    routeLabelEn: 'Open Invoices & Docs'
  },
  {
    id: 'terms',
    title: 'Teslim şekli, ödeme şekli ve lojistik',
    titleTr: 'Teslim şekli, ödeme şekli ve lojistik',
    titleEn: 'Incoterms, Payment Terms & Logistics',
    detail: 'Incoterms ve ödeme şeklini (peşin, akreditif, vadeli) belirle; navlun, sigorta ve ahşap ambalaj (ISPM-15) planını yap.',
    detailTr: 'Incoterms ve ödeme şeklini (peşin, akreditif, vadeli) belirle; navlun, sigorta ve ahşap ambalaj (ISPM-15) planını yap.',
    detailEn: 'Agree on Incoterms and payment terms (advance, L/C, CAD); arrange freight, marine insurance, and ISPM-15 wood packaging.',
    route: 'pallet',
    routeLabel: 'Palet / CBM\'yi aç',
    routeLabelTr: 'Palet / CBM\'yi aç',
    routeLabelEn: 'Open Pallet & CBM'
  },
  {
    id: 'export',
    title: 'Gümrük çıkışı ve sevkiyat',
    titleTr: 'Gümrük çıkışı ve sevkiyat',
    titleEn: 'Customs Clearance & Dispatch',
    detail: 'İhracat beyannamesi veya uygun ise ETGB ile gümrükten çıkışı yap; sevkiyatı kaydet ve takip et.',
    detailTr: 'İhracat beyannamesi veya uygun ise ETGB ile gümrükten çıkışı yap; sevkiyatı kaydet ve takip et.',
    detailEn: 'File the export customs declaration (or micro-export ETGB); dispatch cargo and track the consignment in transit.',
    route: 'shipments',
    routeLabel: 'Sevkiyat Takibi\'ni aç',
    routeLabelTr: 'Sevkiyat Takibi\'ni aç',
    routeLabelEn: 'Open Shipment Tracking'
  },
  {
    id: 'proceeds',
    title: 'Bedelin tahsili: 180 gün, İBKB, KDV iadesi',
    titleTr: 'Bedelin tahsili: 180 gün, İBKB, KDV iadesi',
    titleEn: 'Proceeds Repatriation: 180 Days & IBKB',
    detail: 'İhracat bedelini fiili ihraç (kapanış / VEDOP) tarihinden itibaren 180 günde yurda getirip İBKB bağlayın. TCMB genelgesi uyarınca belirlenen oran Merkez Bankası\'na bozdurulur (Ek-2 muaf ülkeler hariç). Sözleşmede 180 günden uzun vade varsa süre vade bitiminden itibaren 90 gündür; müteahhit ihracatında 365 gün. Güncel Genelge'den teyit edin.',
    detailTr: 'İhracat bedelini fiili ihraç (kapanış / VEDOP) tarihinden itibaren 180 günde yurda getirip İBKB bağlayın. TCMB genelgesi uyarınca belirlenen oran Merkez Bankası\'na bozdurulur (Ek-2 muaf ülkeler hariç). Sözleşmede 180 günden uzun vade varsa süre vade bitiminden itibaren 90 gündür; müteahhit ihracatında 365 gün. Güncel Genelge'den teyit edin.',
    detailEn: 'Repatriate export proceeds within 180 days from the actual export date (VEDOP closure) to issue IBKB. Mandatory conversion applies per CBRT rules (excluding Ek-2 exempt countries).',
    route: 'shipments',
    routeLabel: 'Bedel takibini aç',
    routeLabelTr: 'Bedel takibini aç',
    routeLabelEn: 'Open Proceeds Tracker'
  }
];

interface BeginnerGuideStep {
  id: number;
  titleTr: string;
  titleEn: string;
  descTr: string;
  descEn: string;
  docsTr: string[];
  docsEn: string[];
  tipTr: string;
  tipEn: string;
  actionRoute?: Screen;
  actionLabelTr?: string;
  actionLabelEn?: string;
}

const BEGINNER_GUIDE_STEPS: BeginnerGuideStep[] = [
  {
    id: 1,
    titleTr: "1. Şirket Kurulumu & Vergi Dairesi Kaydı",
    titleEn: "1. Company Formation & Tax Registration",
    descTr: "Resmi ihracat faturası kesebilmek ve gümrükte tescil işlemi yapabilmek için aktif bir şahıs işletmesi, Limited Şirket (Ltd. Şti.) veya Anonim Şirket (A.Ş.) sahibi olmanız şarttır.",
    descEn: "You must have an active sole proprietorship, LLC, or Joint Stock Company to issue official export invoices and lodge declarations at customs.",
    docsTr: ["Vergi Levhası", "İmza Sirküleri / İmza Beyannamesi", "Ticaret Sicil Gazetesi (Tüzel şirketler için)", "Nüfus Cüzdanı Fotokopisi"],
    docsEn: ["Tax Plate", "Authorized Signature Circular", "Trade Registry Gazette", "ID Copies"],
    tipTr: "Yeni başlayanlar için kuruluşu en hızlı (1 iş gününde) ve masrafı en düşük olan şahıs firması tercih edilebilir.",
    tipEn: "Sole proprietorships are the fastest (1 business day) and cheapest to register for beginner exporters."
  },
  {
    id: 2,
    titleTr: "2. İhracatçılar Birliği (İB) Üyeliği",
    titleEn: "2. Exporters' Association Membership",
    descTr: "Gümrük Kanunu uyarınca Türkiye'den gümrük beyannamesiyle resmi ihracat yapacak her firma, faaliyet alanındaki İhracatçılar Birliği'ne (İİB, EİB, OAİB vb.) kayıt olmakla yükümlüdür.",
    descEn: "By law, every entity exporting goods from Turkey under a customs declaration must be registered with the relevant Exporters' Association.",
    docsTr: ["İB Üyelik Başvuru Formu", "Noter Onaylı İmza Sirküleri", "Vergi Levhası Fotokopisi", "Birlik Giriş Aidatı Dekontu"],
    docsEn: ["Membership Application Form", "Notarized Signature Circular", "Tax Plate Copy", "Entry Fee Payment Receipt"],
    tipTr: "Üyelik başvurusu online ortamda e-Devlet üzerinden hızla onaylanır ve sisteme 24 saat içinde işlenir.",
    tipEn: "Applications are processed quickly online via e-Government and reflected in customs systems within 24 hours."
  },
  {
    id: 3,
    titleTr: "3. Gümrük Müşaviri Yetkilendirmesi (Noter Onaylı)",
    titleEn: "3. Customs Broker Authorization (Notarized)",
    descTr: "Gümrük idarelerinde firmanız adına beyanname tescili, fiziki muayene ve gümrükleme işlemlerini yürütebilmesi için T.C. Ticaret Bakanlığı lisanslı bir Gümrük Müşavirine noterden vekaletname verilmelidir.",
    descEn: "You must grant a notarized power of attorney to a licensed Customs Broker to act and clear cargo on your behalf with customs administrations.",
    docsTr: ["Gümrük Vekaletnamesi (Noter Onaylı)", "Gümrük Müşavirliği Hizmet Sözleşmesi", "BİLGE Sistemi Firma Tanımlama Formu"],
    docsEn: ["Customs Power of Attorney", "Brokerage Service Agreement", "BILGE System Company Registration"],
    tipTr: "Gümrük müşaviriniz, ürünlerinizin doğru GTİP tespiti ve ihracat teşviklerinden yararlanmanızda en önemli stratejik ortağınızdır.",
    tipEn: "Your licensed customs broker will be your primary strategic partner for tariff classification and export incentives.",
    actionRoute: 'expert-audit',
    actionLabelTr: "Uzman Doğrulama Modu'nu Aç",
    actionLabelEn: "Open Expert Audit Mode"
  },
  {
    id: 4,
    titleTr: "4. GTİP (HS Code) Belirleme & Ürün Analizi",
    titleEn: "4. Determine HS Code (GTİP) & Product Classification",
    descTr: "İhraç edilecek her ürünün Dünya Gümrük Örgütü (WCO) standartlarında 6 haneli, Türkiye'de ise 12 haneli Gümrük Tarife İstatistik Pozisyonu (GTİP) kodu doğru tespit edilmelidir. Yanlış tarife cezai yaptırıma tabidir.",
    descEn: "Every export item must be classified under a 6-digit international HS Code and 12-digit national GTİP code. Incorrect codes incur severe fines.",
    docsTr: ["Ürün Teknik Özellik Kataloğu", "Malzeme İçerik Listesi (BOM)", "Laboratuvar / İçerik Analiz Raporu (gıda, kimya ve tekstil için)"],
    docsEn: ["Product Technical Specification", "Bill of Materials (BOM)", "Laboratory / Content Analysis Report (food, chemicals, textiles)"],
    tipTr: "GümrükPilot platformundaki 'Gümrük Hazırlık' sekmesindeki GTİP arama motoru ve akıllı kütüphaneyi ücretsiz kullanabilirsiniz.",
    tipEn: "Use the built-in HS Code search engine and smart directory under 'Customs Prep'.",
    actionRoute: 'customs',
    actionLabelTr: "Gümrük & GTİP Hazırlığı'na Git",
    actionLabelEn: "Go to Customs & HS Prep"
  },
  {
    id: 5,
    titleTr: "5. Zorunlu Resmi Dış Ticaret Belgeleri",
    titleEn: "5. Mandatory Commercial Export Documents",
    descTr: "Gümrük muayenesi ve alıcı ülkenin ithalat kontrolleri için uluslararası standartlara tam uyumlu ticari belgelerin eksiksiz hazırlanması şarttır.",
    descEn: "Mandatory international documents must be meticulously prepared for customs clearance and border controls in the destination country.",
    docsTr: [
      "Ticari Fatura (Alıcı için Commercial Invoice; Türkiye çıkışı için GİB 301 kodlu Gümrük e-Faturası)",
      "Çeki Listesi (Packing List - Koli, Brüt/Net Ağırlık, CBM)",
      "Dolaşım & Menşe Belgeleri (AB sanayi için A.TR Dolaşım, STA için EUR.1 Tercihli Menşe, 3. ülkeler için Menşe Şahadetnamesi)",
      "Uluslararası Taşıma Belgesi (CMR, Denizyolu Konşimentosu / Bill of Lading, Havayolu AWB)"
    ],
    docsEn: [
      "Commercial Export Invoice (Commercial Invoice for buyer; GİB Customs e-Invoice for TR clearance)",
      "Packing List (Box counts, Gross/Net Weight, CBM)",
      "Circulation & Origin Proofs (A.TR Free Circulation for EU, EUR.1 Preferential Origin for FTA, Certificate of Origin for MFN)",
      "International Transport Document (CMR, Bill of Lading, Air Waybill)"
    ],
    tipTr: "GümrükPilot 'Fatura & Evrak' modülü ile alıcınız için proforma/ticari fatura ve çeki listenizi gümrük formatında PDF olarak 1 dakikada oluşturabilirsiniz.",
    tipEn: "Use GümrükPilot's 'Invoice & Docs' tool to generate compliant commercial invoices and packing lists in PDF for your overseas buyer.",
    actionRoute: 'docs',
    actionLabelTr: "Fatura & Çeki Listesi Oluştur",
    actionLabelEn: "Generate Invoice & Packing List"
  },
  {
    id: 6,
    titleTr: "6. Lojistik, Navlun & Teslim Şekli (Incoterms)",
    titleEn: "6. Logistics, Freight & Delivery Terms (Incoterms)",
    descTr: "Müşterinizle taşıma masraflarının ve risklerinin kime ait olduğunu belirleyen Incoterms kuralı (EXW, FOB, CFR, CIF, DAP vb.) kararlaştırılmalı ve güvenilir bir lojistik taşıyıcı ile navlun anlaşması yapılmalıdır.",
    descEn: "You and your buyer must agree on an Incoterms rule (EXW, FOB, CFR, CIF, DAP) governing freight obligations, risk transfer, and transport bookings.",
    docsTr: ["Uluslararası Lojistik Taşıma Sözleşmesi", "Navlun Teklifi ve Rezervasyon Teyidi", "Emtia Nakliyat Sigortası (özellikle CIF / CIP teslimlerde zorunlu)"],
    docsEn: ["International Transport Agreement", "Freight Booking Confirmation", "Marine Cargo Insurance Policy (mandatory for CIF/CIP)"],
    tipTr: "Uygulamamızdaki 'Palet Analizi' ve 'Maliyet Hesaplayıcı' araçlarıyla araç doluluğunu ve toplam nakliye maliyetinizi önceden simüle edin.",
    tipEn: "Simulate container/pallet space utilization and landed transport costs using our integrated Pallet & Cost Calculators.",
    actionRoute: 'pallet',
    actionLabelTr: "Palet & CBM Analizini Aç",
    actionLabelEn: "Open Pallet & CBM Analysis"
  }
];

const TOP_MISTAKES = [
  {
    id: 1,
    titleTr: "Eksik veya Yanlış GTİP Kodu Seçimi",
    titleEn: "Incorrect or Missing HS (GTİP) Code",
    descTr: "Ürününüzün 12 haneli gümrük kodunu yanlış beyan etmek, gümrükte cezalara, ürünün bekletilmesine veya yanlış vergi ödenmesine neden olur.",
    descEn: "Misclassifying your product leads to customs fines, delays, or incorrect duty payments.",
    linkRoute: "customs",
    linkTitleTr: "GTİP Denetimi'ne git",
    linkTitleEn: "Go to HS Engine"
  },
  {
    id: 2,
    titleTr: "Fatura ve Çeki Listesi Tutarsızlığı",
    titleEn: "Invoice vs. Packing List Discrepancies",
    descTr: "Faturadaki kalem miktarları ile çeki listesindeki paket içeriklerinin birebir örtüşmemesi, gümrük muayenesinde en büyük kırmızı bayraktır.",
    descEn: "Mismatches between item quantities and package contents are major red flags during inspection.",
    linkRoute: "docs",
    linkTitleTr: "Evrak Oluşturucu'yu aç",
    linkTitleEn: "Open Doc Generator"
  },
  {
    id: 3,
    titleTr: "ISPM-15 Standartı Olmayan Ahşap Palet Kullanımı",
    titleEn: "Using Non-ISPM-15 Wood Pallets",
    descTr: "Isıl işlem görmemiş (damgasız) ahşap paletler çoğu ülke gümrüğünden geri çevrilir. Plastik veya sertifikalı ahşap palet kullanın.",
    descEn: "Untreated wood pallets are rejected by most customs. Use plastic or certified heat-treated pallets.",
    linkRoute: "pallet",
    linkTitleTr: "Palet Analizi'ni aç",
    linkTitleEn: "Open Pallet Engine"
  },
  {
    id: 4,
    titleTr: "EORI Numarası Kontrolü Yapmadan AB'ye Sevkiyat",
    titleEn: "EU Shipments Without EORI Validation",
    descTr: "Avrupa Birliği'ne yapılan ihracatlarda alıcının aktif bir EORI numarası yoksa gümrük işlemleri tamamlanamaz.",
    descEn: "Exporting to the EU requires the consignee to have an active EORI number for clearance.",
    linkRoute: "customs",
    linkTitleTr: "Kontrol Listesi'ni gör",
    linkTitleEn: "View Checklist"
  },
  {
    id: 5,
    titleTr: "180 Günlük İhracat Bedeli Takibini İhmal Etmek",
    titleEn: "Neglecting 180-Day Payment Deadline",
    descTr: "İhracat bedelinin gümrük beyannamesi kapanışından itibaren 180 gün içinde yurda getirilmesi (İBKB) yasal zorunluluktur (istisnalar hariç).",
    descEn: "Most export proceeds must be repatriated within 180 days by law (with some exceptions).",
    linkRoute: "shipments",
    linkTitleTr: "Bedel Takibi'ni aç",
    linkTitleEn: "Open Proceeds Tracker"
  },
  {
    id: 6,
    titleTr: "Yanlış Incoterm (Teslim Şekli) Seçimi",
    titleEn: "Wrong Incoterm Selection",
    descTr: "EXW ve DDP gibi uç terimlerde, beyanname açma veya varış gümrük ödemeleri konusunda sorumluluklar karıştırılmaktadır.",
    descEn: "Responsibilities for export/import clearance are often confused in EXW or DDP terms.",
    linkRoute: "cost",
    linkTitleTr: "Maliyet Simülatörü'ne git",
    linkTitleEn: "Go to Cost Simulator"
  },
  {
    id: 7,
    titleTr: "Eksik Menşe Belgesi (A.TR / EUR.1)",
    titleEn: "Missing Origin Certificates",
    descTr: "Ülke rejimine göre gerekli dolaşım belgesinin eksik olması, alıcının gümrük muafiyetinden yararlanamamasına ve satışın riske girmesine yol açar.",
    descEn: "Missing A.TR or EUR.1 certificates prevent buyers from using duty exemptions.",
    linkRoute: "customs",
    linkTitleTr: "Rejim Kontrolü yap",
    linkTitleEn: "Check Regime"
  },
  {
    id: 8,
    titleTr: "Lityum Pil Sevkiyatlarında UN 38.3 İhmali",
    titleEn: "Neglecting UN 38.3 for Lithium Batteries",
    descTr: "Pilli ürünlerde MSDS ve UN 38.3 test raporları olmadan havayolu veya karayolu taşıyıcıları yükü kabul etmeyecektir.",
    descEn: "MSDS and UN 38.3 reports are mandatory for any electronic product containing batteries.",
    linkRoute: "shipments",
    linkTitleTr: "Ön Değerlendirme'yi aç",
    linkTitleEn: "Open Advisor"
  },
  {
    id: 9,
    titleTr: "Ambalaj ve Etiket Uyumsuzluğu",
    titleEn: "Packaging & Labeling Mismatch",
    descTr: "Koli üzerindeki etiketlerdeki 'Made in' ibaresi veya miktar bilgileri fatura ile uyuşmalıdır. Uyumsuzluk tam tespit muayenesine neden olur.",
    descEn: "'Made in' labels and quantities on boxes must match the invoice to avoid manual exams.",
    linkRoute: "docs",
    linkTitleTr: "Çeki Listesi'ni hazırla",
    linkTitleEn: "Prep Packing List"
  },
  {
    id: 10,
    titleTr: "CIF ve FOB Terimlerini Karıştırmak",
    titleEn: "Confusing CIF and FOB",
    descTr: "Navlun ve sigorta ödemesinin kimin sorumluluğunda olduğu karıştırılınca beklenmedik ek maliyetler ve operasyonel duraksamalar yaşanır.",
    descEn: "Mixing up who pays freight and insurance leads to unexpected costs and delays.",
    linkRoute: "cost",
    linkTitleTr: "Maliyet Kalemleri'ne bak",
    linkTitleEn: "View Cost Items"
  }
];

export default function App() {
  const [lang, setLang] = useState<Language>('tr');
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('gumrukpilot_theme');
    if (saved === 'light' || saved === 'dark') return saved;
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  });

  useEffect(() => {
    localStorage.setItem('gumrukpilot_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  // Açılışta karşılama + destek durumu her seferinde gösterilir.
  const [hasSeenWelcome, setHasSeenWelcome] = useState<boolean>(false);

  // Navigation History Stack & Quick Return
  const [activeScreen, setActiveScreenState] = useState<Screen>('dashboard');
  const [screenHistory, setScreenHistory] = useState<Screen[]>([]);
  const [isQuickDrawerOpen, setIsQuickDrawerOpen] = useState(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);

  const SCREEN_TITLES: Record<Screen, { tr: string; en: string }> = {
    dashboard: { tr: 'Ana Panel', en: 'Dashboard' },
    shipments: { tr: 'Sevkiyat Takibi', en: 'Shipment Tracking' },
    pallet: { tr: 'Palet / CBM Analizi', en: 'Pallet / CBM' },
    cost: { tr: 'Maliyet & Kâr Hesabı', en: 'Cost Calculator' },
    customs: { tr: 'Gümrük Hazırlığı', en: 'Customs Prep' },
    roadmap: { tr: 'Yol Haritası', en: 'Roadmap' },
    mistakes: { tr: 'En Sık Hatalar', en: 'Top Mistakes' },
    settings: { tr: 'Ayarlar & Lisans', en: 'Settings & License' },
    docs: { tr: 'Fatura & Çeki Listesi', en: 'Invoices & Docs' },
    catalog: { tr: 'Ürün Kataloğu', en: 'Product Catalog' },
    'expert-audit': { tr: 'Uzman Doğrulama Modu', en: 'Expert Audit Mode' },
    exchange: { tr: 'Döviz Kurları', en: 'Exchange Rates' },
    sync: { tr: 'Dosya Tabanlı Ekip Paylaşımı (Google Drive / OneDrive Uyumlu)', en: 'File-Based Team Sharing (Drive / OneDrive Compatible)' }
  };

  const [licenseKey, setLicenseKey] = useState('');
  const [licenseToken, setLicenseToken] = useState(() => localStorage.getItem('licenseToken') || '');
  const [isPro, setIsPro] = useState(false);

  // Pro durumu yalnızca sunucunun imzalı token doğrulamasından gelir; localStorage'daki bir bayrakla açılamaz.
  useEffect(() => {
    localStorage.removeItem('isPro');
    localStorage.removeItem('licenseKey');
    if (!licenseToken) { setIsPro(false); return; }
    let cancelled = false;
    fetch('/api/license/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: licenseToken }),
    })
      .then(r => r.json())
      .then(j => {
        if (cancelled) return;
        if (j?.valid === true) setIsPro(true);
        else { setIsPro(false); if (j?.reason === 'invalid' || j?.reason === 'expired') { localStorage.removeItem('licenseToken'); setLicenseToken(''); } }
      })
      .catch(() => { if (!cancelled) setIsPro(false); });
    return () => { cancelled = true; };
  }, [licenseToken]);

  const navigateTo = (target: Screen) => {
    if (target === activeScreen) return;
    setScreenHistory(prev => {
      const filtered = prev.filter(s => s !== target);
      return [...filtered, activeScreen];
    });
    setActiveScreenState(target);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const setActiveScreen = (target: string | Screen) => {
    navigateTo(target as Screen);
  };

  const dismissWelcome = (targetScreen: Screen = 'dashboard') => {
    localStorage.setItem('hasSeenWelcome', 'true');
    setHasSeenWelcome(true);
    setActiveScreen(targetScreen);
  };

  const showWelcomeAgain = () => {
    localStorage.removeItem('hasSeenWelcome');
    setHasSeenWelcome(false);
  };

  const goBack = () => {
    if (screenHistory.length === 0) return;
    const prev = screenHistory[screenHistory.length - 1];
    setScreenHistory(h => h.slice(0, h.length - 1));
    setActiveScreenState(prev);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const previousScreen = screenHistory.length > 0 ? screenHistory[screenHistory.length - 1] : null;

  // Touch Swipe Gesture Detection for Mobile
  const [touchStartPos, setTouchStartPos] = useState<{ x: number; y: number } | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartPos({ x: e.touches[0].clientX, y: e.touches[0].clientY });
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartPos) return;
    const diffX = e.changedTouches[0].clientX - touchStartPos.x;
    const diffY = e.changedTouches[0].clientY - touchStartPos.y;
    setTouchStartPos(null);

    if (Math.abs(diffX) > 75 && Math.abs(diffX) > Math.abs(diffY) * 1.5) {
      if (diffX > 0 && previousScreen) {
        goBack();
      }
    }
  };

  // Exchange rates
  type Rate = {
    code: string;
    nameTr: string;
    nameEn: string;
    rate: number;
    change: string;
    symbol: string;
  };

  const fallbackRates: Rate[] = [
    { code: 'EUR', nameTr: 'Euro', nameEn: 'Euro', rate: 55.76, change: '+0.32%', symbol: '€' },
    { code: 'USD', nameTr: 'Amerikan Doları', nameEn: 'US Dollar', rate: 48.85, change: '+0.18%', symbol: '$' },
    { code: 'GBP', nameTr: 'İngiliz Sterlini', nameEn: 'British Pound', rate: 64.86, change: '-0.12%', symbol: '£' },
    { code: 'CHF', nameTr: 'İsviçre Frangı', nameEn: 'Swiss Franc', rate: 59.20, change: '+0.05%', symbol: 'Fr' },
    { code: 'CNY', nameTr: 'Çin Yuanı', nameEn: 'Chinese Yuan', rate: 7.28, change: '+0.24%', symbol: '¥' },
  ];

  const [rates, setRates] = useState<Rate[]>(fallbackRates);
  const [isUpdatingRates, setIsUpdatingRates] = useState(false);
  const [rateUpdateError, setRateUpdateError] = useState('');

  const updateRates = async () => {
    setIsUpdatingRates(true);
    setRateUpdateError('');

    try {
      let xmlText = '';
      try {
        const response = await fetch('/api/tcmb');
        if (response.ok) {
          xmlText = await response.text();
        }
      } catch {}

      if (!xmlText) {
        throw new Error('TCMB verisi alınamadı.');
      }

      const xml = new DOMParser().parseFromString(xmlText, 'text/xml');
      const updatedRates = fallbackRates.map((item) => {
        const currency = Array.from(
          xml.getElementsByTagName('Currency')
        ).find(
          (element) => element.getAttribute('Kod') === item.code
        );

        const sellingValue = currency
          ?.getElementsByTagName('ForexSelling')[0]
          ?.textContent
          ?.replace(',', '.');

        const parsedRate = Number(sellingValue);

        return {
          ...item,
          rate: Number.isFinite(parsedRate) && parsedRate > 0 ? parsedRate : item.rate,
        };
      });

      setRates(updatedRates);
    } catch (error) {
      console.error('Kur güncelleme hatası:', error);
      setRateUpdateError('TCMB verisine ulaşılamadı. Aşağıdaki değerler son kayıtlı değerlerdir.');
    } finally {
      setIsUpdatingRates(false);
    }
  };

  useEffect(() => {
    updateRates();
  }, []);

  // Pallet analysis form state
  const [selectedPalletId, setSelectedPalletId] = useState<string>('eur1');
  const [boxLength, setBoxLength] = useState<number>(400);
  const [boxWidth, setBoxWidth] = useState<number>(300);
  const [boxHeight, setBoxHeight] = useState<number>(250);
  const [boxWeight, setBoxWeight] = useState<number>(12.5);
  const [maxHeight, setMaxHeight] = useState<number>(1800);
  const [totalBoxes, setTotalBoxes] = useState<number>(180);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('tir');
  const [view3D, setView3D] = useState<boolean>(false);

  // Exchange rate converter state
  const [convertAmount, setConvertAmount] = useState<number>(2500);
  const [sourceCurrency, setSourceCurrency] = useState<string>('EUR');
  const [customsFreightEur, setCustomsFreightEur] = useState<number>(3200);
  const [customsDutyPct, setCustomsDutyPct] = useState<number>(6.5);
  const [vatPct, setVatPct] = useState<number>(20);

  // Cost Calculator state
  const [costMode, setCostMode] = useState<'road' | 'sea' | 'air' | 'rail'>('road');
  const [costOrigin, setCostOrigin] = useState('İstanbul (Ambarlı)');
  const [costDestination, setCostDestination] = useState('Münih (Freimann)');
  const [costBaseFreight, setCostBaseFreight] = useState<number>(2850);
  const [costCurrency, setCostCurrency] = useState<'EUR' | 'USD' | 'TRY'>('EUR');
  const [costBafPct, setCostBafPct] = useState<number>(8.5);
  const [costThc, setCostThc] = useState<number>(180);
  const [costDocFee, setCostDocFee] = useState<number>(65);
  const [costCustomsFee, setCostCustomsFee] = useState<number>(140);
  const [costGoodsValue, setCostGoodsValue] = useState<number>(45000);
  const [costInsurancePct, setCostInsurancePct] = useState<number>(0.35);
  const [costCargoWeightKg, setCostCargoWeightKg] = useState<number>(18400);
  const [costPalletCount, setCostPalletCount] = useState<number>(33);
  const [copiedQuote, setCopiedQuote] = useState(false);

  // Customs Prep state
  const [customsCountryCode, setCustomsCountryCode] = useState<string>('DE');
  const [customsCategory, setCustomsCategory] = useState<ProductCategory>('ELECTRONICS');
  const [customsHsCode, setCustomsHsCode] = useState<string>('8471.30.00.00.00');
  const [customsGoodsValue, setCustomsGoodsValue] = useState<number>(35000);
  const [customsCurrency, setCustomsCurrency] = useState<'EUR' | 'USD'>('EUR');
  const [customsFreightCost, setCustomsFreightCost] = useState<number>(2800);
  const [customsInsuranceCost, setCustomsInsuranceCost] = useState<number>(150);
  const [customsHasPreferential, setCustomsHasPreferential] = useState<boolean>(true);
  const [customsCheckedDocs, setCustomsCheckedDocs] = useState<Record<string, boolean>>({
    doc_commercial_invoice: true,
    doc_packing_list: true,
    doc_atr: true
  });
  const [customsIncoterm, setCustomsIncoterm] = useState<'EXW' | 'FOB' | 'CIF' | 'CIP' | 'DAP' | 'DDP'>('DAP');
  const [customsPaymentMethod, setCustomsPaymentMethod] = useState<string>('cash_in_advance');

  // Invoice & Documentation state
  const [invoiceNumber, setInvoiceNumber] = useState('INV-2026-0941');
  const [invoiceDate, setInvoiceDate] = useState('29.09.2026');
  const [invoiceSeller, setInvoiceSeller] = useState('GümrükPilot Lojistik & Dış Ticaret A.Ş.');
  const [invoiceSellerAddress, setInvoiceSellerAddress] = useState('Büyükdere Cad. No: 142 Levent, İstanbul / Türkiye');
  const [invoiceSellerTaxId, setInvoiceSellerTaxId] = useState('TR-3891048291');
  const [invoiceBuyer, setInvoiceBuyer] = useState('Almanya Import GmbH');
  const [invoiceBuyerAddress, setInvoiceBuyerAddress] = useState('Industriestrasse 48, 60314 Frankfurt, Germany');
  const [invoiceBuyerTaxId, setInvoiceBuyerTaxId] = useState('DE-815294821');
  const [invoiceIncoterm, setInvoiceIncoterm] = useState('DAP');
  const [invoiceCurrency, setInvoiceCurrency] = useState('EUR');
  const [invoiceItems, setInvoiceItems] = useState([
    { id: '1', description: 'Endüstriyel Otomasyon Sensörleri', hsCode: '8471.30.00.00.00', qty: 250, unit: 'PCS', unitPrice: 85, vatPct: 20 },
    { id: '2', description: 'Servo Motor Sürücü Kartları', hsCode: '8504.40.82.00.00', qty: 120, unit: 'PCS', unitPrice: 145, vatPct: 20 }
  ]);
  const [invoiceNotes, setInvoiceNotes] = useState('Ödeme Vadesi: 30 Gün. Teslim Şekli: DAP Frankfurt.');
  const [newItemDesc, setNewItemDesc] = useState('');
  const [newItemHs, setNewItemHs] = useState('');
  const [newItemQty, setNewItemQty] = useState(10);
  const [newItemPrice, setNewItemPrice] = useState(50);
  const [invoiceLang, setInvoiceLang] = useState<Language>('tr');

  // Product Catalog CRUD state (persisted in localStorage)
  const [productCatalog, setProductCatalog] = useState<CatalogProduct[]>(() => loadCatalogFromStorage());
  const [catalogSearch, setCatalogSearch] = useState('');
  const [editingCatalogId, setEditingCatalogId] = useState<string | null>(null);
  const [catalogFormName, setCatalogFormName] = useState('');
  const [catalogFormHs, setCatalogFormHs] = useState('');
  const [catalogFormCategory, setCatalogFormCategory] = useState('ELECTRONICS');
  const [catalogFormPrice, setCatalogFormPrice] = useState<number>(100);
  const [catalogFormCurrency, setCatalogFormCurrency] = useState('EUR');
  const [catalogFormUnit, setCatalogFormUnit] = useState('PCS');

  useEffect(() => {
    saveCatalogToStorage(productCatalog);
  }, [productCatalog]);

  const handleSaveCatalogProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catalogFormName.trim()) return;

    if (editingCatalogId) {
      setProductCatalog(prev =>
        prev.map(p =>
          p.id === editingCatalogId
            ? {
                ...p,
                name: catalogFormName.trim(),
                hsCode: catalogFormHs.trim() || '8471.30.00.00.00',
                category: catalogFormCategory,
                unitPrice: Number(catalogFormPrice) || 0,
                currency: catalogFormCurrency,
                unit: catalogFormUnit
              }
            : p
        )
      );
      setEditingCatalogId(null);
    } else {
      const newProd: CatalogProduct = {
        id: `prod-${Date.now()}`,
        name: catalogFormName.trim(),
        hsCode: catalogFormHs.trim() || '8471.30.00.00.00',
        category: catalogFormCategory,
        unitPrice: Number(catalogFormPrice) || 0,
        currency: catalogFormCurrency,
        unit: catalogFormUnit,
        createdAt: new Date().toISOString().split('T')[0]
      };
      setProductCatalog(prev => [newProd, ...prev]);
    }

    setCatalogFormName('');
    setCatalogFormHs('');
    setCatalogFormPrice(100);
  };

  const handleEditCatalogProduct = (prod: CatalogProduct) => {
    setEditingCatalogId(prod.id);
    setCatalogFormName(prod.name);
    setCatalogFormHs(prod.hsCode);
    setCatalogFormCategory(prod.category);
    setCatalogFormPrice(prod.unitPrice);
    setCatalogFormCurrency(prod.currency);
    setCatalogFormUnit(prod.unit);
  };

  const handleDeleteCatalogProduct = (id: string) => {
    setProductCatalog(prev => prev.filter(p => p.id !== id));
    if (editingCatalogId === id) {
      setEditingCatalogId(null);
      setCatalogFormName('');
      setCatalogFormHs('');
    }
  };

  // Invoice Share State
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareCopied, setShareCopied] = useState(false);

  const generateInvoiceShareText = () => {
    const totalAmount = invoiceItems.reduce((acc, item) => acc + (item.qty * item.unitPrice), 0);
    const itemsText = invoiceItems
      .map((item, i) => `${i + 1}. ${item.description} (GTİP: ${item.hsCode}) - ${item.qty} ${item.unit} x ${item.unitPrice.toFixed(2)} ${invoiceCurrency} = ${(item.qty * item.unitPrice).toFixed(2)} ${invoiceCurrency}`)
      .join('\n');

    return `📄 TICARI FATURA / COMMERCIAL INVOICE
=========================================
Fatura No: ${invoiceNumber}
Tarih: ${invoiceDate}
Teslim Şekli: ${invoiceIncoterm}
Döviz Cinsi: ${invoiceCurrency}

🏢 İHRACATÇI / EXPORTER:
${invoiceSeller}
${invoiceSellerAddress}
Vergi / EORI: ${invoiceSellerTaxId}

🏬 ALICI / CONSIGNEE:
${invoiceBuyer}
${invoiceBuyerAddress}
VAT / EORI: ${invoiceBuyerTaxId}

📦 KALEMLER / ITEMS:
${itemsText}

-----------------------------------------
GENEL TOPLAM: ${totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${invoiceCurrency}
-----------------------------------------
Notlar: ${invoiceNotes}
Oluşturan: GümrükPilot Logistics OS`;
  };

  const handleNativeShare = async () => {
    const text = generateInvoiceShareText();
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Ticari Fatura ${invoiceNumber} - ${invoiceBuyer}`,
          text: text,
        });
        return;
      } catch (err) {}
    }
    setIsShareModalOpen(true);
  };

  const handleCopyShareText = () => {
    const text = generateInvoiceShareText();
    navigator.clipboard.writeText(text);
    setShareCopied(true);
    setTimeout(() => setShareCopied(false), 2500);
  };

  // Customs Summary PDF / Text Generator
  const generateCustomsSummaryText = () => {
    const allItems = allCustomsChecklistItems;
    const checkedItems = allItems.filter(i => customsCheckedDocs[i.id]);

    return `📄 GÜMRÜK BEYANNAME HAZIRLIK ÖZETİ (GÜMRÜKÇÜ İÇİN)
==================================================
Hedef Ülke: ${selectedCountry.nameTr} (${customsCountryCode})
Ürün Kategorisi: ${customsCategory}
GTİP / HS Kodu: ${customsHsCode}
CIF Mal Bedeli: ${customsCifOriginal.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${customsCurrency}
Tercihli Rejim / A.TR: ${customsHasPreferential ? 'Var (Muafiyet Uygulanır)' : 'Yok'}

✅ HAZIR OLAN BELGELER:
${checkedItems.map(i => `[x] ${i.title} (${i.severity})`).join('\n')}

❌ EKSİK VEYA BEKLEYEN BELGELER:
${allItems.filter(i => !customsCheckedDocs[i.id]).map(i => `[ ] ${i.title} (${i.severity})`).join('\n')}

--------------------------------------------------
Oluşturan: GümrükPilot Logistics OS
Kural Verisi Son Güncelleme (resmi kaynaktan teyit edin): ${customsChecklistPlan.dataVerifiedOn}`;
  };

  const sanitizeTurkishForPdf = (str: string) => {
    if (!str) return '';
    const map: Record<string, string> = {
      'ş': 's', 'Ş': 'S',
      'ğ': 'g', 'Ğ': 'G',
      'ı': 'i', 'İ': 'I',
      'ç': 'c', 'Ç': 'C',
      'ö': 'o', 'Ö': 'O',
      'ü': 'u', 'Ü': 'U'
    };
    return str.replace(/[şŞğĞıİçÇöÖüÜ]/g, match => map[match] || match);
  };

  const addWatermark = (doc: jsPDF) => {
    if (isPro) return;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(40);
    doc.setTextColor(200, 200, 200);
    doc.text("GUMRUKPILOT FREE", 30, 150, { angle: 45 });
    doc.setTextColor(0, 0, 0);
  };

  const shareOrDownloadPdf = async (pdfDoc: jsPDF, fileName: string) => {
    const blob = pdfDoc.output('blob');
    const file = new File([blob], fileName, { type: 'application/pdf' });

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: fileName,
          text: `${fileName} paylaşıldı.`,
        });
        return;
      } catch (err) {
        if (err instanceof Error && err.name !== 'AbortError') {
          console.error('Sharing failed', err);
        } else {
          return; // User cancelled
        }
      }
    }

    // Fallback to download
    pdfDoc.save(fileName);
  };

  const handleDownloadCustomsSummary = (share: boolean = false) => {
    const doc = new jsPDF();
    addWatermark(doc);
    // ... (rest of the function)
    doc.setFont("helvetica", "bold");
    doc.setFontSize(15);
    doc.text(sanitizeTurkishForPdf("GÜMRÜK BEYANNAME HAZIRLIK ÖZETİ"), 14, 20);

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(sanitizeTurkishForPdf(`Hedef Ülke: ${selectedCountry.nameTr} (${customsCountryCode})`), 14, 28);
    doc.text(sanitizeTurkishForPdf(`Ürün Kategorisi: ${customsCategory}`), 14, 34);
    doc.text(sanitizeTurkishForPdf(`GTİP / HS Kodu: ${customsHsCode}`), 14, 40);
    doc.text(sanitizeTurkishForPdf(`CIF Mal Bedeli: ${customsCifOriginal.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${customsCurrency}`), 14, 46);
    doc.text(sanitizeTurkishForPdf(`Tercihli Rejim / A.TR: ${customsHasPreferential ? 'Var (Muafiyet Uygulanır)' : 'Yok'}`), 14, 52);

    let y = 62;
    doc.setFont("helvetica", "bold");
    doc.text(sanitizeTurkishForPdf("KONTROL LİSTESİ VE BELGE DURUMU:"), 14, y);
    y += 8;

    doc.setFont("helvetica", "normal");
    const allItems = allCustomsChecklistItems;
    allItems.forEach((item, idx) => {
      const isChecked = Boolean(customsCheckedDocs[item.id]);
      const statusStr = isChecked 
        ? (lang === 'tr' ? "[HAZIR / OK]" : "[READY / OK]") 
        : (lang === 'tr' ? "[EKSİK]" : "[MISSING]");
      const itemTitle = lang === 'tr' ? item.title : (item.titleEn || item.title);
      const itemDetail = lang === 'tr' ? item.detail : (item.detailEn || item.detail);
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(sanitizeTurkishForPdf(`${idx + 1}. ${itemTitle} - ${statusStr}`), 14, y);
      y += 6;
      doc.setFontSize(8.5);
      doc.setTextColor(100);
      doc.text(sanitizeTurkishForPdf(`${lang === 'tr' ? 'Detay' : 'Detail'}: ${itemDetail}`), 18, y);
      doc.setFontSize(10);
      doc.setTextColor(0);
      y += 8;
    });

    if (y > 260) {
      doc.addPage();
      y = 20;
    }
    y += 10;
    doc.text(sanitizeTurkishForPdf(`Oluşturan: GümrükPilot Logistics OS`), 14, y);
    doc.text(sanitizeTurkishForPdf(`Kural Verisi Son Güncelleme (resmi kaynaktan teyit edin): ${customsChecklistPlan.dataVerifiedOn}`), 14, y + 6);

    const fileName = `Gumruk-Beyanname-Ozeti-${customsCountryCode}.pdf`;
    if (share) {
      shareOrDownloadPdf(doc, fileName);
    } else {
      doc.save(fileName);
    }
  };

  const invoiceLabels = {
    tr: {
      invoiceTitle: "TICARI FATURA",
      packingListTitle: "CEKI LISTESI",
      invoiceNo: "Fatura No",
      date: "Tarih",
      exporter: "IHRACATCI",
      consignee: "ALICI",
      taxId: "Vergi No",
      vatId: "VAT/EORI No",
      items: "URUNLER",
      packingDetails: "PAKETLEME DETAYLARI",
      total: "TOPLAM",
      quantity: "Miktar",
    },
    en: {
      invoiceTitle: "COMMERCIAL INVOICE",
      packingListTitle: "PACKING LIST",
      invoiceNo: "Invoice No",
      date: "Date",
      exporter: "EXPORTER",
      consignee: "CONSIGNEE",
      taxId: "Tax ID",
      vatId: "VAT/EORI No",
      items: "ITEMS",
      packingDetails: "PACKING DETAILS",
      total: "TOTAL",
      quantity: "Quantity",
    }
  };

  const handleDownloadInvoicePdf = (share: boolean = false) => {
    const labels = invoiceLabels[invoiceLang];
    const doc = new jsPDF();
    addWatermark(doc);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text(sanitizeTurkishForPdf(labels.invoiceTitle), 14, 20);

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(sanitizeTurkishForPdf(`${labels.invoiceNo}: ${invoiceNumber}`), 14, 30);
    doc.text(sanitizeTurkishForPdf(`${labels.date}: ${invoiceDate}`), 14, 36);

    doc.setFont("helvetica", "bold");
    doc.text(sanitizeTurkishForPdf(`${labels.exporter}:`), 14, 46);
    doc.setFont("helvetica", "normal");
    doc.text(sanitizeTurkishForPdf(invoiceSeller), 14, 52);
    doc.text(sanitizeTurkishForPdf(invoiceSellerAddress), 14, 58);
    doc.text(sanitizeTurkishForPdf(`${labels.taxId}: ${invoiceSellerTaxId}`), 14, 64);

    doc.setFont("helvetica", "bold");
    doc.text(sanitizeTurkishForPdf(`${labels.consignee}:`), 14, 74);
    doc.setFont("helvetica", "normal");
    doc.text(sanitizeTurkishForPdf(invoiceBuyer), 14, 80);
    doc.text(sanitizeTurkishForPdf(invoiceBuyerAddress), 14, 86);
    doc.text(sanitizeTurkishForPdf(`${labels.vatId}: ${invoiceBuyerTaxId}`), 14, 92);

    let y = 105;
    doc.setFont("helvetica", "bold");
    doc.text(sanitizeTurkishForPdf(`${labels.items}:`), 14, y);
    y += 8;

    invoiceItems.forEach((item, idx) => {
      doc.setFont("helvetica", "normal");
      doc.text(sanitizeTurkishForPdf(`${idx + 1}. ${item.description} (GTIP: ${item.hsCode})`), 14, y);
      y += 6;
      doc.text(sanitizeTurkishForPdf(`${item.qty} ${item.unit} x ${item.unitPrice.toFixed(2)} ${invoiceCurrency} = ${(item.qty * item.unitPrice).toFixed(2)} ${invoiceCurrency}`), 20, y);
      y += 8;
    });

    const total = invoiceItems.reduce((acc, item) => acc + (item.qty * item.unitPrice), 0);
    doc.setFont("helvetica", "bold");
    doc.text(sanitizeTurkishForPdf(`${labels.total}: ${total.toLocaleString()} ${invoiceCurrency}`), 14, y + 5);

    const fileName = `Fatura-${invoiceNumber}.pdf`;
    if (share) {
      shareOrDownloadPdf(doc, fileName);
    } else {
      doc.save(fileName);
    }
  };

  const handleDownloadPackingListPdf = (share: boolean = false) => {
    const labels = invoiceLabels[invoiceLang];
    const doc = new jsPDF();
    addWatermark(doc);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text(sanitizeTurkishForPdf(labels.packingListTitle), 14, 20);

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(sanitizeTurkishForPdf(`${labels.invoiceNo}: ${invoiceNumber}`), 14, 30);
    doc.text(sanitizeTurkishForPdf(`${labels.date}: ${invoiceDate}`), 14, 36);

    let y = 50;
    doc.setFont("helvetica", "bold");
    doc.text(sanitizeTurkishForPdf(`${labels.packingDetails}:`), 14, y);
    y += 8;

    invoiceItems.forEach((item, idx) => {
      doc.setFont("helvetica", "normal");
      doc.text(sanitizeTurkishForPdf(`${idx + 1}. ${item.description}`), 14, y);
      y += 6;
      doc.text(sanitizeTurkishForPdf(`${labels.quantity}: ${item.qty} ${item.unit}`), 20, y);
      y += 8;
    });

    const fileName = `Ceki-Listesi-${invoiceNumber}.pdf`;
    if (share) {
      shareOrDownloadPdf(doc, fileName);
    } else {
      doc.save(fileName);
    }
  };

  const [expertAuditNotes, setExpertAuditNotes] = useState<Record<string, { status: 'CORRECT' | 'INCORRECT' | 'PENDING'; note: string }>>({});
  const [inspectorName, setInspectorName] = useState('');
  const [isReportConfirmed, setIsReportConfirmed] = useState(false);

  // GTİP ön değerlendirme durumu (uzman tablosu → cihaz önbelleği → Gemini)
  const [aiAuditHsCode, setAiAuditHsCode] = useState('8471.30.00.00.00');
  const [aiAuditCountry, setAiAuditCountry] = useState('Almanya');
  const [aiAuditLoading, setAiAuditLoading] = useState(false);
  const [aiAuditResult, setAiAuditResult] = useState<any>(null);
  const [officialInfo, setOfficialInfo] = useState<any>(null);
  const [aiAuditError, setAiAuditError] = useState<string | null>(null);
  const [aiAuditActiveTab, setAiAuditActiveTab] = useState<'hybrid-ai' | 'checklist'>('hybrid-ai');
  const [aiAuditCopied, setAiAuditCopied] = useState(false);

  const handleRunAiAudit = async (force: boolean = false) => {
    setOfficialInfo(null);
    // Resmî kaynaklar (ABD HTS + Comtrade) AI'dan bağımsız, paralel ve sessizce; hata olursa kart gizli kalır.
    fetch(`/api/market?hs=${encodeURIComponent(aiAuditHsCode)}&country=${encodeURIComponent(aiAuditCountry)}`)
      .then(r => (r.ok ? r.json() : null))
      .then(j => setOfficialInfo(j))
      .catch(() => setOfficialInfo(null));
    setAiAuditLoading(true);
    setAiAuditError(null);
    try {
      // 1) Cihaz önbelleği: taze kayıt varsa AI'ya gitmeden göster.
      const cached = getCached(aiAuditHsCode, aiAuditCountry);
      if (cached && !force && !isStale(cached)) {
        setAiAuditResult({ source: 'device_cache', data: { ...cached.data, cached_at: cached.savedAt } });
        return;
      }
      // 2) Sunucu: uzman tablosu, yoksa Gemini. Kayıt bayatsa/zorlanmışsa yeniden kontrol + fark günlüğü.
      const res = await fetch('/api/customs/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hsCode: aiAuditHsCode, targetCountry: aiAuditCountry }),
      });
      const data = await res.json();
      if (!res.ok) {
        // AI kotası/hatası: eski kayıt varsa onu göster (bayat uyarısıyla)
        if (cached) {
          setAiAuditResult({ source: 'device_cache', data: { ...cached.data, cached_at: cached.savedAt, stale: true } });
          setAiAuditError((data.error || 'Yenileme başarısız.') + ' Son kayıtlı sonuç gösteriliyor.');
          return;
        }
        throw new Error(data.error || 'Denetim sorgusu başarısız oldu.');
      }
      const log = cached ? diffTariff(cached.data, data.data) : undefined;
      const next = log ? { ...data, data: { ...data.data, comparison_log: log } } : data;
      saveCached(aiAuditHsCode, aiAuditCountry, data.data, data.source);
      setAiAuditResult(next);
    } catch (err: any) {
      setAiAuditError(err.message || 'Yapay zeka denetimi sırasında bağlantı hatası oluştu.');
    } finally {
      setAiAuditLoading(false);
    }
  };

  const handleCopyAiJson = () => {
    if (!aiAuditResult) return;
    navigator.clipboard.writeText(JSON.stringify(aiAuditResult.data, null, 2));
    setAiAuditCopied(true);
    setTimeout(() => setAiAuditCopied(false), 2000);
  };

  const generateExpertAuditReportText = () => {
    const allItems = allCustomsChecklistItems;
    const itemsReport = allItems.map(i => {
      const audit = expertAuditNotes[i.id] || { status: 'PENDING', note: '' };
      const statusText = audit.status === 'CORRECT' ? 'DOĞRU / ONAYLI' : audit.status === 'INCORRECT' ? 'YANLIŞ / EKSİK' : 'BEKLEMEDE';
      return `- [${audit.status === 'CORRECT' ? 'X' : ' '}] ${i.title} (${i.severity})
  Durum: ${statusText}
  Gümrükçü Notu: ${audit.note || 'Not girilmedi'}`;
    }).join('\n\n');


    return `🏛️ GÜMRÜKÇÜ UZMAN DOĞRULAMA & DENETİM RAPORU
==================================================
Hedef Ülke: ${selectedCountry.nameTr} (${customsCountryCode})
Kategori: ${customsCategory}
GTİP: ${customsHsCode}
CIF Değer: ${customsCifOriginal.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${customsCurrency}
Tarih: ${new Date().toLocaleDateString('tr-TR')}

📋 KONTROL LİSTESİ DENETİM SONUÇLARI:
${itemsReport}

--------------------------------------------------
${expertStatementLines().join('\n')}
Oluşturan: GümrükPilot Logistics OS`;
  };

  const expertStatementLines = (): string[] =>
    isReportConfirmed && inspectorName.trim()
      ? [`Bu denetim ${inspectorName.trim()} tarafindan ${new Date().toISOString()} itibariyla gerceklestirilmistir.`,
         'Uzmanin ruhsat/sicil no ve imzasi ayrica rapor uzerine eklenmelidir; bu cikti tek basina resmi belge degildir.']
      : ['UZMAN ONAYI YOKTUR: Bu rapor bir gumruk musaviri tarafindan onaylanmamis taslaktir.',
         'Resmi gecerliligi yoktur; beyanname oncesi yetkili gumruk musaviri ile teyit ediniz.'];

  const handleDownloadExpertAuditTxt = () => {
    const text = generateExpertAuditReportText();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Gumrukcu-Uzman-Denetim-Raporu-${customsCountryCode}-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadExpertAuditPdf = (share: boolean = false) => {
    const doc = new jsPDF();
    addWatermark(doc);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(15);
    doc.text(sanitizeTurkishForPdf("GÜMRÜKÇÜ UZMAN DOĞRULAMA & DENETİM RAPORU"), 14, 20);

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(sanitizeTurkishForPdf(`Hedef Ülke: ${selectedCountry.nameTr} (${customsCountryCode})`), 14, 28);
    doc.text(sanitizeTurkishForPdf(`Ürün Kategorisi: ${customsCategory}`), 14, 34);
    doc.text(sanitizeTurkishForPdf(`GTİP: ${customsHsCode}`), 14, 40);
    doc.text(sanitizeTurkishForPdf(`CIF Değer: ${customsCifOriginal.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${customsCurrency}`), 14, 46);
    doc.text(sanitizeTurkishForPdf(`Tarih: ${new Date().toLocaleDateString('tr-TR')}`), 14, 52);

    let y = 62;
    doc.setFont("helvetica", "bold");
    doc.text(sanitizeTurkishForPdf("KONTROL LİSTESİ DENETİM SONUÇLARI:"), 14, y);
    y += 8;

    doc.setFont("helvetica", "normal");
    const allItems = allCustomsChecklistItems;
    allItems.forEach((item, idx) => {
      const audit = expertAuditNotes[item.id] || { status: 'PENDING', note: '' };
      const statusText = audit.status === 'CORRECT' 
        ? (lang === 'tr' ? 'DOĞRU / ONAYLI' : 'CORRECT / APPROVED')
        : audit.status === 'INCORRECT' 
        ? (lang === 'tr' ? 'YANLIŞ / EKSİK' : 'INCORRECT / MISSING') 
        : (lang === 'tr' ? 'BEKLEMEDE' : 'PENDING');
      const itemTitle = lang === 'tr' ? item.title : (item.titleEn || item.title);
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(sanitizeTurkishForPdf(`${idx + 1}. ${itemTitle} - [${statusText}]`), 14, y);
      y += 6;
      doc.setFontSize(8.5);
      doc.setTextColor(100);
      const noteLabel = lang === 'tr' ? 'Gümrükçü Notu' : 'Auditor Note';
      const noNoteText = lang === 'tr' ? 'Not girilmedi' : 'No note entered';
      doc.text(sanitizeTurkishForPdf(`${noteLabel}: ${audit.note || noNoteText}`), 18, y);
      doc.setFontSize(10);
      doc.setTextColor(0);
      y += 8;
    });

    if (y > 260) {
      doc.addPage();
      y = 20;
    }
    y += 10;
    doc.setFont("helvetica", "bolditalic");
    expertStatementLines().forEach((ln, i) => doc.text(ln.slice(0, 110), 14, y + i * 6));
    doc.setFont("helvetica", "normal");
    doc.text(sanitizeTurkishForPdf(`Oluşturan: GümrükPilot`), 14, y + 18);

    const fileName = `Gumrukcu-Uzman-Denetim-Raporu-${customsCountryCode}.pdf`;
    if (share) {
      shareOrDownloadPdf(doc, fileName);
    } else {
      doc.save(fileName);
    }
  };

  // Dashboard search and filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const pallet = useMemo(() => PALLET_STANDARDS.find(p => p.id === selectedPalletId) || PALLET_STANDARDS[0], [selectedPalletId]);
  const vehicle = useMemo(() => VEHICLE_PRESETS.find(v => v.id === selectedVehicleId) || VEHICLE_PRESETS[0], [selectedVehicleId]);

  // Pallet calculation
  const calculation = useMemo(() => {
    const pL = pallet.lengthMm;
    const pW = pallet.widthMm;
    const pH = pallet.heightMm;

    const bL = Math.max(10, boxLength);
    const bW = Math.max(10, boxWidth);
    const bH = Math.max(10, boxHeight);
    const bWt = Math.max(0.1, boxWeight);

    const countX1 = Math.floor(pL / bL);
    const countY1 = Math.floor(pW / bW);
    const total1 = countX1 * countY1;

    const countX2 = Math.floor(pL / bW);
    const countY2 = Math.floor(pW / bL);
    const total2 = countX2 * countY2;

    const useRotated = total2 > total1;
    const bestBoxesPerLayer = Math.max(1, useRotated ? total2 : total1);
    const countX = useRotated ? countX2 : countX1;
    const countY = useRotated ? countY2 : countY1;
    const placedW = useRotated ? bW : bL;
    const placedH = useRotated ? bL : bW;

    const availableH = Math.max(bH, maxHeight - pH);
    const layers = Math.max(1, Math.floor(availableH / bH));
    const boxesPerPallet = bestBoxesPerLayer * layers;
    const totalPallets = Math.max(1, Math.ceil(totalBoxes / boxesPerPallet));

    const palletNetKg = boxesPerPallet * bWt;
    const palletGrossKg = palletNetKg + pallet.tareWeightKg;
    const totalGrossKg = totalPallets * palletGrossKg;

    const totalEnvelopeM3 = (pL / 1000) * (pW / 1000) * ((pH + (layers * bH)) / 1000);
    const boxesM3 = (bL / 1000) * (bW / 1000) * (bH / 1000) * boxesPerPallet;
    const volumeEfficiency = totalEnvelopeM3 > 0 ? Math.min(100, (boxesM3 / totalEnvelopeM3) * 100) : 0;

    const overhangX = Math.max(0, (countX * placedW) - pL);
    const overhangY = Math.max(0, (countY * placedH) - pW);

    const startX = Math.max(0, (pL - (countX * placedW)) / 2);
    const startY = Math.max(0, (pW - (countY * placedH)) / 2);

    const positions: Array<{ x: number; y: number; w: number; h: number }> = [];
    for (let r = 0; r < countY; r++) {
      for (let c = 0; c < countX; c++) {
        positions.push({
          x: startX + (c * placedW),
          y: startY + (r * placedH),
          w: placedW,
          h: placedH
        });
      }
    }

    const vehicleUtilization = (totalPallets / vehicle.palletCapacity) * 100;

    return {
      bestBoxesPerLayer,
      layers,
      boxesPerPallet,
      totalPallets,
      palletGrossKg,
      totalGrossKg,
      totalEnvelopeM3,
      volumeEfficiency,
      overhangX,
      overhangY,
      positions,
      countX,
      countY,
      placedW,
      placedH,
      vehicleUtilization
    };
  }, [pallet, boxLength, boxWidth, boxHeight, boxWeight, maxHeight, totalBoxes, vehicle]);

  const currentRate = rates.find(r => r.code === sourceCurrency)?.rate ?? 55.76;
  const convertedTry = convertAmount * currentRate;

  // Shipments Data & States
  const initialShipments = [
    { id: 'GP-8841-ROT', origin: 'İstanbul (Ambarlı)', destination: 'Rotterdam (Haven)', statusTr: 'Yolda', statusEn: 'In Transit', statusKey: 'TRANSIT', pallets: 33, weight: 19450, mode: 'Karayolu TIR', carrier: 'Anadolu Lojistik', date: '2026-09-24', note: 'Öncelikli sevkiyat' },
    { id: 'GP-9204-MUN', origin: 'İzmir (Aliağa)', destination: 'Münih (Freimann)', statusTr: 'Gümrükte', statusEn: 'In Customs', statusKey: 'CUSTOMS', pallets: 28, weight: 16800, mode: 'İntermodal', carrier: 'Marmara Taşımacılık', date: '2026-09-23', note: '' },
    { id: 'GP-7719-GEN', origin: 'Mersin Limanı', destination: 'Cenova (Porto)', statusTr: 'Yolda', statusEn: 'In Transit', statusKey: 'TRANSIT', pallets: 25, weight: 21300, mode: 'Denizyolu Ro-Ro', carrier: 'Ege Nakliyat', date: '2026-09-22', note: '' },
    { id: 'GP-6150-VIE', origin: 'Bursa (OSB)', destination: 'Viyana (Inzersdorf)', statusTr: 'Teslim Edildi', statusEn: 'Delivered', statusKey: 'DELIVERED', pallets: 33, weight: 18200, mode: 'Karayolu TIR', carrier: 'Toros Kargo', date: '2026-09-21', note: 'Sorunsuz tamamlandı' }
  ];

  const [shipmentsList, setShipmentsList] = useState(() => {
    try {
      const saved = localStorage.getItem('tracked_shipments_web');
      return saved ? JSON.parse(saved) : initialShipments;
    } catch {
      return initialShipments;
    }
  });

  useEffect(() => {
    localStorage.setItem('tracked_shipments_web', JSON.stringify(shipmentsList));
  }, [shipmentsList]);

  // Shipment form states
  const [editingShipmentId, setEditingShipmentId] = useState<string | null>(null);
  const [formCode, setFormCode] = useState('');
  const [formOrigin, setFormOrigin] = useState('');
  const [formDestination, setFormDestination] = useState('');
  const [formCategory, setFormCategory] = useState('ELECTRONICS');
  const [formCountryCode, setFormCountryCode] = useState('DE');
  const [formGoodsValue, setFormGoodsValue] = useState('');
  const [formFreight, setFormFreight] = useState('');
  const [formStatusKey, setFormStatusKey] = useState('PREPARING');
  const [formMode, setFormMode] = useState('Karayolu TIR');
  const [formCarrier, setFormCarrier] = useState('');
  const [formPallets, setFormPallets] = useState('');
  const [formWeight, setFormWeight] = useState('');
  const [formDate, setFormDate] = useState('');
  const [formNote, setFormNote] = useState('');
  const [formErrors, setFormErrors] = useState<string[]>([]);

  const selectedCategoryObj = PRODUCT_CATEGORIES.find(c => c.code === formCategory) || PRODUCT_CATEGORIES[0];
  const selectedCountryObj = CUSTOMS_COUNTRIES.find(c => c.code === formCountryCode) || CUSTOMS_COUNTRIES[0];
  const currentWeightNum = Number(formWeight) || 0;
  const currentGoodsValueNum = Number(formGoodsValue) || 0;
  const currentFreightNum = Number(formFreight) || 0;

  const shipmentAdvice = useMemo(() => {
    const catMapping: Record<string, ProductCategory> = {
      ELECTRONICS: 'ELECTRONICS',
      CLOTHING: 'CLOTHING',
      CHEMICAL: 'CHEMICALS',
      FOOD: 'FOOD',
      MACHINERY: 'MACHINERY',
      COSMETICS: 'COSMETICS',
      MEDICAL: 'MEDICAL',
      PLANT_ANIMAL: 'PLANT_ANIMAL'
    };
    const mappedCategory: ProductCategory = catMapping[selectedCategoryObj.code] || 'OTHER';

    const checklistResult = buildChecklist(selectedCountryObj.code, mappedCategory, {
      declaredValue: currentGoodsValueNum,
      hasLithiumBattery: selectedCategoryObj.hasBattery
    });

    const allItems = checklistResult.sections.flatMap(s => s.items);
    const blockers = allItems.filter(i => i.severity === 'BLOCKER').map(i => `${i.title}: ${i.detail}`);
    const requirements = allItems.filter(i => i.severity === 'REQUIRED' || i.severity === 'WARNING').map(i => `${i.title}`);

    let acceptance: 'RESTRICTED' | 'CONDITIONAL' | 'OK' = 'OK';
    if (blockers.length > 0) {
      acceptance = 'RESTRICTED';
    } else if (requirements.length > 0 && selectedCategoryObj.code !== 'OTHER' && selectedCategoryObj.code !== 'BOOKS') {
      acceptance = 'CONDITIONAL';
    }

    let palletsEstimate = null;
    if (currentWeightNum > 0) {
      const min = Math.max(1, Math.ceil(currentWeightNum / selectedCategoryObj.densityMax));
      const max = Math.max(1, Math.ceil(currentWeightNum / selectedCategoryObj.densityMin));
      const suggested = Math.max(1, Math.ceil(currentWeightNum / ((selectedCategoryObj.densityMin + selectedCategoryObj.densityMax) / 2)));
      palletsEstimate = { min, max, suggested, lowKg: selectedCategoryObj.densityMin, highKg: selectedCategoryObj.densityMax };
    }

    let costEstimate = null;
    if (currentGoodsValueNum > 0) {
      const isEU = ['DE', 'FR', 'IT'].includes(selectedCountryObj.code);
      const isFTA = ['GB', 'AZ'].includes(selectedCountryObj.code);
      const dutyPct = (isEU || isFTA) ? 0 : selectedCountryObj.defaultDutyPct;
      const vatPctVal = isEU ? 19 : 20;

      const res = calculateLandedCost(currentGoodsValueNum, currentFreightNum, dutyPct, vatPctVal);

      costEstimate = {
        duty: res.duty,
        vat: res.vat,
        taxesLow: res.total * 0.95 - (currentGoodsValueNum + currentFreightNum),
        taxesHigh: res.total * 1.05 - (currentGoodsValueNum + currentFreightNum),
        totalLow: res.total * 0.95,
        totalHigh: res.total * 1.05,
        confidence: isEU ? 'Yüksek (Gümrük Birliği A.TR)' : 'Tahmini'
      };
    }

    const isEtgb = currentWeightNum > 0 && currentWeightNum <= 300 && currentGoodsValueNum > 0 && currentGoodsValueNum <= 15000;
    const isDualUse = ['ELECTRONICS', 'MACHINERY', 'CHEMICAL'].includes(selectedCategoryObj.code);
    const isProceedsExempt = checkProceedsExemption(currentGoodsValueNum);
    const ibkbRemainingDays = calculateIbkbRemainingDays(formDate);

    let ibkbDeadlineStr = '';
    if (formDate) {
      const d = new Date(formDate);
      if (!isNaN(d.getTime())) {
        d.setDate(d.getDate() + 180);
        ibkbDeadlineStr = d.toISOString().split('T')[0];
      }
    }

    return {
      acceptance,
      blockers,
      requirements,
      carrierApprovalLikely: selectedCategoryObj.carrierApproval,
      pallets: palletsEstimate,
      cost: costEstimate,
      isEtgb,
      isDualUse,
      isProceedsExempt,
      ibkbRemainingDays,
      ibkbDeadlineStr
    };
  }, [selectedCategoryObj, selectedCountryObj, currentWeightNum, currentGoodsValueNum, currentFreightNum, formDate]);

  // Beginner's Foreign Trade Guide States
  const [activeGuideStep, setActiveGuideStep] = useState<number | null>(1);
  const [completedGuideSteps, setCompletedGuideSteps] = useState<Record<number, boolean>>(() => {
    try {
      const saved = localStorage.getItem('completed_guide_steps');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem('completed_guide_steps', JSON.stringify(completedGuideSteps));
  }, [completedGuideSteps]);
  const [completedRoadmapSteps, setCompletedRoadmapSteps] = useState<Record<string, boolean>>({
    company: true,
    esign: true
  });
  const [showRoadmap, setShowRoadmap] = useState(true);

  // Google Drive & Team Cloud Sync State ($0 Cost)
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<string>(() => {
    return localStorage.getItem('last_team_sync_time') || '';
  });
  const [syncFeedback, setSyncFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleExportGoogleDriveJson = () => {
    try {
      const now = new Date();
      const exportData = {
        app: 'gumrukpilot',
        version: 1,
        exportedAt: now.toISOString(),
        shipments: shipmentsList,
        roadmap: completedRoadmapSteps,
        catalog: productCatalog,
        seller: {
          name: 'GümrükPilot İhracat Ekibi',
          taxId: '',
          updatedAt: now.toISOString()
        }
      };
      const jsonStr = JSON.stringify(exportData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = now.toISOString().split('T')[0].replace(/-/g, '');
      a.href = url;
      a.download = `gumrukpilot_ortak_ekip_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      const timeStr = now.toLocaleDateString('tr-TR') + ' ' + now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
      setLastSyncTimestamp(timeStr);
      localStorage.setItem('last_team_sync_time', timeStr);
      localStorage.setItem('lastBackupAt', String(Date.now()));
      setSyncFeedback({
        type: 'success',
        message: lang === 'tr'
          ? 'Ortak ekip dosyası başarıyla indirildi. Dışa Aktar ile inen dosyayı kendi Drive/OneDrive klasörünüze siz taşırsınız, otomatik bağlantı yoktur.'
          : 'Team data exported. Move the downloaded file into your shared Drive/OneDrive folder; there is no automatic connection.'
      });
    } catch (err: any) {
      setSyncFeedback({
        type: 'error',
        message: 'Dışa aktarma hatası: ' + (err?.message || err)
      });
    }
  };

  const handleImportGoogleDriveJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);

        if (!parsed || (parsed.app !== 'gumrukpilot' && parsed.app !== 'freightflow')) {
          throw new Error('Geçersiz dosya: Bu dosya GümrükPilot yedeği değil.');
        }

        let addedCount = 0;
        let updatedCount = 0;
        if (Array.isArray(parsed.shipments)) {
          const currentMap = new Map(shipmentsList.map(s => [s.id, s]));
          parsed.shipments.forEach((incoming: any) => {
            if (incoming && incoming.id) {
              const existing = currentMap.get(incoming.id);
              if (existing) {
                currentMap.set(incoming.id, Object.assign({}, existing, incoming));
                updatedCount++;
              } else {
                currentMap.set(incoming.id, incoming);
                addedCount++;
              }
            }
          });
          const mergedList = Array.from(currentMap.values());
          setShipmentsList(mergedList);
          localStorage.setItem('tracked_shipments_web', JSON.stringify(mergedList));
        }

        if (Array.isArray(parsed.catalog)) {
          const byId = new Map(productCatalog.map(p => [p.id, p]));
          parsed.catalog.forEach((p: any) => { if (p && p.id && p.name) byId.set(p.id, p); });
          const merged = Array.from(byId.values());
          setProductCatalog(merged);
          saveCatalogToStorage(merged);
        }

        if (parsed.roadmap && typeof parsed.roadmap === 'object') {
          setCompletedRoadmapSteps(prev => ({ ...prev, ...parsed.roadmap }));
        }

        const now = new Date();
        const timeStr = now.toLocaleDateString('tr-TR') + ' ' + now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
        setLastSyncTimestamp(timeStr);
        localStorage.setItem('last_team_sync_time', timeStr);

        setSyncFeedback({
          type: 'success',
          message: lang === 'tr'
            ? `Ortak klasörden başarıyla eşitlendi: ${addedCount} yeni sevkiyat eklendi, ${updatedCount} sevkiyat güncellendi.`
            : `Synced from team drive: ${addedCount} new shipments added, ${updatedCount} updated.`
        });
      } catch (err: any) {
        setSyncFeedback({
          type: 'error',
          message: 'Eşitleme hatası: ' + (err?.message || 'Geçersiz JSON dosyası')
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const filteredShipments = shipmentsList.filter(s => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = !q ||
      s.id.toLowerCase().includes(q) ||
      s.origin.toLowerCase().includes(q) ||
      s.destination.toLowerCase().includes(q) ||
      s.carrier.toLowerCase().includes(q) ||
      (s.note && s.note.toLowerCase().includes(q));
    const matchesFilter = filterStatus === 'ALL' || s.statusKey === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const eurRate = rates.find(r => r.code === 'EUR')?.rate ?? 55.76;
  const customsBaseTry = customsFreightEur * eurRate;
  const customsDutyTry = customsBaseTry * (customsDutyPct / 100);
  const vatTry = (customsBaseTry + customsDutyTry) * (vatPct / 100);
  const totalLandedTry = customsBaseTry + customsDutyTry + vatTry;

  const costRateToTry = rates.find(r => r.code === costCurrency)?.rate ?? (costCurrency === 'EUR' ? 55.76 : costCurrency === 'USD' ? 48.85 : 1);
  const costBafAmount = costBaseFreight * (costBafPct / 100);
  const costInsuranceAmount = costGoodsValue * (costInsurancePct / 100);
  const totalCostOriginal = costBaseFreight + costBafAmount + costThc + costDocFee + costCustomsFee + costInsuranceAmount;
  const totalCostTry = totalCostOriginal * (costCurrency === 'TRY' ? 1 : costRateToTry);
  const costPerTon = costCargoWeightKg > 0 ? (totalCostOriginal / (costCargoWeightKg / 1000)) : 0;
  const costPerPallet = costPalletCount > 0 ? (totalCostOriginal / costPalletCount) : 0;

  const transitEstimate = useMemo(() => {
    const country = COUNTRIES.find(c => c.code === customsCountryCode);
    const isEu = country?.tradeRegime === 'CUSTOMS_UNION';
    return estimateTransitTime(customsCountryCode, costMode, isEu);
  }, [customsCountryCode, costMode]);

  const selectedCountry = CUSTOMS_COUNTRIES.find(c => c.code === customsCountryCode) || CUSTOMS_COUNTRIES[0];
  const customsCurrencyRate = rates.find(r => r.code === customsCurrency)?.rate ?? (customsCurrency === 'EUR' ? 55.76 : 48.85);

  const customsCifOriginal = customsGoodsValue + customsFreightCost + customsInsuranceCost;
  const customsCifTry = customsCifOriginal * customsCurrencyRate;

  const applicableDutyPct = (customsHasPreferential && selectedCountry.isPreferential)
    ? 0
    : selectedCountry.defaultDutyPct;

  const dutyAmountTry = customsCifTry * (applicableDutyPct / 100);
  const customsVatBaseTry = customsCifTry + dutyAmountTry;
  const customsVatAmountTry = customsVatBaseTry * 0.20;
  const totalCustomsTaxTry = dutyAmountTry + customsVatAmountTry;
  const totalLandedCostTryCalculated = customsCifTry + totalCustomsTaxTry;
  const cleanHsDigits = customsHsCode.replace(/[^0-9]/g, '');
  const isHsCodeValid = [6, 8, 12].includes(cleanHsDigits.length);

  const customsChecklistPlan = useMemo(() => {
    return buildChecklist(customsCountryCode, customsCategory, {
      declaredValue: customsGoodsValue,
      incoterm: customsIncoterm,
      paymentMethodId: customsPaymentMethod
    });
  }, [customsCountryCode, customsCategory, customsGoodsValue, customsIncoterm, customsPaymentMethod]);

  const allCustomsChecklistItems = useMemo(() => {
    return customsChecklistPlan.sections.flatMap(s => s.items);
  }, [customsChecklistPlan]);

  const totalChecklistItems = allCustomsChecklistItems.length || 1;
  const checkedItemsCount = allCustomsChecklistItems.filter(i => customsCheckedDocs[i.id]).length;
  const readinessPercent = Math.round((checkedItemsCount / totalChecklistItems) * 100);

  const invoiceSubtotal = useMemo(() => {
    return invoiceItems.reduce((acc, it) => acc + (it.qty * it.unitPrice), 0);
  }, [invoiceItems]);

  const invoiceTotalVat = useMemo(() => {
    return invoiceItems.reduce((acc, it) => acc + (it.qty * it.unitPrice * (it.vatPct / 100)), 0);
  }, [invoiceItems]);

  const invoiceGrandTotal = invoiceSubtotal + invoiceTotalVat;

  const t = {
    appName: 'GümrükPilot',
    dashboardTitle: lang === 'tr' ? 'Ana Panel' : 'Dashboard',
    exchangeRate: lang === 'tr' ? 'Döviz Kuru' : 'Exchange Rate',
    palletAnalysis: lang === 'tr' ? 'Palet Analizi' : 'Pallet Analysis',
    costCalculator: lang === 'tr' ? 'Maliyet Hesaplayıcı' : 'Cost Calculator',
    customsPrep: lang === 'tr' ? 'Gümrük Hazırlık' : 'Customs Prep',
    docsTitle: lang === 'tr' ? 'Fatura & Evrak' : 'Invoice & Docs',
    invoiceHeader: lang === 'tr' ? 'Ticari Fatura & İhracat Belgesi' : 'Commercial Invoice & Export Document',
    costCalcTitle: lang === 'tr' ? 'Lojistik & Navlun Maliyet Hesaplayıcı' : 'Freight & Transport Cost Calculator',
    customsPrepTitle: lang === 'tr' ? 'Gümrük Ön Hazırlık & GTİP Denetimi' : 'Customs Prep & HS Code Engine',
    origin: lang === 'tr' ? 'Kalkış Noktası' : 'Origin',
    destination: lang === 'tr' ? 'Varış Noktası' : 'Destination',
    transportMode: lang === 'tr' ? 'Taşıma Türü' : 'Transport Mode',
    baseFreight: lang === 'tr' ? 'Temel Navlun' : 'Base Freight',
    fuelSurcharge: lang === 'tr' ? 'Yakıt Harcı (BAF)' : 'Fuel Surcharge (BAF)',
    thcFee: lang === 'tr' ? 'Liman / Terminal Elleçleme (THC)' : 'Terminal Handling (THC)',
    docFee: lang === 'tr' ? 'Taşıma Belgesi / Konşimento' : 'Documentation Fee (BL/CMR)',
    customsHandlingFee: lang === 'tr' ? 'Gümrükleme Hizmet Bedeli' : 'Customs Clearance Fee',
    insuranceFee: lang === 'tr' ? 'Emtia Nakliyat Sigortası' : 'Cargo Marine Insurance',
    goodsVal: lang === 'tr' ? 'Mal Bedeli' : 'Goods Value',
    totalTransportCost: lang === 'tr' ? 'Toplam Taşıma Maliyeti' : 'Total Transport Cost',
    hsCodeLabel: lang === 'tr' ? 'GTİP / HS Kodu (6, 8 veya 12 Hane)' : 'HS Code / GTIP (6, 8 or 12 Digits)',
    countryProfile: lang === 'tr' ? 'Menşe / Hedef Ülke Rejimi' : 'Country Trade Regime',
    preferentialCert: lang === 'tr' ? 'A.TR / EUR.1 Tercihli Dolaşım Belgesi' : 'Preferential Certificate (A.TR / EUR.1)',
    cifValue: lang === 'tr' ? 'CIF Değeri (Mal + Navlun + Sigorta)' : 'CIF Value (Goods + Freight + Ins.)',
    customsDutyLabel: lang === 'tr' ? 'Gümrük Vergisi' : 'Customs Duty',
    vatLabel: lang === 'tr' ? 'KDV Tutarı (%20)' : 'VAT Amount (20%)',
    requiredDocsList: lang === 'tr' ? 'Zorunlu Resmi Evrak Kontrol Listesi' : 'Required Customs Documents Checklist',
    readinessMeter: lang === 'tr' ? 'Gümrük Uygunluk Derecesi' : 'Customs Compliance Readiness',
    language: lang === 'tr' ? 'Dil' : 'Language',
    turkish: 'Türkçe',
    english: 'English',
    welcomeSubtitle: lang === 'tr' ? 'Lojistik Operasyonları & Palet Optimizasyon Portalı' : 'Logistics Operations & Pallet Optimization Portal',
    activeShipments: lang === 'tr' ? 'Aktif Sevkiyatlar' : 'Active Shipments',
    dispatchedPallets: lang === 'tr' ? 'Yüklenen Paletler' : 'Dispatched Pallets',
    freightVolume: lang === 'tr' ? 'Navlun Hacmi' : 'Freight Volume',
    fleetCapacity: lang === 'tr' ? 'Filo Doluluk' : 'Fleet Capacity',
    searchPlaceholder: lang === 'tr' ? 'Sevkiyat, güzergah veya taşıyıcı ara...' : 'Search shipment, route or carrier...',
    recentShipments: lang === 'tr' ? 'Güncel Sevkiyat Hareketleri' : 'Recent Freight Shipments',
    calculate: lang === 'tr' ? 'Paleti Hesapla' : 'Calculate Pallet',
    currencyConverter: lang === 'tr' ? 'Navlun & Döviz Çevirici' : 'Freight & FX Converter',
    boxesPerLayer: lang === 'tr' ? 'Katman Başı Koli' : 'Boxes / Layer',
    layersCount: lang === 'tr' ? 'Katman Sayısı' : 'Layer Count',
    boxesPerPallet: lang === 'tr' ? 'Palet Başı Koli' : 'Boxes / Pallet',
    totalPalletsReq: lang === 'tr' ? 'Gereken Palet' : 'Pallets Needed',
    palletGrossWeight: lang === 'tr' ? 'Palet Brüt Ağırlık' : 'Pallet Gross Weight',
    totalGrossWeight: lang === 'tr' ? 'Toplam Ağırlık' : 'Total Gross Weight',
    volumetricEfficiency: lang === 'tr' ? 'Hacimsel Doluluk' : 'Volume Efficiency',
    overhangStatus: lang === 'tr' ? 'Taşma Durumu' : 'Overhang Status',
    noOverhang: lang === 'tr' ? 'Taşma Yok (Uygun)' : 'No Overhang (OK)',
    hasOverhang: lang === 'tr' ? 'Taşma Var (Dikkat)' : 'Overhang Detected',
    vehicleCapacity: lang === 'tr' ? 'Araç Kapasitesi' : 'Vehicle Utilization',
    boxDimensions: lang === 'tr' ? 'Koli & Yük Parametreleri' : 'Box & Cargo Parameters',
    palletStandard: lang === 'tr' ? 'Palet Standardı' : 'Pallet Standard',
    targetVehicle: lang === 'tr' ? 'Hedef Taşıma Aracı' : 'Target Vehicle',
    customsTitle: lang === 'tr' ? 'Gümrük & İthalat Maliyet Simülasyonu' : 'Customs & Landed Cost Simulation',
    totalCost: lang === 'tr' ? 'Toplam Tahmini Maliyet' : 'Total Landed Cost',
    dutyAmount: lang === 'tr' ? 'Gümrük Vergisi Tutarı' : 'Duty Amount',
    vatAmount: lang === 'tr' ? 'Hesaplanan KDV' : 'Calculated VAT'
  };


  if (!hasSeenWelcome) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white transition-colors">
        {/* Header Bar */}
        <header className="border-b border-slate-800/80 bg-slate-900/80 backdrop-blur-md px-4 sm:px-8 py-3.5 sticky top-0 z-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-sky-500/20">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-extrabold text-base tracking-tight text-white flex items-center gap-2">
                <span>GümrükPilot</span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-600 dark:text-sky-400 border border-sky-500/30">
                  {lang === 'tr' ? 'Yeni Sürüm' : 'New Release'}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 font-medium">
                {lang === 'tr' ? 'Dış Ticaret & Lojistik Yönetim Platformu' : 'Foreign Trade & Logistics OS'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-200 dark:border-slate-700 cursor-pointer"
              title={theme === 'dark' ? 'Açık Mod' : 'Koyu Mod'}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-sky-600" />}
            </button>
            <div className="flex items-center gap-2 bg-slate-800/80 rounded-lg p-0.5 border border-slate-700">
              <button
                onClick={() => setLang('tr')}
                className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                  lang === 'tr' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                TR
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                  lang === 'en' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                EN
              </button>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <section className="relative overflow-hidden py-12 sm:py-16 px-4 sm:px-8 border-b border-slate-800 bg-gradient-to-b from-slate-900 via-slate-900/60 to-slate-950">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(14,165,233,0.18),rgba(255,255,255,0))] pointer-events-none" />
          <div className="max-w-4xl mx-auto text-center relative z-10 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold">
              <Compass className="w-3.5 h-3.5" />
              <span>{lang === 'tr' ? 'Karşılama & Oryantasyon Rehberi' : 'Welcome & Onboarding Guide'}</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
              {lang === 'tr' ? (
                <>Gümrükte <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300">Reddedilmeden Önce</span> Kontrol Et</>
              ) : (
                <>Check <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300">Before Rejection</span> at Customs</>
              )}
            </h1>

            <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
              {lang === 'tr'
                ? 'İhracata ilk adımı atan girişimcilerden aktif dış ticaret ekiplerine kadar; şirket kurulumu, gümrük müşaviri yetkilendirmesi, GTİP tespiti, 3D palet analizi ve 180 günlük İBKB kambiyo mevzuat takibini tek çatı altında sunan lojistik operasyon platformu.'
                : 'From first-time exporters to active foreign trade teams; manage company formation, broker authorization, HS Code classification, 3D pallet optimization, and 180-day foreign exchange proceeds tracking under one roof.'}
            </p>

            {/* Two Primary Action Buttons */}
            <div className="pt-3 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
              <button
                onClick={() => dismissWelcome('dashboard')}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-sky-500/25 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
              >
                <span>{lang === 'tr' ? 'Uygulamaya Gir' : 'Enter Application'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => dismissWelcome('roadmap')}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-sm sm:text-base border border-slate-700 flex items-center justify-center gap-2 shadow-sm transition-all hover:border-sky-500/50 cursor-pointer"
              >
                <Compass className="w-4 h-4 text-sky-400" />
                <span>{lang === 'tr' ? 'Yol Haritasını Gör' : 'View Roadmap'}</span>
              </button>
            </div>
          </div>
        </section>

        <SupportBanner lang={lang} />
        <ProofStrip lang={lang} />

        {/* 6-Step Roadmap Summary */}
        <section className="py-12 px-4 sm:px-8 max-w-6xl mx-auto w-full">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <div className="text-xs font-bold text-sky-400 uppercase tracking-wider mb-1">
                {lang === 'tr' ? 'Adım Adım Süreç Rehberi' : 'Step-by-Step Guide'}
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white">
                {lang === 'tr' ? 'Dış Ticarete İlk Kez Başlayanlar İçin 6 Temel Adım' : '6 Core Steps for First-Time Exporters'}
              </h2>
            </div>
            <p className="text-xs text-slate-400 max-w-md">
              {lang === 'tr'
                ? 'İhracat sürecinde sırasıyla tamamlanması gereken yasal ve operasyonel aşamaların özeti:'
                : 'Summary of legal and operational milestones required in sequence for official export shipments:'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {BEGINNER_GUIDE_STEPS.map((step) => (
              <div
                key={step.id}
                className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="w-7 h-7 rounded-lg bg-sky-500/20 text-sky-400 text-xs font-extrabold flex items-center justify-center border border-sky-500/30">
                      {step.id}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      {lang === 'tr' ? `Aşama 0${step.id}` : `Phase 0${step.id}`}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-100 text-sm mb-2">
                    {lang === 'tr' ? step.titleTr : step.titleEn}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed mb-4">
                    {lang === 'tr' ? step.descTr : step.descEn}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-800/80">
                  <div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                      {lang === 'tr' ? 'Gerekli Evraklar' : 'Required Docs'}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {(lang === 'tr' ? step.docsTr : step.docsEn).slice(0, 3).map((doc, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/60 font-medium">
                          {doc}
                        </span>
                      ))}
                      {(lang === 'tr' ? step.docsTr : step.docsEn).length > 3 && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-medium">
                          +{(lang === 'tr' ? step.docsTr : step.docsEn).length - 3}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-sky-950/40 border border-sky-800/30 text-[11px] text-sky-300 leading-snug">
                    <span className="font-bold text-sky-400">İpucu: </span>
                    {lang === 'tr' ? step.tipTr : step.tipEn}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Core Feature Cards */}
          <div className="mt-12 pt-8 border-t border-slate-800">
            <div className="text-center max-w-xl mx-auto mb-8">
              <h3 className="text-lg font-bold text-white mb-1">
                {lang === 'tr' ? 'GümrükPilot Operasyonel Özellikleri' : 'GümrükPilot Core Capabilities'}
              </h3>
              <p className="text-xs text-slate-400">
                {lang === 'tr' ? 'Operasyonel süreçleri kolaylaştıran 4 temel işlev' : '4 essential capabilities simplifying operational processes'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                <FileText className="w-5 h-5 text-sky-400 mb-2" />
                <div className="text-xs font-bold text-white mb-1">
                  {lang === 'tr' ? 'Fatura & Çeki Listesi' : 'Invoices & Packing Lists'}
                </div>
                <div className="text-[11px] text-slate-400 leading-relaxed">
                  {lang === 'tr' ? 'Tek tıkla resmi proforma & çeki listesi PDF ve baskı çıktısı.' : 'One-click official proforma and packing list generation.'}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                <BoxIcon className="w-5 h-5 text-amber-400 mb-2" />
                <div className="text-xs font-bold text-white mb-1">
                  {lang === 'tr' ? '3D Palet & Konteyner' : '3D Pallet & Container'}
                </div>
                <div className="text-[11px] text-slate-400 leading-relaxed">
                  {lang === 'tr' ? 'CBM, desi, araç doluluk oranı ve ağırlık simülasyonu.' : 'CBM, volumetric weight, vehicle utilization simulation.'}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                <ShieldCheck className="w-5 h-5 text-emerald-400 mb-2" />
                <div className="text-xs font-bold text-white mb-1">
                  {lang === 'tr' ? '180 Günlük İBKB Takibi' : '180-Day IBKB Tracker'}
                </div>
                <div className="text-[11px] text-slate-400 leading-relaxed">
                  {lang === 'tr' ? 'TCMB kambiyo mevzuatı 180 gün süresi ve vergi dairesi ihbar koruması.' : 'Central Bank 180-day proceeds deadline & penalty protection.'}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800">
                <FolderSync className="w-5 h-5 text-indigo-400 mb-2" />
                <div className="text-xs font-bold text-white mb-1">
                  {lang === 'tr' ? 'Dosya Tabanlı Paylaşım' : 'File-Based Sharing'}
                </div>
                <div className="text-[11px] text-slate-400 leading-relaxed">
                  {lang === 'tr' ? 'Google Drive & OneDrive uyumlu şifreli JSON yedekleme.' : 'Google Drive & OneDrive compatible team JSON sync.'}
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Call to Action */}
          <div className="mt-10 p-6 rounded-2xl bg-gradient-to-r from-sky-950/60 via-slate-900 to-slate-900 border border-sky-800/40 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="font-bold text-white text-sm sm:text-base">
                {lang === 'tr' ? 'Operasyonlarınıza başlamaya hazır mısınız?' : 'Ready to start your operations?'}
              </div>
              <div className="text-xs text-slate-400">
                {lang === 'tr'
                  ? 'Giriş yaptıktan sonra dilediğiniz zaman Ayarlar menüsünden bu karşılama ekranını yeniden açabilirsiniz.'
                  : 'You can reopen this onboarding guide anytime from the Settings menu.'}
              </div>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={() => dismissWelcome('dashboard')}
                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <span>{lang === 'tr' ? 'Uygulamaya Gir' : 'Enter Application'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => dismissWelcome('roadmap')}
                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm border border-slate-700 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Compass className="w-3.5 h-3.5 text-sky-400" />
                <span>{lang === 'tr' ? 'Yol Haritasını Gör' : 'View Roadmap'}</span>
              </button>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-auto border-t border-slate-800/80 py-4 px-4 sm:px-8 text-center text-xs text-slate-500">
          <div>{lang === 'tr' ? 'GümrükPilot — Dış Ticaret & Lojistik Yönetim Platformu' : 'GümrükPilot — Foreign Trade & Logistics OS'}</div>
          <div className="mt-1.5"><LegalLinks lang={lang} dark /></div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col text-slate-900 dark:text-slate-100 transition-colors">
      <header className="bg-slate-900 text-white px-3 md:px-8 py-2.5 md:py-3.5 border-b border-slate-800 flex flex-wrap lg:flex-nowrap items-center justify-between gap-2.5 md:gap-4 sticky top-0 z-50 shadow-md">
        <div className="flex items-center gap-2.5 flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-sky-600 flex items-center justify-center text-white shadow-sm flex-shrink-0">
            <Truck className="w-4 h-4 md:w-5 md:h-5" />
          </div>
          <div>
            <div className="text-sm md:text-base font-bold tracking-tight whitespace-nowrap">{t.appName}</div>
            <div className="text-[10px] text-slate-400 font-medium whitespace-nowrap hidden sm:block">Logistics Operating System</div>
          </div>
        </div>

        <nav className="flex items-center gap-1 md:gap-1.5 overflow-x-auto max-w-full py-1 lg:py-0 order-3 lg:order-2 w-full lg:w-auto scrollbar-none flex-nowrap">
          <button
            onClick={() => setActiveScreen('dashboard')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'dashboard' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Warehouse className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{t.dashboardTitle}</span>
          </button>

          <button
            onClick={() => setActiveScreen('shipments')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'shipments' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Truck className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{lang === 'tr' ? 'Sevkiyat Takibi' : 'Shipment Tracking'}</span>
          </button>

          <button
            onClick={() => setActiveScreen('pallet')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'pallet' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{t.palletAnalysis}</span>
          </button>

          <button
            onClick={() => setActiveScreen('cost')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'cost' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calculator className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{t.costCalculator}</span>
          </button>

          <button
            onClick={() => setActiveScreen('customs')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'customs' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{t.customsPrep}</span>
          </button>

          <button
            onClick={() => setActiveScreen('roadmap')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'roadmap' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Compass className="w-3.5 h-3.5 md:w-4 md:h-4 text-emerald-400" />
            <span>{lang === 'tr' ? 'Yol Haritası' : 'Roadmap'}</span>
          </button>

          <button
            onClick={() => setActiveScreen('mistakes')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'mistakes' ? 'bg-rose-500 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{lang === 'tr' ? 'En Sık Hatalar' : 'Top Mistakes'}</span>
          </button>

          <button
            onClick={() => setActiveScreen('settings')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'settings' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Edit2 className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{lang === 'tr' ? 'Ayarlar' : 'Settings'}</span>
          </button>

          <button
            onClick={() => setActiveScreen('docs')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'docs' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{t.docsTitle}</span>
          </button>

          <button
            onClick={() => setActiveScreen('catalog')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'catalog' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tag className="w-3.5 h-3.5 md:w-4 md:h-4 text-emerald-400" />
            <span>{lang === 'tr' ? 'Ürün Kataloğu' : 'Product Catalog'}</span>
          </button>

          <button
            onClick={() => setActiveScreen('exchange')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'exchange' ? 'bg-white/10 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span>{t.exchangeRate}</span>
          </button>

          <button
            onClick={() => setActiveScreen('sync')}
            className={`px-2.5 md:px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 ${
              activeScreen === 'sync' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <FolderSync className="w-3.5 h-3.5 md:w-4 md:h-4 text-emerald-400" />
            <span>{lang === 'tr' ? 'Ekip Paylaşımı (Drive/OneDrive)' : 'Team Sharing (Drive/OneDrive)'}</span>
          </button>
        </nav>

        <div className="flex items-center gap-2 md:gap-3 flex-shrink-0 order-2 lg:order-3">
          <button
            onClick={() => setIsCopilotOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-sky-500/20 to-indigo-500/20 hover:from-sky-500/30 hover:to-indigo-500/30 text-sky-200 border border-sky-400/40 rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs group"
            title={lang === 'tr' ? 'AI Gümrük Rehberi (Mevzuat & Sistem Yönlendirici)' : 'AI Customs Copilot (Regulatory & Navigator)'}
          >
            <Bot className="w-3.5 h-3.5 text-sky-400 group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline">{lang === 'tr' ? 'AI Gümrük Rehberi' : 'AI Copilot'}</span>
          </button>

          <button
            onClick={() => setIsQuickDrawerOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-bold transition-all cursor-pointer"
            title={lang === 'tr' ? 'Hızlı Gösterge Kurları & Çevirici' : 'Quick FX & Converter'}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="hidden sm:inline">{lang === 'tr' ? 'Hızlı Kur' : 'Quick FX'}</span>
          </button>

          <button
            onClick={toggleTheme}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700 cursor-pointer flex items-center justify-center"
            title={theme === 'dark' ? (lang === 'tr' ? 'Açık Mod' : 'Light Mode') : (lang === 'tr' ? 'Koyu Mod' : 'Dark Mode')}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-sky-400" />}
          </button>

          <div className="bg-slate-800 border border-slate-700 rounded-lg p-0.5 flex">
            <button
              onClick={() => setLang('tr')}
              className={`px-2 py-0.5 text-[11px] rounded font-semibold transition-colors ${
                lang === 'tr' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              TR
            </button>
            <button
              onClick={() => setLang('en')}
              className={`px-2 py-0.5 text-[11px] rounded font-semibold transition-colors ${
                lang === 'en' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              EN
            </button>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-slate-800 text-slate-300 rounded-lg text-[11px] font-medium border border-slate-700">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="hidden sm:inline">{lang === 'tr' ? 'Operasyon' : 'Operations'}</span>
          </div>
        </div>
      </header>

      <main
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6 select-text"
      >
        <BackupReminder lang={lang} hasData={shipmentsList.length > 0 || productCatalog.some(p => !p.id.startsWith('prod-'))} onGo={() => setActiveScreen('sync')} />
        {previousScreen && (
          <div className="flex items-center justify-between gap-2 w-full bg-slate-900 text-white px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl border border-slate-800 shadow-sm text-xs transition-all">
            <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
              <span className="text-slate-400 hidden sm:inline whitespace-nowrap text-[11px] sm:text-xs">
                {lang === 'tr' ? 'Şu anki ekran:' : 'Current screen:'}
              </span>
              <span className="font-bold text-sky-400 bg-slate-800 px-2 sm:px-2.5 py-0.5 rounded border border-slate-700 truncate max-w-[160px] sm:max-w-none text-[11px] sm:text-xs">
                {SCREEN_TITLES[activeScreen]?.[lang] || activeScreen}
              </span>
            </div>

            <button
              onClick={goBack}
              className="flex items-center gap-1.5 px-2.5 sm:px-3.5 py-1 sm:py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg transition-all shadow-sm active:scale-95 cursor-pointer whitespace-nowrap flex-shrink-0 text-[11px] sm:text-xs"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>
                {lang === 'tr'
                  ? `« ${SCREEN_TITLES[previousScreen]?.[lang] || previousScreen}'na Dön`
                  : `« Back to ${SCREEN_TITLES[previousScreen]?.[lang] || previousScreen}`}
              </span>
            </button>
          </div>
        )}

        {activeScreen === 'dashboard' && (
          <>
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3.5 flex items-start gap-3 text-slate-700 dark:text-slate-300">
              <ShieldCheck className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed">
                <span className="font-bold text-amber-900 dark:text-amber-300">{lang === 'tr' ? 'Yasal Güvence & Sorumluluk Reddi (Safe Harbor): ' : 'Legal Safe Harbor & Disclaimer: '}</span>
                {lang === 'tr'
                  ? 'GümrükPilot bir dış ticaret ve operasyonel karar destek kokpitidir. 4458 sayılı Gümrük Kanunu, 32 sayılı Kambiyo Kararı ve 213 sayılı VUK uyarınca resmi gümrük beyannamesi tescili, bağlayıcı tarife tespiti ve vergi mükellefiyeti yetkili gümrük müşaviri ve mali müşavir sorumluluğundadır. Sunulan hesaplamalar ve veriler bağlayıcı resmi danışmanlık hükmünde değildir.'
                  : 'GümrükPilot is an operational decision-support simulation. Official customs declarations, binding tariff determinations (BTI), and tax liabilities remain the legal responsibility of your licensed customs broker and CPA pursuant to applicable customs and tax laws.'}
              </div>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div
                onClick={() => setActiveScreen('shipments')}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-sky-300 transition-colors"
              >
                <div className="text-xs text-slate-500 font-medium">{t.activeShipments}</div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-bold font-mono text-slate-900">
                    {shipmentsList.filter(s => s.statusKey !== 'DELIVERED').length}
                  </span>
                  <span className="text-xs font-semibold text-sky-600">{lang === 'tr' ? 'Sevkiyat' : 'Active'}</span>
                </div>
              </div>

              <div
                onClick={() => setActiveScreen('shipments')}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-amber-300 transition-colors"
              >
                <div className="text-xs text-slate-500 font-medium">{t.dispatchedPallets}</div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-bold font-mono text-slate-900">
                    {shipmentsList.filter(s => s.statusKey !== 'DELIVERED').reduce((acc, s) => acc + Number(s.pallets || 0), 0)}
                  </span>
                  <span className="text-xs font-semibold text-amber-600">{lang === 'tr' ? 'Palet' : 'Pallets'}</span>
                </div>
              </div>

              <div
                onClick={() => setActiveScreen('shipments')}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-emerald-300 transition-colors"
              >
                <div className="text-xs text-slate-500 font-medium">{lang === 'tr' ? 'Aktif Brüt Ağırlık' : 'Active Gross Weight'}</div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-bold font-mono text-slate-900">
                    {shipmentsList.filter(s => s.statusKey !== 'DELIVERED').reduce((acc, s) => acc + Number(s.weight || 0), 0).toLocaleString()}
                  </span>
                  <span className="text-xs font-semibold text-emerald-600">kg</span>
                </div>
              </div>

              <div
                onClick={() => setActiveScreen('shipments')}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-indigo-300 transition-colors"
              >
                <div className="text-xs text-slate-500 font-medium">{lang === 'tr' ? 'Gümrükteki Yükler' : 'In Customs'}</div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-bold font-mono text-slate-900">
                    {shipmentsList.filter(s => s.statusKey === 'CUSTOMS').length}
                  </span>
                  <span className="text-xs font-semibold text-indigo-600">{lang === 'tr' ? 'Sevkiyat' : 'Active'}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div
                onClick={() => setActiveScreen('pallet')}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-amber-300 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700">
                    <BoxIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{t.palletAnalysis}</div>
                    <div className="text-xs text-slate-500">
                      {lang === 'tr' ? 'Palet dizilim & istifleme' : 'Pallet layout & stacking'}
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>

              <div
                onClick={() => setActiveScreen('cost')}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-sky-300 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700">
                    <Calculator className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{t.costCalculator}</div>
                    <div className="text-xs text-slate-500">
                      {lang === 'tr' ? 'Navlun, BAF, THC & sigorta' : 'Freight, BAF & insurance'}
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>

              <div
                onClick={() => setActiveScreen('customs')}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-300 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{t.customsPrep}</div>
                    <div className="text-xs text-slate-500">
                      {lang === 'tr' ? 'GTİP & A.TR/EUR.1 evrakları' : 'HS Code & trade regime'}
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>

              <div
                onClick={() => setActiveScreen('exchange')}
                className="bg-slate-900 text-white p-4 rounded-xl shadow-sm hover:bg-slate-800 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-sky-900/50 border border-sky-700 flex items-center justify-center text-sky-400">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">{t.exchangeRate}</div>
                    <div className="text-xs text-slate-400 font-mono">
                      EUR: {rates.find(r => r.code === 'EUR')?.rate.toFixed(2)} ₺ · USD: {rates.find(r => r.code === 'USD')?.rate.toFixed(2)} ₺
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
            </div>

            <div
              onClick={() => setActiveScreen('sync')}
              className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 text-white p-4 rounded-xl border border-emerald-800/40 shadow-sm flex items-center justify-between cursor-pointer hover:border-emerald-500/50 transition-all"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
                  <FolderSync className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">
                      {lang === 'tr' ? 'Dosya Tabanlı Ekip Paylaşımı (Google Drive / OneDrive Uyumlu)' : 'File-Based Team Sharing (Drive / OneDrive Compatible)'}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {lang === 'tr' ? 'Sunucusuz / 0 TL' : 'Serverless / $0'}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 mt-0.5">
                    {lang === 'tr'
                      ? 'Dışa Aktar ile inen dosyayı kendi Drive/OneDrive klasörünüze siz taşırsınız, otomatik bağlantı yoktur.'
                      : 'You manually move exported files to your Drive/OneDrive folder; there is no automatic connection.'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 shrink-0">
                <span>{lang === 'tr' ? 'Paylaşım Merkezini Aç' : 'Open Sharing Hub'}</span>
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">{lang === 'tr' ? 'Güncel Sevkiyat Hareketleri' : 'Recent Freight Shipments'}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {lang === 'tr' ? 'Aktif taşıma ve transit süreçleri' : 'Active road & maritime shipments in transit'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                  <div className="relative flex-1 md:w-64">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      placeholder={t.searchPlaceholder}
                      className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-sky-600"
                    />
                  </div>

                  <div className="flex bg-slate-100 p-1 rounded-lg gap-1">
                    {[
                      { key: 'ALL', tr: 'Tümü', en: 'All' },
                      { key: 'TRANSIT', tr: 'Yolda', en: 'Transit' },
                      { key: 'CUSTOMS', tr: 'Gümrük', en: 'Customs' }
                    ].map(f => (
                      <button
                        key={f.key}
                        onClick={() => setFilterStatus(f.key)}
                        className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                          filterStatus === f.key ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {lang === 'tr' ? f.tr : f.en}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => setActiveScreen('shipments')}
                    className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{lang === 'tr' ? 'Ekle & Yönet' : 'Add & Manage'}</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/75 border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-2.5 px-4">ID</th>
                      <th className="py-2.5 px-4">{lang === 'tr' ? 'Güzergah' : 'Route'}</th>
                      <th className="py-2.5 px-4">{lang === 'tr' ? 'Durum' : 'Status'}</th>
                      <th className="py-2.5 px-4 text-right">{lang === 'tr' ? 'Palet / Ağırlık' : 'Pallets / Wt'}</th>
                      <th className="py-2.5 px-4">{lang === 'tr' ? 'Taşıyıcı & Mod' : 'Carrier & Mode'}</th>
                      <th className="py-2.5 px-4 text-right">{lang === 'tr' ? 'Tarih' : 'Date'}</th>
                      <th className="py-2.5 px-4 text-center">{lang === 'tr' ? 'İşlem' : 'Action'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredShipments.map(s => {
                      const badge = (() => {
                        switch (s.statusKey) {
                          case 'PREPARING':
                            return { text: lang === 'tr' ? 'Hazırlanıyor' : 'Preparing', color: 'text-amber-700 bg-amber-50 border-amber-100', dot: 'bg-amber-500' };
                          case 'TRANSIT':
                            return { text: lang === 'tr' ? 'Yolda' : 'In Transit', color: 'text-sky-700 bg-sky-50 border-sky-100', dot: 'bg-sky-500' };
                          case 'CUSTOMS':
                            return { text: lang === 'tr' ? 'Gümrükte' : 'In Customs', color: 'text-rose-700 bg-rose-50 border-rose-100', dot: 'bg-rose-500' };
                          case 'DELIVERED':
                            return { text: lang === 'tr' ? 'Teslim Edildi' : 'Delivered', color: 'text-emerald-700 bg-emerald-50 border-emerald-100', dot: 'bg-emerald-500' };
                          default:
                            return { text: s.statusKey, color: 'text-slate-700 bg-slate-50 border-slate-100', dot: 'bg-slate-500' };
                        }
                      })();

                      return (
                        <tr key={s.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-3 px-4 font-mono font-semibold text-slate-900">{s.id}</td>
                          <td className="py-3 px-4 font-medium text-slate-800">
                            {s.origin} → {s.destination}
                          </td>
                          <td className="py-3 px-4">
                            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[11px] font-semibold ${badge.color}`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                              {badge.text}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-medium text-slate-700">
                            {s.pallets} {lang === 'tr' ? 'Palet' : 'Pallets'} · {Number(s.weight).toLocaleString()} kg
                          </td>
                          <td className="py-3 px-4 text-slate-600">
                            {s.carrier} <span className="text-slate-400">({s.mode})</span>
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-slate-500">{s.date}</td>
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => {
                                setEditingShipmentId(s.id);
                                setFormCode(s.id);
                                setFormOrigin(s.origin);
                                setFormDestination(s.destination);
                                setFormStatusKey(s.statusKey);
                                setFormMode(s.mode);
                                setFormCarrier(s.carrier);
                                setFormPallets(String(s.pallets));
                                setFormWeight(String(s.weight));
                                setFormDate(s.date);
                                setFormNote(s.note || '');
                                setActiveScreen('shipments');
                              }}
                              className="text-sky-600 hover:text-sky-800 font-semibold"
                            >
                              {lang === 'tr' ? 'Düzenle' : 'Edit'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                    {filteredShipments.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-400 italic">
                          {lang === 'tr' ? 'Sevkiyat bulunamadı.' : 'No shipments found.'}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {activeScreen === 'shipments' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
              <div>
                <h2 className="text-xl font-bold text-slate-900">{lang === 'tr' ? 'Sevkiyat Takip Portalı' : 'Shipment Tracking Portal'}</h2>
                <p className="text-sm text-slate-500 mt-1">
                  {lang === 'tr' 
                    ? 'Kendi sevkiyatlarınızı ekleyin, düzenleyin, silin ve gümrük durumlarını anlık güncelleyin.' 
                    : 'Add, edit, delete and update customs status of your own freight shipments in real-time.'}
                </p>
              </div>
              {editingShipmentId === null && (
                <button
                  onClick={() => {
                    const today = new Date().toISOString().split('T')[0];
                    const count = shipmentsList.length + 1;
                    const defaultId = `SV-${today.replace(/-/g, '')}-${String(count).padStart(3, '0')}`;
                    setEditingShipmentId('new');
                    setFormCode(defaultId);
                    setFormOrigin('Bursa OSB');
                    setFormDestination('Rotterdam Limanı');
                    setFormCategory('ELECTRONICS');
                    setFormCountryCode('DE');
                    setFormGoodsValue('5000');
                    setFormFreight('400');
                    setFormStatusKey('PREPARING');
                    setFormMode('Karayolu TIR');
                    setFormCarrier('Anadolu Lojistik');
                    setFormPallets('');
                    setFormWeight('1000');
                    setFormDate(today);
                    setFormNote('');
                    setFormErrors([]);
                  }}
                  className="px-4 py-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-sm font-semibold transition-all flex items-center gap-2 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>{lang === 'tr' ? 'Yeni Sevkiyat Ekle' : 'Add New Shipment'}</span>
                </button>
              )}
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
                    <Compass className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {lang === 'tr' ? 'İhracata Başlangıç Yol Haritası (9 Adım)' : 'Beginner Export Roadmap (9 Steps)'}
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      {lang === 'tr' 
                        ? 'Şirket kuruluşundan 180 günlük İBKB bedel kapanışına kadar adım adım resmi süreç.' 
                        : 'Official step-by-step export workflow from company setup to 180-day proceeds closing.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-xs font-bold text-sky-700">
                      {Object.values(completedRoadmapSteps).filter(Boolean).length} / {ROADMAP_STEPS.length}
                    </span>
                    <span className="text-[11px] text-slate-400 ml-1">
                      {lang === 'tr' ? 'Tamamlandı' : 'Completed'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowRoadmap(!showRoadmap)}
                    className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 transition-colors"
                  >
                    <ChevronDown className={`w-4 h-4 transition-transform ${showRoadmap ? 'rotate-180' : ''}`} />
                  </button>
                </div>
              </div>

              {showRoadmap && (
                <div className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {ROADMAP_STEPS.map((step, idx) => {
                      const isDone = !!completedRoadmapSteps[step.id];
                      return (
                        <div
                          key={step.id}
                          className={`p-3.5 rounded-xl border text-xs transition-all flex flex-col justify-between ${
                            isDone 
                              ? 'bg-emerald-50/40 border-emerald-200' 
                              : 'bg-white border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2 mb-1.5">
                              <span className="font-bold text-slate-900 flex items-center gap-1.5">
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                  isDone ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                                }`}>
                                  {idx + 1}
                                </span>
                                <span>{lang === 'tr' ? step.titleTr : step.titleEn}</span>
                              </span>
                              <input
                                type="checkbox"
                                checked={isDone}
                                onChange={e => {
                                  setCompletedRoadmapSteps({
                                    ...completedRoadmapSteps,
                                    [step.id]: e.target.checked
                                  });
                                }}
                                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                              />
                            </div>
                            <p className="text-[11px] text-slate-600 leading-relaxed">
                              {lang === 'tr' ? step.detailTr : step.detailEn}
                            </p>
                          </div>

                          {step.route && (
                            <div className="pt-2 mt-2 border-t border-slate-100/80">
                              <button
                                type="button"
                                onClick={() => setActiveScreen(step.route!)}
                                className="text-[11px] font-semibold text-sky-600 hover:text-sky-700 flex items-center gap-1"
                              >
                                <span>{lang === 'tr' ? step.routeLabelTr : step.routeLabelEn}</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {editingShipmentId !== null && (
              <div className="bg-white p-6 rounded-xl border-2 border-sky-500 shadow-sm space-y-5">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="text-base font-bold text-slate-900">
                    {editingShipmentId === 'new' 
                      ? (lang === 'tr' ? 'Yeni Sevkiyat Ekle' : 'Add New Shipment') 
                      : (lang === 'tr' ? `Sevkiyat Düzenle: ${editingShipmentId}` : `Edit Shipment: ${editingShipmentId}`)}
                  </h3>
                  <span className="text-xs text-slate-400">{lang === 'tr' ? 'Veriler tarayıcıda saklanır' : 'Data is stored in browser'}</span>
                </div>

                {formErrors.length > 0 && (
                  <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-lg space-y-1">
                    {formErrors.map((err, idx) => (
                      <div key={idx} className="text-xs text-rose-700 font-semibold flex items-center gap-1.5">
                        <span className="w-1 h-1 rounded-full bg-rose-600" />
                        {err}
                      </div>
                    ))}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Sevkiyat No / Kod' : 'Shipment Code / ID'}</label>
                    <input
                      type="text"
                      value={formCode}
                      onChange={e => setFormCode(e.target.value)}
                      disabled={editingShipmentId !== 'new'}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500 disabled:bg-slate-50 disabled:text-slate-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Çıkış Yeri' : 'Origin'}</label>
                    <input
                      type="text"
                      value={formOrigin}
                      onChange={e => setFormOrigin(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Varış Yeri' : 'Destination'}</label>
                    <input
                      type="text"
                      value={formDestination}
                      onChange={e => setFormDestination(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Sektör / Ürün Cinsi' : 'Product Category'}</label>
                    <select
                      value={formCategory}
                      onChange={e => setFormCategory(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500 bg-white"
                    >
                      {PRODUCT_CATEGORIES.map(c => (
                        <option key={c.code} value={c.code}>{lang === 'tr' ? c.labelTr : c.labelEn}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Varış Ülkesi' : 'Destination Country'}</label>
                    <select
                      value={formCountryCode}
                      onChange={e => setFormCountryCode(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500 bg-white"
                    >
                      {CUSTOMS_COUNTRIES.map(ct => (
                        <option key={ct.code} value={ct.code}>{lang === 'tr' ? ct.nameTr : ct.nameEn} ({ct.code})</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Durum' : 'Status'}</label>
                    <select
                      value={formStatusKey}
                      onChange={e => setFormStatusKey(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500 bg-white"
                    >
                      <option value="PREPARING">{lang === 'tr' ? 'Hazırlanıyor' : 'Preparing'}</option>
                      <option value="TRANSIT">{lang === 'tr' ? 'Yolda (Transit)' : 'In Transit'}</option>
                      <option value="CUSTOMS">{lang === 'tr' ? 'Gümrükte' : 'In Customs'}</option>
                      <option value="DELIVERED">{lang === 'tr' ? 'Teslim Edildi' : 'Delivered'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Taşıma Modu' : 'Transport Mode'}</label>
                    <select
                      value={formMode}
                      onChange={e => setFormMode(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500 bg-white"
                    >
                      <option value="Karayolu TIR">{lang === 'tr' ? 'Karayolu TIR' : 'Road Freight'}</option>
                      <option value="Denizyolu Konteyner">{lang === 'tr' ? 'Denizyolu' : 'Sea Freight'}</option>
                      <option value="Havayolu Kargo">{lang === 'tr' ? 'Havayolu' : 'Air Freight'}</option>
                      <option value="İntermodal">{lang === 'tr' ? 'İntermodal' : 'Intermodal'}</option>
                      <option value="Kurye / Ekspres">{lang === 'tr' ? 'Kurye / Ekspres' : 'Courier / Express'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Taşıyıcı / Firma' : 'Carrier'}</label>
                    <input
                      type="text"
                      value={formCarrier}
                      onChange={e => setFormCarrier(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Palet Sayısı' : 'Pallets'}</label>
                    <input
                      type="number"
                      value={formPallets}
                      onChange={e => setFormPallets(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Ağırlık (kg)' : 'Total Weight (kg)'}</label>
                    <input
                      type="number"
                      value={formWeight}
                      onChange={e => setFormWeight(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Mal Bedeli (€/$)' : 'Goods Value'}</label>
                    <input
                      type="number"
                      value={formGoodsValue}
                      onChange={e => setFormGoodsValue(e.target.value.replace(/[^\d.]/g, ''))}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Nakliye Bedeli (€/$, opsiyonel)' : 'Freight'}</label>
                    <input
                      type="number"
                      value={formFreight}
                      onChange={e => setFormFreight(e.target.value.replace(/[^\d.]/g, ''))}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Tarih' : 'Date'}</label>
                    <input
                      type="date"
                      value={formDate}
                      onChange={e => setFormDate(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">{lang === 'tr' ? 'Not (opsiyonel)' : 'Note'}</label>
                  <textarea
                    value={formNote}
                    onChange={e => setFormNote(e.target.value)}
                    rows={2}
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-sky-600" />
                      <h4 className="text-sm font-bold text-slate-900">{lang === 'tr' ? 'Otomatik Ön Değerlendirme (Shipment Advisor)' : 'Automatic Pre-Assessment'}</h4>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${
                      shipmentAdvice.acceptance === 'RESTRICTED'
                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                        : shipmentAdvice.acceptance === 'CONDITIONAL'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    }`}>
                      {shipmentAdvice.acceptance === 'RESTRICTED'
                        ? (lang === 'tr' ? 'Kısıtlı / Taşıyıcı Onayı Şart' : 'Restricted')
                        : shipmentAdvice.acceptance === 'CONDITIONAL'
                        ? (lang === 'tr' ? 'Koşullu Kabul' : 'Conditional')
                        : (lang === 'tr' ? 'Kabul Edilebilir (OK)' : 'OK')}
                    </span>
                  </div>

                  {shipmentAdvice.blockers.map((b, idx) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-rose-100/70 border border-rose-200 text-xs text-rose-800 font-semibold flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>⛔ {b}</span>
                    </div>
                  ))}

                  <div className="space-y-1">
                    <div className="text-xs font-semibold text-slate-700">{lang === 'tr' ? 'Gereksinimler & İhracat Belgeleri:' : 'Requirements:'}</div>
                    <ul className="text-xs text-slate-600 space-y-1 pl-1">
                      {shipmentAdvice.requirements.slice(0, 5).map((req, idx) => (
                        <li key={idx} className="flex items-center gap-1.5">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {shipmentAdvice.pallets && (
                    <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                      <div className="text-xs text-slate-700">
                        <strong className="text-slate-900">{lang === 'tr' ? 'Tahmini Palet:' : 'Pallet Estimate:'}</strong> {shipmentAdvice.pallets.min}–{shipmentAdvice.pallets.max} ({lang === 'tr' ? 'Öneri:' : 'Suggested:'} {shipmentAdvice.pallets.suggested})
                      </div>
                      <button
                        type="button"
                        onClick={() => setFormPallets(String(shipmentAdvice.pallets.suggested))}
                        className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{lang === 'tr' ? `Önerileni uygula (${shipmentAdvice.pallets.suggested})` : `Apply (${shipmentAdvice.pallets.suggested})`}</span>
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <button
                    onClick={() => {
                      setEditingShipmentId(null);
                      setFormErrors([]);
                    }}
                    className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold text-sm rounded-lg transition-colors"
                  >
                    {lang === 'tr' ? 'Vazgeç' : 'Cancel'}
                  </button>
                  <button
                    onClick={() => {
                      const errors: string[] = [];
                      const cleanCode = formCode.trim().toUpperCase();
                      if (!cleanCode) errors.push(lang === 'tr' ? 'Sevkiyat numarası boş bırakılamaz.' : 'Shipment number cannot be empty.');
                      if (editingShipmentId === 'new') {
                        const exists = shipmentsList.some(s => s.id.toUpperCase() === cleanCode);
                        if (exists) errors.push(lang === 'tr' ? 'Bu sevkiyat numarası zaten kullanımda.' : 'Already in use.');
                      }

                      if (errors.length > 0) {
                        setFormErrors(errors);
                        return;
                      }

                      const newShipment = {
                        id: cleanCode,
                        origin: formOrigin.trim(),
                        destination: formDestination.trim(),
                        category: formCategory,
                        countryCode: formCountryCode,
                        goodsValue: Number(formGoodsValue) || 0,
                        freight: Number(formFreight) || 0,
                        statusKey: formStatusKey,
                        mode: formMode,
                        carrier: formCarrier.trim(),
                        pallets: Number(formPallets) || 0,
                        weight: Number(formWeight) || 0,
                        date: formDate || new Date().toISOString().split('T')[0],
                        note: formNote.trim()
                      };

                      if (editingShipmentId === 'new') {
                        setShipmentsList([newShipment, ...shipmentsList]);
                      } else {
                        setShipmentsList(shipmentsList.map(s => s.id === editingShipmentId ? newShipment : s));
                      }

                      setEditingShipmentId(null);
                      setFormErrors([]);
                    }}
                    className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm rounded-lg transition-colors shadow-sm"
                  >
                    {lang === 'tr' ? 'Kaydet' : 'Save'}
                  </button>
                </div>
              </div>
            )}

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">{lang === 'tr' ? 'Sevkiyat Listesi' : 'Shipment Register'}</h3>
                </div>

                <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                  <div className="relative flex-1 md:w-64">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      placeholder={t.searchPlaceholder}
                      className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-sky-600"
                    />
                  </div>

                  <div className="flex bg-slate-100 p-1 rounded-lg gap-1">
                    {[
                      { key: 'ALL', tr: 'Tümü', en: 'All' },
                      { key: 'PREPARING', tr: 'Hazırlık', en: 'Prep' },
                      { key: 'TRANSIT', tr: 'Yolda', en: 'Transit' },
                      { key: 'CUSTOMS', tr: 'Gümrük', en: 'Customs' },
                      { key: 'DELIVERED', tr: 'Teslim', en: 'Delivered' }
                    ].map(f => (
                      <button
                        key={f.key}
                        onClick={() => setFilterStatus(f.key)}
                        className={`px-2.5 py-1 text-xs rounded font-medium transition-colors ${
                          filterStatus === f.key ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {lang === 'tr' ? f.tr : f.en}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/75 border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-2.5 px-4">ID / NO</th>
                      <th className="py-2.5 px-4">{lang === 'tr' ? 'Güzergah' : 'Route'}</th>
                      <th className="py-2.5 px-4">{lang === 'tr' ? 'Hızlı Durum Güncelle' : 'Status'}</th>
                      <th className="py-2.5 px-4 text-right">{lang === 'tr' ? 'Palet / Ağırlık' : 'Pallets / Wt'}</th>
                      <th className="py-2.5 px-4">{lang === 'tr' ? 'Taşıyıcı & Mod' : 'Carrier & Mode'}</th>
                      <th className="py-2.5 px-4 text-right">{lang === 'tr' ? 'Tarih' : 'Date'}</th>
                      <th className="py-2.5 px-4 text-center">{lang === 'tr' ? 'İşlemler' : 'Actions'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredShipments.map(s => (
                      <tr key={s.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                          <div>{s.id}</div>
                          {s.note && <div className="text-[10px] text-slate-400 mt-0.5 font-sans italic">{s.note}</div>}
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-800">
                          <div>{s.origin} → {s.destination}</div>
                        </td>
                        <td className="py-3 px-4">
                          <select
                            value={s.statusKey}
                            onChange={e => {
                              const newStatus = e.target.value;
                              setShipmentsList(shipmentsList.map(item => item.id === s.id ? { ...item, statusKey: newStatus } : item));
                            }}
                            className="px-2 py-1 rounded border border-slate-200 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-sky-500 bg-white"
                          >
                            <option value="PREPARING">⏳ {lang === 'tr' ? 'Hazırlanıyor' : 'Preparing'}</option>
                            <option value="TRANSIT">🚚 {lang === 'tr' ? 'Yolda' : 'In Transit'}</option>
                            <option value="CUSTOMS">🛂 {lang === 'tr' ? 'Gümrükte' : 'In Customs'}</option>
                            <option value="DELIVERED">✅ {lang === 'tr' ? 'Teslim Edildi' : 'Delivered'}</option>
                          </select>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-medium text-slate-700">
                          {s.pallets} {lang === 'tr' ? 'Palet' : 'Pallets'} · {Number(s.weight).toLocaleString()} kg
                        </td>
                        <td className="py-3 px-4 text-slate-600">
                          {s.carrier} <span className="text-slate-400">({s.mode})</span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-slate-500">{s.date}</td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex gap-3 justify-center">
                            <button
                              onClick={() => {
                                setEditingShipmentId(s.id);
                                setFormCode(s.id);
                                setFormOrigin(s.origin);
                                setFormDestination(s.destination);
                                setFormStatusKey(s.statusKey);
                                setFormMode(s.mode);
                                setFormCarrier(s.carrier);
                                setFormPallets(String(s.pallets));
                                setFormWeight(String(s.weight));
                                setFormDate(s.date);
                                setFormNote(s.note || '');
                                setFormErrors([]);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                              }}
                              className="text-sky-600 hover:text-sky-800 font-semibold"
                            >
                              {lang === 'tr' ? 'Düzenle' : 'Edit'}
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(lang === 'tr' ? 'Bu sevkiyatı silmek istediğinize emin misiniz?' : 'Delete shipment?')) {
                                  setShipmentsList(shipmentsList.filter(item => item.id !== s.id));
                                }
                              }}
                              className="text-rose-600 hover:text-rose-800 font-semibold"
                            >
                              {lang === 'tr' ? 'Sil' : 'Delete'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filteredShipments.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-400 italic">
                          {lang === 'tr' ? 'Sevkiyat bulunamadı.' : 'No shipments found.'}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'pallet' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-900">{t.palletStandard}</h3>

                <div className="grid grid-cols-3 gap-2">
                    {PALLET_STANDARDS.slice(0, 3).map(p => {
                      const displayName = lang === 'tr' ? p.nameTr : p.nameEn;
                      const parts = displayName.split(' ');
                      return (
                        <button
                          key={p.id}
                          onClick={() => setSelectedPalletId(p.id)}
                          className={`p-2.5 rounded-lg border text-left transition-all ${
                            selectedPalletId === p.id
                              ? 'border-sky-600 bg-sky-50 text-sky-900'
                              : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                          }`}
                        >
                          <div className="text-xs font-bold">{parts[0]} {parts[1] || ''}</div>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{p.lengthMm}x{p.widthMm} mm</div>
                        </button>
                      );
                    })}
                </div>

                <div className="border-t border-slate-100 pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-slate-900">{t.boxDimensions}</h3>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-600 font-medium mb-1">{lang === 'tr' ? 'Boy (mm)' : 'Length (mm)'}</label>
                      <input
                        type="number"
                        value={boxLength}
                        onChange={e => setBoxLength(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-slate-900 font-mono focus:outline-none focus:border-sky-600"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 font-medium mb-1">{lang === 'tr' ? 'En (mm)' : 'Width (mm)'}</label>
                      <input
                        type="number"
                        value={boxWidth}
                        onChange={e => setBoxWidth(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-slate-900 font-mono focus:outline-none focus:border-sky-600"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 font-medium mb-1">{lang === 'tr' ? 'Yükseklik (mm)' : 'Height (mm)'}</label>
                      <input
                        type="number"
                        value={boxHeight}
                        onChange={e => setBoxHeight(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-slate-900 font-mono focus:outline-none focus:border-sky-600"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 font-medium mb-1">{lang === 'tr' ? 'Koli Ağırlığı (kg)' : 'Box Weight (kg)'}</label>
                      <input
                        type="number"
                        step="0.5"
                        value={boxWeight}
                        onChange={e => setBoxWeight(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-slate-900 font-mono focus:outline-none focus:border-sky-600"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-4">
              <div className="bg-slate-900 text-white p-5 rounded-xl shadow-sm border border-slate-800">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                  <div>
                    <h3 className="text-sm font-bold">{lang === 'tr' ? 'Paletleme Analiz Özeti' : 'Pallet Analysis Summary'}</h3>
                    <p className="text-xs text-slate-400">{lang === 'tr' ? pallet.nameTr : pallet.nameEn}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <div className="text-xs text-slate-400">{t.boxesPerLayer}</div>
                    <div className="text-xl font-bold font-mono text-white mt-0.5">
                      {calculation.bestBoxesPerLayer} {lang === 'tr' ? 'koli' : 'boxes'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-400">{t.boxesPerPallet}</div>
                    <div className="text-xl font-bold font-mono text-white mt-0.5">
                      {calculation.boxesPerPallet} {lang === 'tr' ? 'koli' : 'boxes'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-400">{t.totalPalletsReq}</div>
                    <div className="text-xl font-bold font-mono text-amber-400 mt-0.5">
                      {calculation.totalPallets} {lang === 'tr' ? 'Palet' : 'Pallets'}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="text-sm font-bold text-slate-900 mb-4">{lang === 'tr' ? 'Görsel Palet Yerleşim Planı' : 'Layout'}</h3>
                <div className="w-full h-64 bg-slate-900 rounded-xl flex items-center justify-center p-4 relative overflow-hidden border border-slate-800">
                  <div className="text-slate-400 text-xs font-mono">3D / 2D Simulation Canvas Active</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'cost' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                <Calculator className="w-6 h-6 text-sky-600" />
                <span>{t.costCalcTitle}</span>
              </h2>
            </div>
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
              <div className="text-2xl font-bold font-mono text-slate-900">
                {totalCostOriginal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {costCurrency}
              </div>
              <div className="flex items-center justify-between mt-1">
                <div className="text-xs text-slate-500">≈ {totalCostTry.toLocaleString(undefined, { maximumFractionDigits: 2 })} ₺</div>
                <div className="text-xs font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-100 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>
                    {lang === 'tr' ? 'Tahmini Teslimat:' : 'Estimated Transit:'} {transitEstimate.minDays}-{transitEstimate.maxDays} {lang === 'tr' ? 'Gün' : 'Days'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'customs' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-6 h-6 text-emerald-600" />
                  <span>{t.customsPrepTitle}</span>
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {lang === 'tr' ? 'Gümrük Ön Hazırlık & Belge Kontrol Listesi' : 'Customs Prep & Checklist'}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleDownloadCustomsSummary(false)}
                    className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{lang === 'tr' ? 'Beyanname Özeti İndir' : 'Download Summary'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDownloadCustomsSummary(true)}
                    className="p-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl border border-emerald-200 transition-colors cursor-pointer"
                    title={lang === 'tr' ? 'Paylaş' : 'Share'}
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveScreen('expert-audit')}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-sm flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{lang === 'tr' ? 'Uzman Doğrulama Modu' : 'Expert Audit Mode'}</span>
                </button>
              </div>
            </div>

            {/* GTİP 12 Hane & BTB Yasal Uyarısı */}
            <div className="p-3.5 bg-sky-500/10 border border-sky-500/25 rounded-2xl flex items-start gap-3 text-xs">
              <Compass className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0 mt-0.5" />
              <div className="leading-relaxed text-slate-700 dark:text-slate-300">
                <span className="font-bold text-sky-900 dark:text-sky-300">
                  {lang === 'tr' ? '📌 Müşavir Hatırlatması (12 Haneli GTİP & BTB Hatırlatması): ' : '📌 Broker Advisory (12-Digit HS & BTI Reminder): '}
                </span>
                <span>
                  {lang === 'tr'
                    ? 'Uluslararası sınıflandırmadaki 6 haneli kodlar genel başlıktır; Türkiye gümrüğünde tescil ve ithalat/ihracat kontrolleri 12 haneli GTİP üzerinden yürütülür. Cezai riskleri sıfırlayan bağlayıcı tarife için Ticaret Bakanlığı\'ndan BTB (Bağlayıcı Tarife Bilgisi) talep edebilirsiniz.'
                    : '6-digit codes represent global subheadings; Turkish customs declarations are lodged strictly on 12-digit national GTIP codes. For zero-risk legal certainty, request a Binding Tariff Information (BTI) from the Ministry of Trade.'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-5 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.countryProfile}</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {CUSTOMS_COUNTRIES.map(c => {
                      const isSelected = customsCountryCode === c.code;
                      return (
                        <button
                          key={c.code}
                          type="button"
                          onClick={() => {
                            setCustomsCountryCode(c.code);
                            setCustomsHasPreferential(c.isPreferential);
                          }}
                          className={`p-2.5 rounded-lg border text-left transition-all ${
                            isSelected
                              ? 'border-emerald-600 bg-emerald-50/60 ring-1 ring-emerald-600'
                              : 'border-slate-200 bg-white hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-900">{lang === 'tr' ? c.nameTr : c.nameEn}</span>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-bold">{c.code}</span>
                          </div>
                          <div className="text-[11px] text-emerald-700 font-medium mt-1">
                            {lang === 'tr' ? c.regimeTr : c.regimeEn}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="border-t border-slate-100 pt-4 grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1.5 block">{lang === 'tr' ? 'Teslim Şekli' : 'Incoterm'}</label>
                    <select
                      value={customsIncoterm}
                      onChange={e => setCustomsIncoterm(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs font-bold focus:ring-1 focus:ring-emerald-600 focus:outline-none"
                    >
                      {['EXW', 'FOB', 'CIF', 'CIP', 'DAP', 'DDP'].map(i => <option key={i} value={i}>{i}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-700 mb-1.5 block">{lang === 'tr' ? 'Ödeme Şekli' : 'Payment Method'}</label>
                    <select
                      value={customsPaymentMethod}
                      onChange={e => setCustomsPaymentMethod(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs font-bold focus:ring-1 focus:ring-emerald-600 focus:outline-none"
                    >
                      {PAYMENT_METHODS.map(pm => <option key={pm.id} value={pm.id}>{lang === 'tr' ? pm.nameTr : (pm.nameEn || pm.nameTr)}</option>)}
                    </select>
                  </div>
                </div>

                <div className="border-t border-slate-100 pt-4">
                  <label className="text-xs font-semibold text-slate-700 mb-1.5 block">{t.hsCodeLabel}</label>
                  <input
                    type="text"
                    value={customsHsCode}
                    onChange={e => setCustomsHsCode(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs font-mono font-bold tracking-wider focus:ring-1 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>

                <div className="border-t border-slate-100 pt-4 space-y-4">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                    <h3 className="text-xs font-bold text-slate-900">{t.requiredDocsList}</h3>
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded">
                      {checkedItemsCount} / {totalChecklistItems} {lang === 'tr' ? 'Hazır' : 'Ready'} (%{readinessPercent})
                    </span>
                  </div>

                  <div className="space-y-4">
                    {customsChecklistPlan.sections.map((section, sIdx) => (
                      <div key={sIdx} className="space-y-2">
                        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                          <span>{lang === 'tr' ? section.title : (section.titleEn || section.title)}</span>
                        </div>
                        <div className="space-y-2">
                          {section.items.map(item => {
                            const isChecked = Boolean(customsCheckedDocs[item.id]);
                            return (
                              <div key={item.id} className={`p-3 rounded-xl border transition-colors ${isChecked ? 'bg-emerald-50/30 border-emerald-300' : 'bg-white border-slate-200'}`}>
                                <div className="flex items-start gap-2.5">
                                  <input
                                    type="checkbox"
                                    id={`check_${item.id}`}
                                    checked={isChecked}
                                    onChange={() => setCustomsCheckedDocs(prev => ({ ...prev, [item.id]: !prev[item.id] }))}
                                    className="mt-1 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer shrink-0"
                                  />
                                  <div className="flex-1">
                                    <label htmlFor={`check_${item.id}`} className={`text-xs cursor-pointer font-bold ${isChecked ? 'text-slate-900 line-through opacity-75' : 'text-slate-900'}`}>
                                      {lang === 'tr' ? item.title : (item.titleEn || item.title)}
                                    </label>
                                    <p className="text-[11px] text-slate-600 mt-1">{lang === 'tr' ? item.detail : (item.detailEn || item.detail)}</p>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-slate-900 text-white p-5 rounded-xl border border-slate-800 shadow-sm space-y-4">
                  <div className="text-xs font-bold text-slate-400">{t.customsTitle}</div>
                  <div className="text-2xl font-extrabold font-mono text-white">
                    {totalLandedCostTryCalculated.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₺
                  </div>
                  <div className="pt-2 border-t border-white/10">
                    {selectedCountry.sourceUrl ? (
                      <a 
                        href={selectedCountry.sourceUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-[10px] text-sky-400 hover:text-sky-300 flex items-center gap-1 font-semibold transition-colors"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>{lang === 'tr' ? 'Resmi Kaynak (Vergi Oranı)' : 'Official Duty Source'}</span>
                      </a>
                    ) : (
                      <div className="text-[10px] text-amber-400 flex items-start gap-1.5 leading-tight italic">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>
                          {lang === 'tr' 
                            ? 'Bu oran doğrulanmamıştır, resmi kaynaktan teyit edin.' 
                            : 'This rate is unverified, please confirm from official source.'}
                        </span>
                      </div>
                    )}

                    {(lang === 'tr' ? selectedCountry.noteTr : selectedCountry.noteEn || selectedCountry.noteTr) && (
                      <div className="text-[10px] text-slate-300 mt-2 pt-2 border-t border-white/5 flex items-start gap-1.5 leading-tight italic opacity-90">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1 shrink-0" />
                        <span>{lang === 'tr' ? selectedCountry.noteTr : selectedCountry.noteEn || selectedCountry.noteTr}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'expert-audit' && (
          <div className="space-y-6">
            {/* Top Navigation & Mode Switcher */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm print:hidden">
              <div>
                <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-6 h-6 text-sky-600" />
                  <span>{lang === 'tr' ? 'GTİP & Vergi Yapay Zeka Ön Değerlendirme (Doğrulanmamış)' : 'HS Code & Duty AI Pre-Assessment (Unverified)'}</span>
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {lang === 'tr'
                    ? 'Yapay zeka GTİP ve vergi için ön tahmin üretir. Sonuç resmi kaynaktan doğrulanmış değildir; beyanname öncesi Access2Markets/TARIC veya gümrük müşaviri ile teyit edin.'
                    : 'AI produces a preliminary estimate for HS code and duty. It is NOT verified against official sources; confirm via Access2Markets/TARIC or a licensed customs broker.'}
                </p>
              </div>

              {/* Mode Segmented Controls */}
              <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setAiAuditActiveTab('hybrid-ai')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                    aiAuditActiveTab === 'hybrid-ai'
                      ? 'bg-white text-sky-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>{lang === 'tr' ? 'AI Ön Değerlendirme' : 'AI Pre-Assessment'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAiAuditActiveTab('checklist')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                    aiAuditActiveTab === 'checklist'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>{lang === 'tr' ? 'Müşavir Kontrol Listesi' : 'Broker Checklist'}</span>
                </button>
              </div>
            </div>

            {/* TAB 1: HYBRID AI & UN COMTRADE AUDIT */}
            {aiAuditActiveTab === 'hybrid-ai' && (
              <div className="space-y-6">
                {/* Institutional Audit Protocol Banner */}
                <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-start sm:items-center gap-2.5">
                    <div className="p-2 bg-sky-500/20 text-sky-400 rounded-xl border border-sky-500/30 shrink-0">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-white text-sm flex items-center gap-2">
                        <span>Resmi Dış Ticaret & Gümrük Uyum Denetim Protokolü</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          DENETİM KORUMALI
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        Menşe: <strong className="text-slate-200">Türkiye (TR)</strong> · Yön: <strong className="text-slate-200">İhracat Uyum</strong> · Dayanak: 4458 G.K. Md. 8-9 (BTI), 1/95 OKK (A.TR). Resmi teyit: AB Access2Markets/TARIC, ülke gümrük idaresi.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400 self-end sm:self-auto shrink-0 font-mono">
                    <span className="flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Sıfır Halüsinasyon</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-sky-400" />
                      <span>Resmi Kanıt</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Yasal Disclaimer</span>
                    </span>
                  </div>
                </div>

                {/* Search & Configuration Bar */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-3">
                    <div className="flex-1">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'tr' ? 'GTİP / HS Kodu (6 veya 12 Haneli)' : 'HS / GTIP Code'}
                      </label>
                      <input
                        type="text"
                        value={aiAuditHsCode}
                        onChange={e => setAiAuditHsCode(e.target.value)}
                        placeholder="Örn: 8471.30.00.00.00"
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-mono font-medium focus:outline-none focus:ring-2 focus:ring-sky-500"
                      />
                    </div>

                    <div className="w-full sm:w-56">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'tr' ? 'Hedef Ülke' : 'Target Country'}
                      </label>
                      <input
                        type="text"
                        value={aiAuditCountry}
                        onChange={e => setAiAuditCountry(e.target.value)}
                        placeholder="Örn: Almanya"
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-sky-500"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleRunAiAudit(false)}
                        disabled={aiAuditLoading}
                        className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        <Zap className="w-4 h-4" />
                        <span>
                          {aiAuditLoading
                            ? (lang === 'tr' ? 'Denetleniyor...' : 'Auditing...')
                            : (lang === 'tr' ? 'AI ile Denetle & Doğrula' : 'Run AI Audit')}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleRunAiAudit(true)}
                        disabled={aiAuditLoading}
                        title={lang === 'tr' ? '30 günlük önbelleği atla ve dış API\'den yeniden doğrula' : 'Bypass cache and force refresh from external API'}
                        className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${aiAuditLoading ? 'animate-spin' : ''}`} />
                        <span className="hidden sm:inline">{lang === 'tr' ? 'Zorla Yenile' : 'Force Refresh'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Active Official Sources Badge */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-500">
                      <span className="font-semibold text-slate-700">Resmi Kaynaklar:</span>
                      <a href="https://trade.ec.europa.eu/access-to-markets" target="_blank" rel="noopener noreferrer" className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded font-medium border border-blue-200 hover:bg-blue-100">
                        🇪🇺 Access2Markets ↗
                      </a>
                      <a href="https://www.macmap.org" target="_blank" rel="noopener noreferrer" className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-medium hover:bg-slate-200">
                        🌐 ITC Market Access Map ↗
                      </a>
                      <a href="https://uygulama.gtb.gov.tr/Tara" target="_blank" rel="noopener noreferrer" className="px-2 py-0.5 bg-red-50 text-red-700 rounded font-medium border border-red-200 hover:bg-red-100">
                        🇹🇷 Ticaret Bakanlığı Tara ↗
                      </a>
                    </div>

                    <div className="text-[11px] text-slate-400">
                      Bu araç resmi veritabanına bağlı değildir; oranları yukarıdaki resmi kaynaklardan teyit edin.
                    </div>
                  </div>

                  {/* Sample Quick Chips */}
                  <div className="flex flex-wrap items-center gap-1.5 text-xs">
                    <span className="text-slate-500 font-medium">{lang === 'tr' ? 'Hızlı Test Kodları:' : 'Quick Test Codes:'}</span>
                    {[
                      { code: '8471.30.00.00.00', country: 'Almanya', label: '8471.30 (Almanya - Taşınabilir PC)' },
                      { code: '6205.20.00.00.00', country: 'Fransa', label: '6205.20 (Fransa - Pamuklu Gömlek)' },
                      { code: '1509.20.00.00.00', country: 'İtalya', label: '1509.20 (İtalya - Sızma Zeytinyağı)' },
                      { code: '8481.20.10.00.00', country: 'İspanya', label: '8481.20 (İspanya - Hidrolik Valf)' },
                      { code: '8517.13.00.00.00', country: 'Hollanda', label: '8517.13 (Hollanda - Akıllı Telefon)' },
                      { code: '6109.10', country: 'Almanya', label: '6109.10 (Almanya - Tişört)' }
                    ].map(sample => (
                      <button
                        key={sample.code + sample.country}
                        type="button"
                        onClick={() => {
                          setAiAuditHsCode(sample.code);
                          setAiAuditCountry(sample.country);
                          setTimeout(() => handleRunAiAudit(true), 50);
                        }}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-sky-50 hover:text-sky-700 text-slate-600 rounded-lg text-xs font-mono transition-colors cursor-pointer"
                      >
                        {sample.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Error Banner */}
                {aiAuditError && (
                  <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                    <span>{aiAuditError}</span>
                  </div>
                )}

                {/* Loading State */}
                {aiAuditLoading && (
                  <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm text-center space-y-3">
                    <div className="w-10 h-10 border-4 border-sky-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    <h3 className="text-sm font-bold text-slate-900">
                      {lang === 'tr' ? 'Yapay Zeka Denetimi Yürütülüyor' : 'Running AI Customs Verification'}
                    </h3>
                    <p className="text-xs text-slate-500 max-w-md mx-auto">
                      {lang === 'tr'
                        ? 'Yapay zeka ön tahmini hazırlanıyor (resmi kaynak sorgulanmıyor).'
                        : 'Preparing AI estimate (no official source is queried).'}
                    </p>
                  </div>
                )}

                {/* Results Card */}
                {aiAuditResult && !aiAuditLoading && (
                  <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-6">
                    <OfficialDataCard info={officialInfo} lang={lang} />
                    {/* Header Strip with Strict 5-Rule Metadata */}
                    <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                      <div className="flex items-center gap-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-extrabold tracking-wide ${
                          aiAuditResult.source === 'expert_table'
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                            : 'bg-amber-100 text-amber-900 border border-amber-300'
                        }`}>
                          {aiAuditResult.source === 'expert_table'
                            ? '✔ UZMAN ONAYLI TABLO'
                            : aiAuditResult.source === 'device_cache'
                            ? `⚠ KAYITLI AI TAHMİNİ — ${new Date(aiAuditResult.data.cached_at).toLocaleDateString('tr-TR')}${aiAuditResult.data.stale ? ' (süresi doldu)' : ''}`
                            : '⚠ DOĞRULANMAMIŞ — AI TAHMİNİ'}
                        </span>

                        <span className="font-mono text-slate-700 font-bold">
                          GTİP: {aiAuditResult.data.hs_code} · {aiAuditResult.data.country}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-slate-600">
                        <div>
                          <span className="text-slate-400 font-medium">Sorgu Tarihi: </span>
                          <span className="font-mono font-bold text-slate-900">{aiAuditResult.data.last_verification_date}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 font-medium">Kaynak: </span>
                          <span className="font-semibold text-slate-900">{aiAuditResult.data.provenance?.primary_source}</span>
                          <span className="text-sky-600 ml-1 font-mono">({aiAuditResult.data.provenance?.confidence_score})</span>
                        </div>
                      </div>
                    </div>

                    {/* Comparison Log & DIFF Section */}
                    {aiAuditResult.data.comparison_log && (
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                          <Layers className="w-4 h-4 text-sky-600" />
                          <span>{lang === 'tr' ? 'Karşılaştırma Günlüğü (Comparison Log & DIFF)' : 'Comparison Log & DIFF'}</span>
                        </h4>
                        <div className="border border-slate-200 rounded-xl overflow-hidden">
                          <table className="w-full text-left text-xs">
                            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                              <tr>
                                <th className="p-3 w-1/4">Kontrol Unvanı</th>
                                <th className="p-3 w-3/8 text-rose-700 bg-rose-50/50">Önceki Veri (previous_value)</th>
                                <th className="p-3 w-3/8 text-emerald-700 bg-emerald-50/50">Doğrulanan Yeni Veri (new_value)</th>
                                <th className="p-3 text-center">Fark Durumu</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                              <tr className="hover:bg-slate-50">
                                <td className="p-3 font-semibold text-slate-800 font-mono">Gümrük Vergisi Oranı</td>
                                <td className="p-3 text-slate-700 bg-rose-50/30 font-mono font-semibold">
                                  {aiAuditResult.data.comparison_log.previous_value}
                                </td>
                                <td className="p-3 text-emerald-800 bg-emerald-50/30 font-mono font-bold">
                                  {aiAuditResult.data.comparison_log.new_value}
                                </td>
                                <td className="p-3 text-center">
                                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                                    aiAuditResult.data.comparison_log.change_detected
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-emerald-100 text-emerald-800'
                                  }`}>
                                    {aiAuditResult.data.comparison_log.change_detected ? 'Değişiklik Var' : 'Fark Yok'}
                                  </span>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {/* Verified Tariff Parameters Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                        <div className="text-[11px] font-bold text-slate-500">Temel Gümrük Vergisi (Base Duty)</div>
                        <div className="text-sm font-mono font-bold text-slate-900">
                          {aiAuditResult.data.tariff_details?.base_duty_rate}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          KDV Oranı: <span className="font-semibold text-slate-800 font-mono">{aiAuditResult.data.tariff_details?.vat_rate}</span>
                        </div>
                      </div>

                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1 md:col-span-2">
                        <div className="text-[11px] font-bold text-slate-500">Mevzuat Koşulları & Zorunlu Belgeler (Conditions)</div>
                        <div className="text-xs font-medium text-slate-900 leading-relaxed">
                          {aiAuditResult.data.tariff_details?.conditions}
                        </div>
                      </div>
                    </div>

                    {/* Legal Disclaimer Box */}
                    <div className="p-4 bg-amber-50/80 border border-amber-300 rounded-xl text-xs space-y-1">
                      <div className="font-extrabold text-amber-950 flex items-center gap-1.5 uppercase tracking-wide">
                        <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                        <span>Yasal Sorumluluk Reddi (Mandatory Legal Disclaimer)</span>
                      </div>
                      <p className="text-amber-900 leading-relaxed text-[11px] font-medium">
                        {aiAuditResult.data.disclaimer}
                      </p>
                    </div>

                    {/* Strict JSON Output Inspector */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                          <FileText className="w-4 h-4 text-slate-600" />
                          <span>JSON Veri Paketi (Doğrulanmamış Ön Değerlendirme)</span>
                        </h4>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleCopyAiJson}
                            className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span>{aiAuditCopied ? 'Kopyalandı!' : 'JSON Kopyala'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              const jsonStr = JSON.stringify(aiAuditResult.data, null, 2);
                              const blob = new Blob([jsonStr], { type: 'application/json' });
                              const url = URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `customs_verified_${String(aiAuditResult.data.hs_code).replace(/\D/g, '')}_${aiAuditResult.data.last_verification_date}.json`;
                              a.click();
                              URL.revokeObjectURL(url);
                            }}
                            className="px-3 py-1 bg-sky-50 text-sky-700 hover:bg-sky-100 rounded-lg text-xs font-bold border border-sky-200 transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>JSON İndir</span>
                          </button>
                        </div>
                      </div>

                      <pre className="p-4 bg-slate-900 text-emerald-400 rounded-xl text-xs font-mono overflow-x-auto max-h-80 leading-relaxed border border-slate-800">
                        {JSON.stringify(aiAuditResult.data, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: BROKER CHECKLIST (Existing Functionality Preserved) */}
            {aiAuditActiveTab === 'checklist' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={inspectorName}
                      onChange={e => !isReportConfirmed && setInspectorName(e.target.value)}
                      placeholder={lang === 'tr' ? 'Denetleyen Adı Soyadı' : 'Inspector Name'}
                      className="px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-sky-600 w-48"
                      disabled={isReportConfirmed}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!inspectorName.trim()) {
                          notify(lang === 'tr' ? 'Onay için denetleyen Ad Soyad zorunludur.' : 'Inspector name is required to confirm.', 'error');
                          return;
                        }
                        if (confirm(lang === 'tr' ? 'Bu raporu onaylamak istediğinize emin misiniz? Bu işlem geri alınamaz.' : 'Are you sure you want to confirm this report? This action is irreversible.')) {
                          setIsReportConfirmed(true);
                        }
                      }}
                      disabled={isReportConfirmed}
                      className={`px-4 py-2 rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 ${
                        isReportConfirmed ? 'bg-emerald-600 text-white cursor-not-allowed opacity-90' : 'bg-slate-800 text-white hover:bg-slate-900'
                      }`}
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>{isReportConfirmed ? (lang === 'tr' ? 'Tamamlandı/Onaylandı' : 'Completed/Confirmed') : (lang === 'tr' ? 'Tamamla/Onayla' : 'Complete/Confirm')}</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleDownloadExpertAuditTxt}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>{lang === 'tr' ? 'Metin Raporu İndir (.txt)' : 'Download .txt Report'}</span>
                    </button>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleDownloadExpertAuditPdf(false)}
                        className="px-3 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-sm flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">{lang === 'tr' ? 'Uzman Raporu İndir' : 'Download Expert Report'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDownloadExpertAuditPdf(true)}
                        className="p-2 bg-sky-50 text-sky-700 hover:bg-sky-100 rounded-xl border border-sky-200 transition-colors cursor-pointer"
                        title={lang === 'tr' ? 'Paylaş' : 'Share'}
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-6">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                <div>
                  <div className="text-slate-500">{lang === 'tr' ? 'Hedef Ülke' : 'Destination'}</div>
                  <div className="font-bold text-slate-900 mt-0.5">{lang === 'tr' ? selectedCountry.nameTr : selectedCountry.nameEn} ({customsCountryCode})</div>
                </div>
                <div>
                  <div className="text-slate-500">{lang === 'tr' ? 'GTİP Kodu' : 'HS Code'}</div>
                  <div className="font-mono font-bold text-emerald-700 mt-0.5">{customsHsCode}</div>
                </div>
                <div>
                  <div className="text-slate-500">{lang === 'tr' ? 'CIF Mal Bedeli' : 'CIF Value'}</div>
                  <div className="font-mono font-bold text-slate-900 mt-0.5">{customsCifOriginal.toLocaleString()} {customsCurrency}</div>
                </div>
                <div>
                  <div className="text-slate-500">{lang === 'tr' ? 'Doğrulanan Madde' : 'Verified Items'}</div>
                  <div className="font-bold text-sky-700 mt-0.5">
                    {Object.values(expertAuditNotes).filter(v => v.status === 'CORRECT').length} / {allCustomsChecklistItems.length}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {allCustomsChecklistItems.map((item, index) => {
                  const audit = expertAuditNotes[item.id] || { status: 'PENDING', note: '' };
                  return (
                    <div key={item.id} className="p-4 rounded-xl border border-slate-200 bg-white space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <span className="w-6 h-6 rounded-full bg-sky-100 text-sky-800 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                            {index + 1}
                          </span>
                          <div>
                            <h4 className="text-sm font-bold text-slate-900">{lang === 'tr' ? item.title : (item.titleEn || item.title)}</h4>
                            <p className="text-xs text-slate-600 mt-0.5">{lang === 'tr' ? item.detail : (item.detailEn || item.detail)}</p>
                          </div>
                        </div>

                        {/* Status Toggle Buttons */}
                        <div className="flex items-center gap-1.5 self-start sm:self-auto shrink-0 print:hidden">
                          <button
                            type="button"
                            onClick={() => setExpertAuditNotes(prev => ({
                              ...prev,
                              [item.id]: { ...audit, status: 'CORRECT' }
                            }))}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                              audit.status === 'CORRECT'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            ✓ {lang === 'tr' ? 'Doğru' : 'Correct'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setExpertAuditNotes(prev => ({
                              ...prev,
                              [item.id]: { ...audit, status: 'INCORRECT' }
                            }))}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                              audit.status === 'INCORRECT'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            ✕ {lang === 'tr' ? 'Yanlış / Eksik' : 'Incorrect'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setExpertAuditNotes(prev => ({
                              ...prev,
                              [item.id]: { ...audit, status: 'PENDING' }
                            }))}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                              audit.status === 'PENDING'
                                ? 'bg-amber-500 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            ? {lang === 'tr' ? 'Beklemede' : 'Pending'}
                          </button>
                        </div>
                      </div>

                      {/* Expert Note Input */}
                      <div>
                        <input
                          type="text"
                          value={audit.note}
                          onChange={e => !isReportConfirmed && setExpertAuditNotes(prev => ({
                              ...prev,
                              [item.id]: { ...audit, note: e.target.value }
                          }))}
                          placeholder={lang === 'tr' ? 'Gümrük müşaviri notu ekleyin (örn: Onaylandı, eksik imza var vb.)' : 'Add expert auditor note...'}
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-1 focus:ring-sky-600 bg-slate-50 font-medium print:bg-white print:border-none"
                          disabled={isReportConfirmed}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    )}

        {activeScreen === 'roadmap' && (
          <div className="space-y-6">
            {/* Header Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm print:hidden">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold mb-2">
                  <Compass className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'tr' ? '6 Temel Adımda İhracata Başlangıç' : '6 Core Steps to Start Exporting'}</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                  {lang === 'tr' ? 'Dış Ticarete İlk Kez Başlayanlar İçin Yol Haritası' : 'Roadmap For First-Time Foreign Traders'}
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
                  {lang === 'tr'
                    ? 'Hiç ihracat yapmadınız mı? Şirket kuruluşundan İhracatçılar Birliği kaydına, gümrük müşaviri yetkilendirmesinden GTİP tespitine, resmi fatura/çeki listesinden teslim ve 180 günlük İBKB bedel kapanışına kadar tüm yasal süreçler ve zorunlu evraklar aşağıda adım adım açıklanmıştır.'
                    : 'From establishing a company to your first customs declaration, HS codes, circulation certificates, and 180-day proceeds closing, all mandatory procedures and paperwork are explained below.'}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(lang === 'tr' ? 'Tüm adımların işaretini sıfırlamak istediğinize emin misiniz?' : 'Reset all step checkboxes?')) {
                      setCompletedGuideSteps({});
                    }
                  }}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{lang === 'tr' ? 'Sıfırla' : 'Reset'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{lang === 'tr' ? 'Yazdır / PDF' : 'Print / PDF'}</span>
                </button>
              </div>
            </div>

            {/* Readiness Progress Bar Card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-lg">
                    {Object.values(completedGuideSteps).filter(Boolean).length}/6
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      {lang === 'tr' ? 'İhracata Hazırlık Seviyeniz' : 'Export Readiness Score'}
                    </div>
                    <div className="text-xs text-slate-500">
                      {lang === 'tr'
                        ? `${Object.values(completedGuideSteps).filter(Boolean).length} / 6 temel aşama tamamlandı`
                        : `${Object.values(completedGuideSteps).filter(Boolean).length} / 6 core stages completed`}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-2xl font-black text-emerald-700 font-mono">
                    %{Math.round((Object.values(completedGuideSteps).filter(Boolean).length / 6) * 100)}
                  </span>
                </div>
              </div>

              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden border border-slate-200/60">
                <div
                  className="h-full bg-emerald-500 transition-all duration-300 rounded-full"
                  style={{ width: `${Math.round((Object.values(completedGuideSteps).filter(Boolean).length / 6) * 100)}%` }}
                />
              </div>
            </div>

            {/* 6 Core Steps List */}
            <div className="space-y-4">
              {BEGINNER_GUIDE_STEPS.map((step) => {
                const isOpen = activeGuideStep === step.id;
                const isDone = !!completedGuideSteps[step.id];

                return (
                  <div
                    key={step.id}
                    className={`rounded-2xl border transition-all overflow-hidden ${
                      isDone
                        ? 'border-emerald-300 bg-emerald-50/20 shadow-xs'
                        : isOpen
                        ? 'border-sky-400 bg-white shadow-md ring-1 ring-sky-400/20'
                        : 'border-slate-200 bg-white hover:border-slate-300 shadow-xs'
                    }`}
                  >
                    {/* Step Header */}
                    <div
                      onClick={() => setActiveGuideStep(isOpen ? null : step.id)}
                      className="p-5 flex items-center justify-between cursor-pointer select-none gap-4"
                    >
                      <div className="flex items-center gap-3.5 min-w-0">
                        <input
                          type="checkbox"
                          checked={isDone}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) => {
                            setCompletedGuideSteps({
                              ...completedGuideSteps,
                              [step.id]: e.target.checked
                            });
                          }}
                          className="w-5 h-5 rounded text-emerald-600 bg-white border-slate-300 focus:ring-emerald-500 cursor-pointer shrink-0"
                        />
                        <div className="min-w-0">
                          <h3 className={`text-sm sm:text-base font-bold truncate ${isDone ? 'text-emerald-900 line-through' : 'text-slate-900'}`}>
                            {lang === 'tr' ? step.titleTr : step.titleEn}
                          </h3>
                          <span className="text-xs text-slate-500 font-medium">
                            {isDone ? (lang === 'tr' ? '✓ Tamamlandı' : '✓ Completed') : (lang === 'tr' ? 'Beklemede' : 'Pending')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-xs font-bold text-sky-600 hover:text-sky-700 hidden sm:inline">
                          {isOpen ? (lang === 'tr' ? 'Detayları Kapat' : 'Collapse') : (lang === 'tr' ? 'Detayları Gör' : 'Expand')}
                        </span>
                        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180 text-sky-600' : ''}`} />
                      </div>
                    </div>

                    {/* Step Body (Expanded) */}
                    {isOpen && (
                      <div className="px-5 pb-5 pt-1 border-t border-slate-100 space-y-4 text-xs text-slate-700 bg-white">
                        <p className="leading-relaxed text-slate-600 sm:text-sm">
                          {lang === 'tr' ? step.descTr : step.descEn}
                        </p>

                        {/* Mandatory Documents Grid */}
                        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2.5">
                          <span className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                            {lang === 'tr' ? '📌 Bu Adımda Gereken Resmi Belgeler:' : '📌 Mandatory Documents in this Step:'}
                          </span>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {(lang === 'tr' ? step.docsTr : step.docsEn).map((doc, idx) => (
                              <div key={idx} className="flex items-center gap-2 bg-white p-2.5 rounded-lg border border-slate-200 text-slate-800 shadow-2xs">
                                <span className="w-2 h-2 bg-sky-500 rounded-full shrink-0" />
                                <span className="font-semibold text-xs leading-tight">{doc}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Expert Advice Callout */}
                        <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 flex gap-3">
                          <span className="text-lg shrink-0">💡</span>
                          <div className="leading-relaxed text-xs">
                            <span className="font-bold text-amber-950">
                              {lang === 'tr' ? 'Uzman Tavsiyesi: ' : 'Expert Advice: '}
                            </span>
                            {lang === 'tr' ? step.tipTr : step.tipEn}
                          </div>
                        </div>

                        {/* Action Link to Applet Tool */}
                        {step.actionRoute && (
                          <div className="pt-2 flex justify-end">
                            <button
                              type="button"
                              onClick={() => setActiveScreen(step.actionRoute!)}
                              className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                            >
                              <span>{lang === 'tr' ? step.actionLabelTr : step.actionLabelEn}</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Operational 9-Step Lifecycle (Timeline) */}
            <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-sm space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
                    <Truck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">
                      {lang === 'tr' ? 'Operasyonel İhracat Döngüsü & Süre Takibi (9 Adım)' : 'Operational Export Lifecycle & Deadlines (9 Steps)'}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {lang === 'tr'
                        ? 'İhracat beyannamesinin kapanmasından 180 günlük İBKB bedel getirme kuralına kadar operasyonel iş akışı.'
                        : 'Routine shipment lifecycle from customs declaration to the 180-day foreign currency repatriation deadline.'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveScreen('shipments')}
                  className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold transition-colors shrink-0 cursor-pointer"
                >
                  {lang === 'tr' ? 'Sevkiyat Takibini Aç' : 'Open Shipments'}
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {ROADMAP_STEPS.map((step, idx) => {
                  const isDone = !!completedRoadmapSteps[step.id];
                  return (
                    <div
                      key={step.id}
                      className={`p-3.5 rounded-xl border text-xs transition-all flex flex-col justify-between ${
                        isDone
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                          : 'bg-slate-800/80 border-slate-700/80 text-slate-300'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-1.5">
                          <span className="font-bold text-white flex items-center gap-1.5">
                            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                              isDone ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-200'
                            }`}>
                              {idx + 1}
                            </span>
                            <span>{lang === 'tr' ? step.titleTr : step.titleEn}</span>
                          </span>
                          <input
                            type="checkbox"
                            checked={isDone}
                            onChange={(e) => {
                              setCompletedRoadmapSteps({
                                ...completedRoadmapSteps,
                                [step.id]: e.target.checked
                              });
                            }}
                            className="w-4 h-4 rounded text-emerald-500 bg-slate-900 border-slate-600 focus:ring-emerald-500 cursor-pointer"
                          />
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          {lang === 'tr' ? step.detailTr : step.detailEn}
                        </p>
                      </div>

                      {step.route && (
                        <div className="pt-2 mt-2 border-t border-slate-700/50">
                          <button
                            type="button"
                            onClick={() => setActiveScreen(step.route as Screen)}
                            className="text-[11px] font-bold text-sky-400 hover:text-sky-300 flex items-center gap-1 cursor-pointer"
                          >
                            <span>{lang === 'tr' ? step.routeLabelTr : step.routeLabelEn}</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'settings' && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2 mb-4">
                <Edit2 className="w-6 h-6 text-sky-600" />
                <span>{lang === 'tr' ? 'Ayarlar & Lisans' : 'Settings & License'}</span>
              </h2>

              <div className="space-y-6">
                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/50">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-sm font-bold text-slate-900">{lang === 'tr' ? 'Hesap Durumu' : 'Account Status'}</div>
                      <div className="text-xs text-slate-500">{lang === 'tr' ? 'Mevcut abonelik seviyeniz' : 'Current subscription level'}</div>
                    </div>
                    {isPro ? (
                      <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold border border-emerald-200 flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4" />
                        PRO PLAN
                      </span>
                    ) : (
                      <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-bold border border-slate-200">
                        FREE PLAN
                      </span>
                    )}
                  </div>

                  {!isPro && (
                    <div className="space-y-4 pt-2">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1.5">{lang === 'tr' ? 'Lisans Anahtarı' : 'License Key'}</label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={licenseKey}
                            onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                            placeholder="XXXX-XXXX-XXXX-XXXX"
                            className="flex-1 px-3 py-2 rounded-lg border border-slate-200 text-xs font-mono focus:ring-1 focus:ring-sky-600 focus:outline-none"
                          />
                          <button
                            onClick={async () => {
                              try {
                                const r = await fetch('/api/license/verify', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ key: licenseKey }),
                                });
                                const j = await r.json();
                                if (j.valid && j.token) {
                                  localStorage.setItem('licenseToken', j.token);
                                  setLicenseToken(j.token);
                                  setLicenseKey('');
                                  notify(lang === 'tr' ? 'PRO lisansı başarıyla aktifleştirildi!' : 'PRO license activated successfully!', 'success');
                                } else if (j.reason === 'not_configured') {
                                  notify(lang === 'tr' ? 'Lisans servisi bu sürümde henüz yapılandırılmadı.' : 'License service is not configured yet.', 'error');
                                } else {
                                  notify(lang === 'tr' ? 'Geçersiz lisans anahtarı.' : 'Invalid license key.', 'error');
                                }
                              } catch {
                                notify(lang === 'tr' ? 'Lisans doğrulanamadı. Bağlantınızı kontrol edin.' : 'Could not verify license.', 'error');
                              }
                            }}
                            className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold transition-colors"
                          >
                            {lang === 'tr' ? 'Doğrula' : 'Verify'}
                          </button>
                        </div>
                        
                      </div>
                    </div>
                  )}

                  {isPro && (
                    <button
                      onClick={() => {
                        localStorage.removeItem('licenseToken');
                        setLicenseToken('');
                        setIsPro(false);
                        setLicenseKey('');
                      }}
                      className="text-xs font-bold text-rose-600 hover:text-rose-700 underline"
                    >
                      {lang === 'tr' ? 'Lisansı İptal Et' : 'Deactivate License'}
                    </button>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-bold text-slate-900 dark:text-white">{lang === 'tr' ? 'Uygulama Tercihleri' : 'App Preferences'}</div>
                  <div className="flex items-center justify-between p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
                    <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{lang === 'tr' ? 'Dil / Language' : 'Language'}</span>
                    <select
                      value={lang}
                      onChange={(e) => setLang(e.target.value as Language)}
                      className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 text-xs font-bold focus:outline-none"
                    >
                      <option value="tr">Türkçe</option>
                      <option value="en">English</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
                    <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{lang === 'tr' ? 'Tema / Theme Mode' : 'Theme Mode'}</span>
                    <button
                      onClick={toggleTheme}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-2 border border-slate-200 dark:border-slate-700 hover:border-sky-500 transition-all cursor-pointer"
                    >
                      {theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-sky-600" />}
                      <span>{theme === 'dark' ? (lang === 'tr' ? 'Koyu Mod (Aktif)' : 'Dark Mode (Active)') : (lang === 'tr' ? 'Açık Mod (Aktif)' : 'Light Mode (Active)')}</span>
                    </button>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl border border-sky-100 bg-sky-50/60">
                    <div>
                      <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <Compass className="w-3.5 h-3.5 text-sky-600" />
                        <span>{lang === 'tr' ? 'Karşılama & Oryantasyon Ekranı' : 'Welcome & Onboarding Screen'}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {lang === 'tr'
                          ? 'İlk ziyaretteki 6 adımlı dış ticaret yol haritası özetini ve karşılama panelini yeniden açar.'
                          : 'Re-displays the first-visit roadmap summary and welcome orientation screen.'}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={showWelcomeAgain}
                      className="px-3.5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold shadow-xs transition-colors whitespace-nowrap self-start sm:self-auto cursor-pointer flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>{lang === 'tr' ? 'Karşılama Ekranını Tekrar Göster' : 'Show Welcome Screen Again'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'mistakes' && (
          <div className="space-y-6 max-w-5xl mx-auto">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-rose-50 -mr-8 -mt-8 rounded-full blur-2xl opacity-60" />
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <h2 className="text-xl font-extrabold text-slate-900">
                    {lang === 'tr' ? 'İhracatçıların En Sık Yaptığı 10 Kritik Hata' : 'Top 10 Critical Exporting Mistakes'}
                  </h2>
                </div>
                <p className="text-sm text-slate-600">
                  {lang === 'tr' 
                    ? 'Operasyonel gecikmeleri ve maddi cezaları önlemek için bu maddeleri mutlaka kontrol edin.' 
                    : 'Review these common pitfalls to avoid operational delays and financial penalties.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {TOP_MISTAKES.map((m, idx) => (
                <div key={m.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-rose-300 transition-all group">
                  <div className="flex items-start gap-4">
                    <span className="w-8 h-8 rounded-lg bg-slate-50 text-slate-400 flex items-center justify-center font-mono font-bold text-sm shrink-0 border border-slate-100">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <div className="space-y-2">
                      <h3 className="font-bold text-slate-900 group-hover:text-rose-700 transition-colors">
                        {lang === 'tr' ? m.titleTr : m.titleEn}
                      </h3>
                      <p className="text-xs leading-relaxed text-slate-600">
                        {lang === 'tr' ? m.descTr : m.descEn}
                      </p>
                      <button
                        onClick={() => setActiveScreen(m.linkRoute as Screen)}
                        className="text-[11px] font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1 mt-1 transition-colors"
                      >
                        <ChevronRight className="w-3.5 h-3.5" />
                        <span>{lang === 'tr' ? m.linkTitleTr : m.linkTitleEn}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-slate-900 p-6 rounded-2xl text-white flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4 text-center md:text-left">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <div>
                  <div className="font-bold text-lg">{lang === 'tr' ? 'Eksiksiz İhracat İçin İlk Adımı At' : 'Complete and Ready to Start Your Export'}</div>
                  <div className="text-sm text-slate-400">{lang === 'tr' ? 'Yol haritasını takip ederek adım adım ilerleyin.' : 'Follow the roadmap to ensure compliance at every step.'}</div>
                </div>
              </div>
              <button
                onClick={() => setActiveScreen('roadmap')}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-emerald-900/20 cursor-pointer"
              >
                {lang === 'tr' ? 'Yol Haritasını Gör' : 'View Roadmap'}
              </button>
            </div>
          </div>
        )}

        {activeScreen === 'docs' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <h2 className="text-xl font-bold text-slate-900">{t.invoiceHeader}</h2>
                <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                  <button
                    onClick={() => setInvoiceLang('tr')}
                    className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${invoiceLang === 'tr' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                  >
                    {lang === 'tr' ? 'TR Şablon' : 'TR Template'}
                  </button>
                  <button
                    onClick={() => setInvoiceLang('en')}
                    className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${invoiceLang === 'en' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                  >
                    EN Template
                  </button>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => handleDownloadInvoicePdf(false)} 
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{lang === 'tr' ? 'Fatura İndir' : 'Download Invoice'}</span>
                  </button>
                  <button 
                    onClick={() => handleDownloadInvoicePdf(true)} 
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 transition-colors cursor-pointer"
                    title={lang === 'tr' ? 'Paylaş' : 'Share'}
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => handleDownloadPackingListPdf(false)} 
                    className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{lang === 'tr' ? 'Çeki Listesi İndir' : 'Download Packing List'}</span>
                  </button>
                  <button 
                    onClick={() => handleDownloadPackingListPdf(true)} 
                    className="p-1.5 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-lg border border-sky-200 transition-colors cursor-pointer"
                    title={lang === 'tr' ? 'Paylaş' : 'Share'}
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>

                <button 
                  onClick={() => window.print()} 
                  className="px-3 py-1.5 bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{lang === 'tr' ? 'Yazdır' : 'Print'}</span>
                </button>
              </div>
            </div>

            {/* GİB Gümrük e-Faturası & Yasal Uyarı Bildirimi */}
            <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-start gap-3.5 text-xs">
              <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1 text-slate-700 dark:text-slate-300">
                <span className="font-bold text-amber-900 dark:text-amber-300 block">
                  {lang === 'tr' ? '⚖️ Yasal Uyarı: GİB "Gümrük" Tipi e-Fatura Zorunluluğu & KDV İstisnası' : '⚖️ Legal Notice: GİB "Customs" e-Invoice & VAT Exemption Rule'}
                </span>
                <p className="leading-relaxed">
                  {lang === 'tr'
                    ? 'Bu ekranda oluşturulan PDF evrak, yurt dışındaki ithalatçınız için uluslararası ticari belgedir (Commercial Invoice). Türkiye Cumhuriyeti Gümrük İdaresi nezdinde beyanname tescili için e-Fatura mükelleflerinin GİB sistemi üzerinden 301 İstisna Kodu ile "GÜMRÜK" tipinde e-Fatura düzenlemesi ve oluşan 23 haneli ID\'yi gümrük müşavirine iletmesi 3065 s. KDV Kanunu Md. 11/1-a uyarınca zorunludur.'
                    : 'The PDF invoice generated here serves as a Commercial Invoice for foreign customs clearance. For official Turkish customs declaration, e-Invoice registered entities must issue a "CUSTOMS" type e-Invoice with Exception Code 301 via GİB portal.'}
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="font-bold text-slate-900">{lang === 'tr' ? 'Fatura Detayları' : 'Invoice Details'}</h3>
                  <div className="text-xs font-mono font-bold text-sky-600">{invoiceNumber}</div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <div className="text-slate-500 mb-1">{lang === 'tr' ? 'İhracatçı' : 'Exporter'}</div>
                    <div className="font-bold">{invoiceSeller}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 mb-1">{lang === 'tr' ? 'Alıcı' : 'Consignee'}</div>
                    <div className="font-bold">{invoiceBuyer}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 mb-1">{lang === 'tr' ? 'Tarih' : 'Date'}</div>
                    <div className="font-bold">{invoiceDate}</div>
                  </div>
                  <div>
                    <div className="text-slate-500 mb-1">{lang === 'tr' ? 'Incoterm' : 'Terms'}</div>
                    <div className="font-bold">{invoiceIncoterm}</div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="font-bold text-slate-900">{lang === 'tr' ? 'Kalem Listesi' : 'Item List'}</h3>
                  <div className="text-xs font-bold text-slate-500">{invoiceItems.length} {lang === 'tr' ? 'Kalem' : 'Items'}</div>
                </div>
                <div className="space-y-2">
                  {invoiceItems.map((item, idx) => (
                    <div key={item.id} className="flex items-center justify-between text-xs p-2 bg-slate-50 rounded-lg">
                      <div className="font-medium text-slate-900">{idx + 1}. {item.description}</div>
                      <div className="font-bold">{item.qty} {item.unit}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'exchange' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-slate-900">{t.exchangeRate}</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {rates.map(r => (
                <div key={r.code} className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-slate-500">{r.code} / TRY</div>
                  <div className="text-xl font-bold font-mono text-slate-900 mt-1">{r.rate.toFixed(2)} ₺</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeScreen === 'sync' && (
          <div className="space-y-6 max-w-5xl mx-auto">
            {/* Header Banner */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center shrink-0">
                    <FolderSync className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                      {lang === 'tr'
                        ? 'Dosya Tabanlı Ekip Paylaşımı (Google Drive / OneDrive Uyumlu)'
                        : 'File-Based Team Sharing (Google Drive / OneDrive Compatible)'}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {lang === 'tr'
                        ? 'Merkezi veritabanı maliyeti (0 ₺) olmadan, şirket içi ortak bulut klasörünüz üzerinden ekip çalışması.'
                        : 'Zero server database costs ($0) using your local shared cloud synchronization folder.'}
                    </p>
                  </div>
                </div>

                {lastSyncTimestamp && (
                  <div className="text-left sm:text-right bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs shrink-0">
                    <span className="text-slate-500 block text-[10px] uppercase font-bold">
                      {lang === 'tr' ? 'Son Eşitleme / İşlem' : 'Last Sync / Action'}
                    </span>
                    <span className="font-mono font-bold text-slate-800">{lastSyncTimestamp}</span>
                  </div>
                )}
              </div>

              {/* Mandatory User Clarification Notice */}
              <div className="p-4 bg-amber-50 border border-amber-200/80 rounded-xl text-amber-900 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-xs leading-relaxed">
                  <span className="font-bold block text-amber-950 mb-0.5">
                    {lang === 'tr' ? 'Önemli Bilgilendirme & Çalışma Prensibi:' : 'Important Notice & How It Works:'}
                  </span>
                  <span>
                    {lang === 'tr'
                      ? 'Dışa Aktar ile inen dosyayı kendi Drive/OneDrive klasörünüze siz taşırsınız, otomatik bağlantı yoktur. Sistem arka planda herhangi bir üçüncü taraf bulut hesabınıza doğrudan bağlanmaz; verileriniz cihazınızdan izinsiz çıkmaz.'
                      : 'You manually move the downloaded file to your own Drive/OneDrive folder; there is no automatic connection. The app does not connect directly to third-party cloud APIs.'}
                  </span>
                </div>
              </div>

              {syncFeedback && (
                <div
                  className={`p-3.5 rounded-xl text-xs flex items-center gap-2.5 ${
                    syncFeedback.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span className="font-medium">{syncFeedback.message}</span>
                </div>
              )}
            </div>

            {/* Action Cards: Export and Import */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Export Card */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between space-y-5">
                <div className="space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center font-bold">
                      <CloudDownload className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                      {lang === 'tr' ? '1. Ortak Ekip Verisini Dışa Aktar' : '1. Export Team Data'}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lang === 'tr'
                      ? 'Mevcut sevkiyat listenizi, yol haritası durumlarınızı ve şirket profilinizi tek bir JSON dosyasında paketleyip bilgisayarınıza indirir.'
                      : 'Packages your active shipments, roadmap progress, and profile into a standardized JSON file.'}
                  </p>
                  <ul className="text-xs text-slate-500 space-y-1.5 list-disc list-inside">
                    <li>{lang === 'tr' ? 'gumrukpilot_ortak_ekip_YYYYMMDD.json adıyla iner' : 'Downloads as gumrukpilot_ortak_ekip_YYYYMMDD.json'}</li>
                    <li>{lang === 'tr' ? 'İnen dosyayı ortak Drive / OneDrive klasörüne sürükleyin' : 'Move downloaded file to shared Drive / OneDrive folder'}</li>
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={handleExportGoogleDriveJson}
                  className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CloudDownload className="w-4 h-4" />
                  <span>{lang === 'tr' ? 'Ekip Dosyasını İndir (.json)' : 'Download Team JSON File'}</span>
                </button>
              </div>

              {/* Import Card */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between space-y-5">
                <div className="space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
                      <CloudUpload className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                      {lang === 'tr' ? '2. Ortak Klasörden İçe Aktar & Eşitle' : '2. Import & Merge From Team'}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lang === 'tr'
                      ? 'Ekip arkadaşınızın ortak Drive / OneDrive klasörüne kaydettiği güncel dosyayı seçin. Mevcut kayıtlarınız silinmez; yeni ve değişen sevkiyatlar akıllıca birleştirilir.'
                      : 'Select the file updated by your teammate. Existing records are preserved; new and modified shipments are merged.'}
                  </p>
                  <ul className="text-xs text-slate-500 space-y-1.5 list-disc list-inside">
                    <li>{lang === 'tr' ? 'Akıllı ID eşleştirme ile üzerine yazmaz' : 'Smart ID matching avoids data duplication'}</li>
                    <li>{lang === 'tr' ? 'Anında tarayıcı depolamanıza (localStorage) işlenir' : 'Instantly reflected in local storage'}</li>
                  </ul>
                </div>

                <label className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer text-center select-none">
                  <CloudUpload className="w-4 h-4" />
                  <span>{lang === 'tr' ? 'Ortak JSON Dosyasını Seç & Eşitle' : 'Select Team JSON File & Merge'}</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportGoogleDriveJson}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* How It Works Guide */}
            <div className="bg-slate-900 text-white p-6 rounded-2xl space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <span>🔄</span>
                <span>{lang === 'tr' ? '3 Adımda Ekip Senkronizasyon Akışı' : '3-Step Team Sync Workflow'}</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 space-y-1.5">
                  <span className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs mb-1">
                    1
                  </span>
                  <h4 className="font-bold text-white">{lang === 'tr' ? 'Dışa Aktar' : 'Export'}</h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {lang === 'tr'
                      ? 'Sevkiyatları güncelleyen ekip üyesi JSON dosyasını indirir.'
                      : 'The user making updates exports the latest JSON file.'}
                  </p>
                </div>

                <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 space-y-1.5">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs mb-1">
                    2
                  </span>
                  <h4 className="font-bold text-white">{lang === 'tr' ? 'Ortak Klasöre Taşı' : 'Move to Shared Folder'}</h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {lang === 'tr'
                      ? 'Dosya, şirketin Google Drive, OneDrive veya Dropbox senkronize klasörüne sürüklenir.'
                      : 'File is moved to the company Google Drive or OneDrive desktop sync folder.'}
                  </p>
                </div>

                <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 space-y-1.5">
                  <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs mb-1">
                    3
                  </span>
                  <h4 className="font-bold text-white">{lang === 'tr' ? 'İçe Aktar & Birleştir' : 'Import & Merge'}</h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {lang === 'tr'
                      ? 'Diğer ekip arkadaşları ortak klasördeki dosyayı seçerek kendi ekranlarına eşitler.'
                      : 'Teammates select the shared file to update their local cockpit.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeScreen === 'catalog' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">{lang === 'tr' ? 'Ürün Kataloğu' : 'Product Catalog'}</h2>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800">
                {productCatalog.length} {lang === 'tr' ? 'Ürün' : 'Products'}
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-900">{lang === 'tr' ? 'Yeni Ürün Ekle' : 'Add New Product'}</h3>
                <form onSubmit={handleSaveCatalogProduct} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">{lang === 'tr' ? 'Ürün Adı *' : 'Product Name *'}</label>
                    <input
                      type="text"
                      required
                      value={catalogFormName}
                      onChange={e => setCatalogFormName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">{lang === 'tr' ? 'GTİP Kodu *' : 'HS Code *'}</label>
                    <input
                      type="text"
                      required
                      value={catalogFormHs}
                      onChange={e => setCatalogFormHs(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 font-mono"
                    />
                  </div>
                  <button type="submit" className="w-full py-2.5 bg-emerald-600 text-white font-bold rounded-lg cursor-pointer">
                    {lang === 'tr' ? 'Kaydet' : 'Save'}
                  </button>
                </form>
              </div>

              <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 text-slate-500 font-semibold">
                      <th className="py-2">{lang === 'tr' ? 'Ürün' : 'Product'}</th>
                      <th className="py-2 font-mono">{lang === 'tr' ? 'GTİP' : 'HS Code'}</th>
                      <th className="py-2 text-right">{lang === 'tr' ? 'Fiyat' : 'Price'}</th>
                      <th className="py-2 text-center">{lang === 'tr' ? 'İşlem' : 'Action'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {productCatalog.map(prod => (
                      <tr key={prod.id}>
                        <td className="py-2 font-bold text-slate-900">{prod.name}</td>
                        <td className="py-2 font-mono text-emerald-700">{prod.hsCode}</td>
                        <td className="py-2 text-right font-mono font-bold">{prod.unitPrice.toFixed(2)} {prod.currency}</td>
                        <td className="py-2 text-center">
                          <button onClick={() => handleDeleteCatalogProduct(prod.id)} className="text-rose-600 hover:text-rose-700 font-semibold cursor-pointer">{lang === 'tr' ? 'Sil' : 'Delete'}</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

        {/* Global Legal Safe Harbor Footer */}
        <footer className="mt-12 pt-6 pb-4 border-t border-slate-200 dark:border-slate-800 text-center text-[11px] text-slate-500 dark:text-slate-400 space-y-1.5">
          <div className="flex items-center justify-center gap-2 font-semibold text-slate-700 dark:text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>GümrükPilot &copy; 2026 — {lang === 'tr' ? 'Dış Ticaret ve Lojistik Uyum Kokpiti' : 'Foreign Trade & Logistics Compliance OS'}</span>
          </div>
          <p className="max-w-3xl mx-auto leading-relaxed">
            {lang === 'tr'
              ? 'Yasal Bildirim: Bu platformda sunulan GTİP, rejim kütüphanesi, koli optimizasyonu ve kambiyo süreleri simülasyon amaçlıdır. 4458 sayılı Gümrük Kanunu ve mer\'i mevzuat uyarınca nihai tescil işlemleri için yetkili Gümrük Müşaviriniz esastır.'
              : 'Legal Notice: Tariffs, pallet calculations, and regulatory deadlines are decision-support simulations. Consult your licensed customs broker for final official filings pursuant to Customs Law.'}
          </p>
          <div><LegalLinks lang={lang} /></div>
        </footer>
      </main>

      {isQuickDrawerOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div onClick={() => setIsQuickDrawerOpen(false)} className="absolute inset-0 bg-slate-900/60" />
          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-slate-900 text-white shadow-2xl p-6 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold">{lang === 'tr' ? 'Hızlı Kur Paneli' : 'Quick FX Panel'}</h3>
              </div>
              <button onClick={() => setIsQuickDrawerOpen(false)} className="px-4 py-1.5 bg-sky-600 text-white rounded-lg text-xs font-bold cursor-pointer">
                {lang === 'tr' ? 'Kapat' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI Gümrük Rehberi & Yönlendirici Drawer */}
      <CustomsCopilotDrawer
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        onNavigate={(screen) => {
          setActiveScreenState(screen);
          setScreenHistory(prev => [...prev.slice(-10), activeScreen]);
        }}
        lang={lang}
      />
    </div>
  );
}
