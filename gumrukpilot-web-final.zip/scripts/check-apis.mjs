// Canlı doğrulama: npx tsx scripts/check-apis.mjs
// Dış servislerin gerçekte döndürdüğü biçimi gösterir. Çıktı beklenmedikse bağlantıyı yayına almayın.
import { lookupOfficial } from '../server/officialSources.ts';
const cases = [['8471.30', 'ABD'], ['8708.29', 'Almanya'], ['6109.10', 'Birleşik Krallık']];
for (const [hs, c] of cases) {
  const r = await lookupOfficial(hs, c);
  console.log(`\n== ${hs} / ${c}\n`, JSON.stringify(r, null, 1).slice(0, 1200));
}
